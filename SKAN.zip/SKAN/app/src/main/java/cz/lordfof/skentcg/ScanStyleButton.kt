package cz.lordfof.skan

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * Hlavni tlacitko SKAN. Swipem doleva/doprava prepina BRAINROT a POKEMON styl.
 * Brainrot styl pouziva samostatny transparentni SKAN! artwork.
 */
class ScanStyleButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private enum class Style { BRAINROT, POKEMON }

    private var style = Style.BRAINROT
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private val prefs = context.getSharedPreferences("scan_button_style", Context.MODE_PRIVATE)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val brainrotLogo: Drawable? = ContextCompat.getDrawable(context, R.drawable.scan_brainrot)

    init {
        style = if (prefs.getString("style", "brainrot") == "pokemon") Style.POKEMON else Style.BRAINROT
        isClickable = true
        contentDescription = "SKAN"
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        if (style == Style.BRAINROT) {
            // Transparent Brainrot logo — bez barevného tlačítkového pozadí.
            val drawable = brainrotLogo
            if (drawable != null) {
                val maxW = w * 0.94f
                val maxH = h * 0.94f
                val intrinsicW = drawable.intrinsicWidth.coerceAtLeast(1).toFloat()
                val intrinsicH = drawable.intrinsicHeight.coerceAtLeast(1).toFloat()
                val scale = minOf(maxW / intrinsicW, maxH / intrinsicH)
                val dw = (intrinsicW * scale).toInt()
                val dh = (intrinsicH * scale).toInt()
                val left = ((w - dw) / 2f).toInt()
                val top = ((h - dh) / 2f).toInt()
                drawable.setBounds(left, top, left + dw, top + dh)
                drawable.draw(canvas)
            }
        } else {
            drawPokemonButton(canvas, w, h)
        }
    }

    private fun drawPokemonButton(canvas: Canvas, w: Float, h: Float) {
        val left = w * 0.08f
        val right = w * 0.92f
        val top = h * 0.12f
        val bottom = h * 0.88f
        val radius = h * 0.32f

        bgPaint.shader = LinearGradient(
            left, top, right, bottom,
            intArrayOf(Color.rgb(20, 58, 155), Color.rgb(40, 120, 225), Color.rgb(247, 194, 24)),
            null, Shader.TileMode.CLAMP
        )
        bgPaint.style = Paint.Style.FILL
        canvas.drawRoundRect(left, top, right, bottom, radius, radius, bgPaint)

        bgPaint.shader = null
        bgPaint.style = Paint.Style.STROKE
        bgPaint.strokeWidth = h * 0.035f
        bgPaint.color = Color.rgb(255, 224, 50)
        canvas.drawRoundRect(left, top, right, bottom, radius, radius, bgPaint)

        textPaint.style = Paint.Style.FILL
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        textPaint.textSize = h * 0.48f
        textPaint.isFakeBoldText = true
        textPaint.color = Color.WHITE
        textPaint.setShadowLayer(h * 0.10f, h * 0.035f, h * 0.045f, Color.rgb(0, 25, 80))
        val cy = (top + bottom) / 2f - (textPaint.ascent() + textPaint.descent()) / 2f
        canvas.drawText("SKAN !", (left + right) / 2f, cy, textPaint)

        textPaint.clearShadowLayer()
        textPaint.textSize = h * 0.16f
        textPaint.color = Color.argb(170, 255, 255, 255)
        canvas.drawText("‹   ›", right - h * 0.43f, bottom - h * 0.10f, textPaint)
    }

    private fun toggleStyle() {
        style = if (style == Style.BRAINROT) Style.POKEMON else Style.BRAINROT
        prefs.edit().putString("style", if (style == Style.POKEMON) "pokemon" else "brainrot").apply()
        animate().scaleX(0.96f).scaleY(0.96f).setDuration(70).withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(90).start()
        }.start()
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(event.x - downX) > 12f || abs(event.y - downY) > 12f) moved = true
                return true
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.x - downX
                val dy = event.y - downY
                if (abs(dx) > 90f && abs(dx) > abs(dy) * 1.25f) {
                    toggleStyle()
                    // Swipe only changes the visual style. It must NEVER open the camera.
                    return true
                }
                if (!moved) return performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
