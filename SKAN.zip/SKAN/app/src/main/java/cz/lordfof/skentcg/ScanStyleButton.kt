package cz.lordfof.skan

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * Hlavni tlacitko SKAN. Swipem doleva/doprava prepina styly:
 * BRAINROT -> POKEMON -> STAR WARS -> HOT WHEELS -> BRAINROT.
 * Swipe meni pouze vzhled; klepnuti otevre scanner.
 */
class ScanStyleButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private enum class Style { BRAINROT, POKEMON, STARWARS, HOTWHEELS }

    private var style = Style.BRAINROT
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private val prefs = context.getSharedPreferences("scan_button_style", Context.MODE_PRIVATE)
    private val brainrotLogo: Drawable? = ContextCompat.getDrawable(context, R.drawable.scan_brainrot)
    private val pokemonLogo: Drawable? = ContextCompat.getDrawable(context, R.drawable.skan_logo)
    private val starWarsLogo: Drawable? = ContextCompat.getDrawable(context, R.drawable.scan_starwars)
    private val hotWheelsLogo: Drawable? = ContextCompat.getDrawable(context, R.drawable.scan_hotwheels)

    init {
        style = when (prefs.getString("style", "brainrot")) {
            "pokemon" -> Style.POKEMON
            "starwars" -> Style.STARWARS
            "hotwheels" -> Style.HOTWHEELS
            else -> Style.BRAINROT
        }
        isClickable = true
        contentDescription = "SKAN"
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val drawable = when (style) {
            Style.BRAINROT -> brainrotLogo
            Style.POKEMON -> pokemonLogo
            Style.STARWARS -> starWarsLogo
            Style.HOTWHEELS -> hotWheelsLogo
        } ?: return

        val maxW = w * 0.96f
        val maxH = h * 0.92f
        val intrinsicW = drawable.intrinsicWidth.coerceAtLeast(1).toFloat()
        val intrinsicH = drawable.intrinsicHeight.coerceAtLeast(1).toFloat()
        val scale = minOf(maxW / intrinsicW, maxH / intrinsicH)
        val dw = (intrinsicW * scale).toInt()
        val dh = (intrinsicH * scale).toInt()
        val left = ((w - dw) / 2f).toInt()
        val top = ((h - dh) / 2f).toInt()
        drawable.setBounds(left, top, left + dw, top + dh)
        drawable.draw(canvas)
    }

    private fun cycleStyle(direction: Int) {
        val styles = Style.values()
        var index = styles.indexOf(style)
        index = (index + direction + styles.size) % styles.size
        style = styles[index]
        prefs.edit().putString("style", when (style) {
            Style.BRAINROT -> "brainrot"
            Style.POKEMON -> "pokemon"
            Style.STARWARS -> "starwars"
            Style.HOTWHEELS -> "hotwheels"
        }).apply()
        animate().scaleX(0.96f).scaleY(0.96f).setDuration(70).withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(90).start()
        }.start()
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(event.x - downX) > 12f || abs(event.y - downY) > 12f) moved = true
                return true
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.x - downX
                val dy = event.y - downY
                if (abs(dx) > 90f && abs(dx) > abs(dy) * 1.25f) {
                    // Doprava = dalsi styl, doleva = predchozi styl.
                    cycleStyle(if (dx > 0f) 1 else -1)
                    return true
                }
                if (!moved) return performClick()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
