package cz.lordfof.skan

import android.Manifest
import android.app.Dialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    private lateinit var cardImage: ImageView
    private lateinit var cardName: TextView
    private lateinit var cardInfo: TextView
    private lateinit var cardSet: TextView
    private lateinit var collectionButton: Button
    private val executor = Executors.newSingleThreadExecutor()
    private val scanning = AtomicBoolean(false)
    private val prefs by lazy { getSharedPreferences("collection", MODE_PRIVATE) }
    private lateinit var cards: List<Card>
    private var scannerDialog: Dialog? = null

    private val cameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openScannerDialog()
        else Toast.makeText(this, "Bez povolení kamery SKAN nemůže skenovat EAN kódy.", Toast.LENGTH_LONG).show()
    }

    data class Card(
        val id: String,
        val number: Int,
        val name: String,
        val type: String,
        val element: String,
        val stage: String,
        val evolvesFrom: String,
        val evolutionFamily: String,
        val evolutionOrder: Int,
        val category: String,
        val trainerSubtype: String,
        val energySubtype: String,
        val setId: String,
        val setName: String,
        val generation: Int,
        val imageSmall: String,
        val imageLarge: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        cards = loadCards()

        cardImage = findViewById(R.id.cardImage)
        cardName = findViewById(R.id.cardName)
        cardInfo = findViewById(R.id.cardInfo)
        cardSet = findViewById(R.id.cardSet)
        collectionButton = findViewById(R.id.collectionButton)

        findViewById<Button>(R.id.scan).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openScannerDialog()
            else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
        collectionButton.setOnClickListener { showCollectionDialog() }
        findViewById<Button>(R.id.decksButton).setOnClickListener { showDecksDialog() }
        updateCollectionButton()
    }

    private fun loadCards(): List<Card> {
        val result = mutableListOf<Card>()
        val files = assets.list("") ?: emptyArray()
        files.filter { it.endsWith("_cards.json") }.forEach { file ->
            val root = JSONObject(assets.open(file).bufferedReader().use { it.readText() })
            val setId = root.optString("setId", file.substringBefore("_cards.json"))
            val setName = root.optString("setName", setId)
            val defaultGeneration = root.optInt("generation", 1)
            val a = root.getJSONArray("cards")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val numberText = o.optString("number", (i + 1).toString())
                result += Card(
                    id = o.getString("id"),
                    number = numberText.toIntOrNull() ?: (i + 1),
                    name = o.getString("name"),
                    type = o.optString("cardType", "Karta"),
                    element = readTextOrArray(o, "element", "elements", "types"),
                    stage = o.optString("stage", o.optString("evolutionStage", "")),
                    evolvesFrom = o.optString("evolvesFrom", ""),
                    evolutionFamily = o.optString("evolutionFamily", ""),
                    evolutionOrder = o.optInt("evolutionOrder", 0),
                    category = o.optString("category", o.optString("cardType", "")),
                    trainerSubtype = o.optString("trainerSubtype", ""),
                    energySubtype = o.optString("energySubtype", ""),
                    setId = o.optString("setId", setId),
                    setName = o.optString("setName", setName),
                    generation = o.optInt("generation", defaultGeneration),
                    imageSmall = o.optString("imageSmall", o.optString("imageLarge")),
                    imageLarge = o.getString("imageLarge")
                )
            }
        }
        return result.sortedWith(compareBy<Card> { it.generation }.thenBy { it.setName }.thenBy { it.number })
    }

    private fun readTextOrArray(o: JSONObject, vararg keys: String): String {
        for (key in keys) {
            if (!o.has(key) || o.isNull(key)) continue
            val value = o.get(key)
            if (value is JSONArray) return (0 until value.length()).joinToString(", ") { value.optString(it) }
            val text = value.toString().trim()
            if (text.isNotEmpty()) return text
        }
        return ""
    }

    private fun openScannerDialog() {
        if (scannerDialog?.isShowing == true) return
        scanning.set(true)
        val dialog = Dialog(this)
        scannerDialog = dialog
        val root = FrameLayout(this).apply { setBackgroundColor(Color.argb(245, 20, 20, 20)); setPadding(dp(18), dp(18), dp(18), dp(18)) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        root.addView(box, FrameLayout.LayoutParams(-1, -1))
        val preview = PreviewView(this).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE; scaleType = PreviewView.ScaleType.FILL_CENTER }
        box.addView(preview, LinearLayout.LayoutParams(dp(290), dp(290)).apply { gravity = Gravity.CENTER })
        val hint = TextView(this).apply { text = "Namiř čtvereček na EAN čárový kód"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        box.addView(hint, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        val close = roundedButton("ZRUŠIT") { scanning.set(false); dialog.dismiss() }
        box.addView(close, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        dialog.setContentView(root)
        dialog.setCancelable(false)
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.90f).toInt(), (resources.displayMetrics.heightPixels * 0.76f).toInt())
        startCamera(preview, dialog)
    }

    private fun startCamera(preview: PreviewView, dialog: Dialog) {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(executor) { proxy ->
                    val media = proxy.image
                    if (media == null || !scanning.get()) { proxy.close(); return@setAnalyzer }
                    val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                    BarcodeScanning.getClient().process(image)
                        .addOnSuccessListener { codes ->
                            val code = codes.firstOrNull { it.rawValue?.matches(Regex("[0-9]{8,14}")) == true }?.rawValue
                            if (code != null && scanning.compareAndSet(true, false)) runOnUiThread { dialog.dismiss(); scannerDialog = null; showCard(code) }
                        }
                        .addOnCompleteListener { proxy.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
                dialog.setOnDismissListener { scanning.set(false); provider.unbindAll(); scannerDialog = null }
            } catch (_: Exception) {
                scanning.set(false); dialog.dismiss(); Toast.makeText(this, "Kameru se nepodařilo otevřít.", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun showCard(ean: String) {
        val card = cards[deterministicIndex(ean)]
        prefs.edit().putBoolean(card.id, true).putLong(foundAtKey(card.id), System.currentTimeMillis()).apply()
        Glide.with(this).load(card.imageLarge).into(cardImage)
        cardName.text = card.name
        cardInfo.text = card.type
        cardSet.text = "${card.setName} · ${card.number}/${cards.count { it.setId == card.setId }}"
        updateCollectionButton()
    }

    private fun deterministicIndex(ean: String): Int {
        val digest = MessageDigest.getInstance("SHA-256").digest(ean.toByteArray(Charsets.UTF_8))
        var x = 0L
        for (b in digest.take(8)) x = (x shl 8) or (b.toLong() and 255L)
        return Math.floorMod(x, cards.size.toLong()).toInt()
    }

    private fun foundAtKey(id: String) = "foundAt_$id"
    private fun favoriteKey(id: String) = "favorite_$id"
    private fun isOwned(card: Card) = prefs.getBoolean(card.id, false)
    private fun isFavorite(card: Card) = prefs.getBoolean(favoriteKey(card.id), false)

    private fun updateCollectionButton() {
        collectionButton.contentDescription = "Kolekce ${cards.count { isOwned(it) }}/${cards.size}"
    }

    private fun showCollectionDialog() {
        val dialog = Dialog(this)
        val root = darkDialogRoot()
        val title = dialogTitle("MOJE KOLEKCE")
        root.addView(title)

        val filterRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val modeSpinner = makeSpinner(arrayOf("Vše", "Nalezené", "Oblíbené", "Pokémon", "Energie", "Item", "Trainer"))
        val elementSpinner = makeSpinner(arrayOf("Všechny elementy") + availableElements().toTypedArray())
        val sortSpinner = makeSpinner(arrayOf("Datum nalezení", "Element", "Stadium vývoje", "Abecedy", "Pořadí na kartě"))
        filterRow.addView(modeSpinner, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        filterRow.addView(elementSpinner, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        filterRow.addView(sortSpinner, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(filterRow)

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        val close = roundedButton("ZAVŘÍT") { dialog.dismiss() }
        root.addView(close, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        var selectedSet: String? = null
        val collapsedSets = mutableSetOf<String>()
        val collapsedGenerations = mutableSetOf<Int>()
        val generations = cards.map { it.generation }.distinct().sorted()

        fun render() {
            content.removeAllViews()
            val mode = modeSpinner.selectedItem.toString()
            val element = elementSpinner.selectedItem.toString()
            val sort = sortSpinner.selectedItem.toString()
            val sets = cards.map { it.setId }.distinct()
            if (selectedSet == null && sets.size == 1) selectedSet = sets.first()

            if (sets.size == 1) {
                val setId = sets.first()
                val setCards = cards.filter { it.setId == setId }
                val header = sectionButton("${setCards.first().setName}  ${ownedCount(setId)}/${setTotal(setId)}", true)
                content.addView(header)
                val body = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                body.visibility = if (collapsedSets.contains(setId)) View.GONE else View.VISIBLE
                header.setOnClickListener { if (!collapsedSets.add(setId)) collapsedSets.remove(setId); render() }
                content.addView(body)
                if (body.visibility == View.VISIBLE) renderCards(body, applyFilterAndSort(setCards, mode, element, sort))
            } else {
                generations.forEach { gen ->
                    val genSets = cards.filter { it.generation == gen }.distinctBy { it.setId }.sortedBy { it.setName }
                    val genHeader = sectionButton("Gen $gen  ${ownedCountGeneration(gen)}/${totalGeneration(gen)}", true)
                    content.addView(genHeader)
                    val genBody = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                    genBody.visibility = if (collapsedGenerations.contains(gen)) View.GONE else View.VISIBLE
                    genHeader.setOnClickListener { if (!collapsedGenerations.add(gen)) collapsedGenerations.remove(gen); render() }
                    content.addView(genBody)
                    if (genBody.visibility == View.VISIBLE) {
                        genSets.forEach { set ->
                            val setHeader = sectionButton("${set.setName}  ${ownedCount(set.setId)}/${setTotal(set.setId)}", false)
                            genBody.addView(setHeader)
                            val setBody = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                            setBody.visibility = if (collapsedSets.contains(set.setId)) View.GONE else View.VISIBLE
                            setHeader.setOnClickListener { if (!collapsedSets.add(set.setId)) collapsedSets.remove(set.setId); render() }
                            genBody.addView(setBody)
                            if (setBody.visibility == View.VISIBLE) renderCards(setBody, applyFilterAndSort(cards.filter { it.setId == set.setId }, mode, element, sort))
                        }
                    }
                }
            }
        }
        val refresh = { render() }
        modeSpinner.onItemSelected(refresh)
        elementSpinner.onItemSelected(refresh)
        sortSpinner.onItemSelected(refresh)
        dialog.setContentView(root)
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.96f).toInt(), (resources.displayMetrics.heightPixels * 0.92f).toInt())
        render()
    }

    private fun availableElements(): List<String> = cards.flatMap { it.element.split(",", "/", "|") }.map { it.trim() }.filter { it.isNotEmpty() }.distinct().sorted()

    private fun applyFilterAndSort(source: List<Card>, mode: String, element: String, sort: String): List<Card> {
        var list = source
        list = when (mode) {
            "Nalezené" -> list.filter { isOwned(it) }
            "Oblíbené" -> list.filter { isFavorite(it) }
            "Pokémon" -> list.filter { it.category.equals("Pokémon", true) }
            "Energie" -> list.filter { it.category.equals("Energy", true) || it.category.equals("Energie", true) }
            "Item" -> list.filter { it.category.equals("Trainer", true) && it.trainerSubtype.equals("Item", true) }
            "Trainer" -> list.filter { it.category.equals("Trainer", true) && !it.trainerSubtype.equals("Item", true) }
            else -> list
        }
        if (element != "Všechny elementy") list = list.filter { it.element.split(",", "/", "|").map { e -> e.trim() }.any { it.equals(element, true) } }
        return when (sort) {
            "Datum nalezení" -> list.sortedWith(compareByDescending<Card> { prefs.getLong(foundAtKey(it.id), 0L) }.thenBy { it.number })
            "Element" -> list.sortedWith(compareBy<Card> { it.element.ifBlank { "~" } }.thenBy { it.evolutionFamily.ifBlank { it.name } }.thenBy { it.evolutionOrder }.thenBy { it.number })
            "Stadium vývoje" -> list.sortedWith(compareBy<Card> { it.evolutionFamily.ifBlank { "~" } }.thenBy { it.evolutionOrder }.thenBy { it.number })
            "Abecedy" -> list.sortedBy { it.name.lowercase() }
            else -> list.sortedBy { it.number }
        }
    }

    private fun renderCards(content: LinearLayout, setCards: List<Card>) {
        if (setCards.isEmpty()) {
            content.addView(TextView(this).apply { text = "Žádné karty neodpovídají filtru."; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(dp(8), dp(18), dp(8), dp(18)) })
            return
        }
        val grid = GridLayout(this).apply { columnCount = 3; useDefaultMargins = true; setPadding(dp(4), dp(4), dp(4), dp(8)) }
        setCards.forEach { card ->
            val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(3), dp(3), dp(8)) }
            val image = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(96), dp(134)); scaleType = ImageView.ScaleType.CENTER_CROP; contentDescription = card.name; alpha = if (isOwned(card)) 1f else 0.28f
                setOnClickListener { showCardViewer(card) }
            }
            Glide.with(this).load(card.imageSmall).into(image)
            tile.addView(image)
            tile.addView(TextView(this).apply { text = "#${card.number}${if (isFavorite(card)) "  ♥" else ""}"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE) })
            tile.setOnClickListener { showCardViewer(card) }
            grid.addView(tile, GridLayout.LayoutParams().apply { width = 0; height = GridLayout.LayoutParams.WRAP_CONTENT; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) })
        }
        content.addView(grid)
    }

    private fun showCardViewer(card: Card) {
        val viewer = Dialog(this)
        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); isClickable = true }
        val image = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; contentDescription = card.name }
        frame.addView(image, FrameLayout.LayoutParams(-1, -1).apply { setMargins(dp(10), dp(62), dp(10), dp(112)) })
        Glide.with(this).load(card.imageLarge).into(image)
        val back = roundedButton("‹ ZPĚT") { viewer.dismiss() }
        frame.addView(back, FrameLayout.LayoutParams(dp(105), dp(50), Gravity.TOP or Gravity.START).apply { topMargin = dp(8); leftMargin = dp(8) })
        val info = TextView(this).apply { text = "${card.name}  •  ${card.setName} #${card.number}"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        frame.addView(info, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP).apply { topMargin = dp(8); leftMargin = dp(112); rightMargin = dp(8) })

        val fav = roundedButton(if (isFavorite(card)) "♥ OBLÍBENÉ" else "♡ OBLÍBENÉ") {
            prefs.edit().putBoolean(favoriteKey(card.id), !isFavorite(card)).apply()
            (it as Button).text = if (isFavorite(card)) "♥ OBLÍBENÉ" else "♡ OBLÍBENÉ"
        }
        frame.addView(fav, FrameLayout.LayoutParams(0, dp(52), Gravity.BOTTOM or Gravity.START).apply { leftMargin = dp(8); rightMargin = dp(4); bottomMargin = dp(12); width = 0 })
        (fav.layoutParams as FrameLayout.LayoutParams).width = (resources.displayMetrics.widthPixels * 0.44f).toInt()
        val deck = roundedButton("＋ DO BALÍČKU") { showDeckPicker(card) }
        frame.addView(deck, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.44f).toInt(), dp(52), Gravity.BOTTOM or Gravity.END).apply { rightMargin = dp(8); bottomMargin = dp(12) })

        frame.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val edge = dp(70)
                if (event.x < edge || event.x > frame.width - edge) { viewer.dismiss(); true } else false
            } else false
        }
        viewer.setContentView(frame)
        viewer.show()
        viewer.window?.setBackgroundDrawableResource(android.R.color.transparent)
        viewer.window?.setLayout((resources.displayMetrics.widthPixels * 0.98f).toInt(), (resources.displayMetrics.heightPixels * 0.96f).toInt())
    }

    private fun showDecksDialog() {
        val dialog = Dialog(this)
        val root = darkDialogRoot()
        root.addView(dialogTitle("MOJE BALÍČKY"))
        val add = roundedButton("＋ NOVÝ BALÍČEK") {
            val input = EditText(this).apply { hint = "Název balíčku"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
            AlertDialogBuilder(dialog, input) { name ->
                if (name.isNotBlank()) {
                    val decks = getDeckNames().toMutableSet(); decks.add(name); saveDeckNames(decks); renderDeckList(root, dialog)
                }
            }
        }
        root.addView(add, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        renderDeckList(root, dialog)
        val close = roundedButton("ZAVŘÍT") { dialog.dismiss() }
        root.addView(close)
        dialog.setContentView(root)
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), (resources.displayMetrics.heightPixels * 0.82f).toInt())
    }

    private fun renderDeckList(root: LinearLayout, dialog: Dialog) {
        val old = root.findViewWithTag<View>("deckList")
        if (old != null) root.removeView(old)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "deckList" }
        getDeckNames().sorted().forEach { name ->
            val count = getDeckCards(name).size
            val b = sectionButton("$name  •  $count karet", true)
            b.setOnClickListener { showDeck(name) }
            list.addView(b)
        }
        root.addView(list, (root.childCount - 1).coerceAtLeast(0))
    }

    private fun showDeckPicker(card: Card) {
        val dialog = Dialog(this)
        val root = darkDialogRoot()
        root.addView(dialogTitle("PŘIDAT DO BALÍČKU"))
        getDeckNames().sorted().forEach { name ->
            root.addView(sectionButton(name, true) { addCardToDeck(name, card); dialog.dismiss(); Toast.makeText(this, "Přidáno do balíčku $name", Toast.LENGTH_SHORT).show() })
        }
        root.addView(roundedButton("＋ NOVÝ BALÍČEK") {
            val input = EditText(this).apply { hint = "Název balíčku"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
            AlertDialogBuilder(dialog, input) { name ->
                if (name.isNotBlank()) { saveDeckNames(getDeckNames().toMutableSet().apply { add(name) }); addCardToDeck(name, card); dialog.dismiss() }
            }
        })
        root.addView(roundedButton("ZRUŠIT") { dialog.dismiss() })
        dialog.setContentView(root); dialog.show(); dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.88f).toInt(), (resources.displayMetrics.heightPixels * 0.70f).toInt())
    }

    private fun showDeck(name: String) {
        val dialog = Dialog(this)
        val root = darkDialogRoot()
        root.addView(dialogTitle(name))
        val filter = makeSpinner(arrayOf("Vše", "Pokémon", "Energie", "Item", "Trainer", "Oblíbené"))
        root.addView(filter)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val close = roundedButton("ZAVŘÍT") { dialog.dismiss() }
        root.addView(close)
        fun render() {
            content.removeAllViews()
            val ids = getDeckCards(name)
            var list = cards.filter { ids.contains(it.id) }
            list = when (filter.selectedItem.toString()) {
                "Pokémon" -> list.filter { it.category.equals("Pokémon", true) }
                "Energie" -> list.filter { it.category.equals("Energy", true) || it.category.equals("Energie", true) }
                "Item" -> list.filter { it.category.equals("Trainer", true) && it.trainerSubtype.equals("Item", true) }
                "Trainer" -> list.filter { it.category.equals("Trainer", true) && !it.trainerSubtype.equals("Item", true) }
                "Oblíbené" -> list.filter { isFavorite(it) }
                else -> list
            }
            renderCards(content, list.sortedBy { it.number })
        }
        filter.onItemSelected(render)
        dialog.setContentView(root); dialog.show(); dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), (resources.displayMetrics.heightPixels * 0.86f).toInt())
        render()
    }

    private fun getDeckNames(): Set<String> = prefs.getStringSet("deckNames", setOf("Můj balíček")) ?: setOf("Můj balíček")
    private fun saveDeckNames(names: Set<String>) { prefs.edit().putStringSet("deckNames", names).apply() }
    private fun getDeckCards(name: String): Set<String> = prefs.getStringSet("deck_$name", emptySet()) ?: emptySet()
    private fun addCardToDeck(name: String, card: Card) { prefs.edit().putStringSet("deck_$name", getDeckCards(name).toMutableSet().apply { add(card.id) }).apply() }

    private fun darkDialogRoot() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(Color.rgb(18,18,18)) }
    private fun dialogTitle(text: String) = TextView(this).apply { this.text = text; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(10)) }
    private fun roundedButton(text: String, action: (View) -> Unit): Button = Button(this).apply { this.text = text; isAllCaps = false; textSize = 15f; setTextColor(Color.WHITE); background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_button); setOnClickListener(action) }
    private fun sectionButton(text: String, bold: Boolean): Button = roundedButton(text) {}.apply { textSize = if (bold) 16f else 15f; setOnClickListener(null) }
    private fun makeSpinner(items: Array<String>): Spinner {
        val spinner = Spinner(this)
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View = TextView(this@MainActivity).apply { text = items[position]; setTextColor(Color.WHITE); textSize = 13f; setPadding(dp(8), dp(10), dp(8), dp(10)) }
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        return spinner
    }
    private fun Spinner.onItemSelected(action: () -> Unit) = setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener { override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = action(); override fun onNothingSelected(parent: AdapterView<*>?) {} })
    private fun ownedCount(setId: String) = cards.count { it.setId == setId && isOwned(it) }
    private fun setTotal(setId: String) = cards.count { it.setId == setId }
    private fun ownedCountGeneration(gen: Int) = cards.count { it.generation == gen && isOwned(it) }
    private fun totalGeneration(gen: Int) = cards.count { it.generation == gen }

    private fun AlertDialogBuilder(parent: Dialog, input: EditText, onOk: (String) -> Unit) {
        val d = android.app.AlertDialog.Builder(this).setTitle("Nový balíček").setView(input).setNegativeButton("ZRUŠIT", null).setPositiveButton("VYTVOŘIT") { _, _ -> onOk(input.text.toString().trim()) }.create()
        d.show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    override fun onDestroy() { scannerDialog?.dismiss(); executor.shutdown(); super.onDestroy() }
}
