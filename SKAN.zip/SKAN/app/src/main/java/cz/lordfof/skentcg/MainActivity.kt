package cz.lordfof.skan

import android.os.Bundle
import android.widget.*
import android.app.Activity
import java.security.MessageDigest

class MainActivity : Activity() {
    private val pokemon = listOf(
"Bulbasaur","Ivysaur","Venusaur","Charmander","Charmeleon","Charizard","Squirtle","Wartortle","Blastoise","Caterpie","Metapod","Butterfree","Weedle","Kakuna","Beedrill","Pidgey","Pidgeotto","Pidgeot","Rattata","Raticate","Spearow","Fearow","Ekans","Arbok","Pikachu","Raichu","Sandshrew","Sandslash","Nidoran♀","Nidorina","Nidoqueen","Nidoran♂","Nidorino","Nidoking","Clefairy","Clefable","Vulpix","Ninetales","Jigglypuff","Wigglytuff","Zubat","Golbat","Oddish","Gloom","Vileplume","Paras","Parasect","Venonat","Venomoth","Diglett","Dugtrio","Meowth","Persian","Psyduck","Golduck","Mankey","Primeape","Growlithe","Arcanine","Poliwag","Poliwhirl","Poliwrath","Abra","Kadabra","Alakazam","Machop","Machoke","Machamp","Bellsprout","Weepinbell","Victreebel","Tentacool","Tentacruel","Geodude","Graveler","Golem","Ponyta","Rapidash","Slowpoke","Slowbro","Magnemite","Magneton","Farfetch'd","Doduo","Dodrio","Seel","Dewgong","Grimer","Muk","Shellder","Cloyster","Gastly","Haunter","Gengar","Onix","Drowzee","Hypno","Krabby","Kingler","Voltorb","Electrode","Exeggcute","Exeggutor","Cubone","Marowak","Hitmonlee","Hitmonchan","Lickitung","Koffing","Weezing","Rhyhorn","Rhydon","Chansey","Tangela","Kangaskhan","Horsea","Seadra","Goldeen","Seaking","Staryu","Starmie","Mr. Mime","Scyther","Jynx","Electabuzz","Magmar","Pinsir","Tauros","Magikarp","Gyarados","Lapras","Ditto","Eevee","Vaporeon","Jolteon","Flareon","Porygon","Omanyte","Omastar","Kabuto","Kabutops","Aerodactyl","Snorlax","Articuno","Zapdos","Moltres","Dratini","Dragonair","Dragonite","Mewtwo","Mew")
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var card: TextView; private lateinit var collection: TextView
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
        prefs=getSharedPreferences("collection",0); card=findViewById(R.id.card); collection=findViewById(R.id.collection)
        findViewById<Button>(R.id.scan).setOnClickListener { val code=findViewById<EditText>(R.id.barcode).text.toString(); if(code.isBlank()) { Toast.makeText(this,"Zadej čárový kód",Toast.LENGTH_SHORT).show(); return@setOnClickListener }; showCard(code) }
        findViewById<Button>(R.id.clear).setOnClickListener { prefs.edit().clear().apply(); updateCollection() }
        updateCollection()
    }
    private fun index(code:String):Int { val d=MessageDigest.getInstance("SHA-256").digest(code.toByteArray()); var x=0L; for(i in 0..3) x=(x shl 8)+(d[i].toInt() and 255); return (x % 151).toInt() }
    private fun showCard(code:String){ val i=index(code); val num=i+1; val name=pokemon[i]; card.text="🎴\n$name\n\nPokémon #$num\nScarlet & Violet—151\nKarta $num/165\n\nČárový kód: $code\n\n✓ Automaticky přidáno do kolekce"; prefs.edit().putBoolean("$num",true).apply(); updateCollection() }
    private fun updateCollection(){ val owned=(1..151).filter{prefs.getBoolean("$it",false)}; collection.text="MOJE KOLEKCE (${owned.size}/151)\n\n"+if(owned.isEmpty())"Zatím žádné karty." else owned.joinToString("\n"){String.format("#%03d  %s  —  %d/165",it,pokemon[it-1],it)} }
}
