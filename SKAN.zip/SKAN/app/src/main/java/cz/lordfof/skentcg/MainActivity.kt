package cz.lordfof.skan

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private lateinit var preview: PreviewView
    private lateinit var cardImage: ImageView
    private lateinit var cardInfo: TextView
    private lateinit var collection: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private val scanning = AtomicBoolean(false)
    private val prefs by lazy { getSharedPreferences("collection", MODE_PRIVATE) }
    private lateinit var cards: List<Card>

    data class Card(val id:String,val number:Int,val name:String,val type:String,val imageLarge:String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        cards = loadCards()
        preview = findViewById(R.id.preview)
        cardImage = findViewById(R.id.cardImage)
        cardInfo = findViewById(R.id.cardInfo)
        collection = findViewById(R.id.collection)
        findViewById<Button>(R.id.scan).setOnClickListener { scanning.set(true); Toast.makeText(this,"Namiř kameru na EAN čárový kód",Toast.LENGTH_SHORT).show() }
        findViewById<Button>(R.id.clear).setOnClickListener { prefs.edit().clear().apply(); updateCollection() }
        updateCollection()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
    }

    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startCamera()
        else Toast.makeText(this,"Bez povolení kamery SKAN nemůže skenovat EAN kódy.",Toast.LENGTH_LONG).show()
    }

    private fun loadCards(): List<Card> {
        val root = JSONObject(assets.open("base1_cards.json").bufferedReader().use { it.readText() })
        val a = root.getJSONArray("cards")
        return (0 until a.length()).map { i ->
            val o=a.getJSONObject(i)
            Card(o.getString("id"),o.getInt("number"),o.getString("name"),o.getString("cardType"),o.getString("imageLarge"))
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider=future.get()
            val previewUseCase=Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(executor) { proxy ->
                val media=proxy.image
                if (media == null || !scanning.get()) { proxy.close(); return@setAnalyzer }
                val image=InputImage.fromMediaImage(media,proxy.imageInfo.rotationDegrees)
                BarcodeScanning.getClient().process(image)
                    .addOnSuccessListener { codes ->
                        val code=codes.firstOrNull { it.rawValue?.matches(Regex("[0-9]{8,14}")) == true }?.rawValue
                        if (code != null && scanning.compareAndSet(true,false)) runOnUiThread { showCard(code) }
                    }
                    .addOnCompleteListener { proxy.close() }
            }
            provider.unbindAll()
            provider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,previewUseCase,analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun showCard(ean:String) {
        val card=cards[deterministicIndex(ean)]
        prefs.edit().putBoolean(card.id,true).apply()
        Glide.with(this).load(card.imageLarge).into(cardImage)
        cardInfo.text="${card.name}\n${card.type}\nBase Set · ${card.number}/102\nEAN: $ean\n✓ Automaticky přidáno do kolekce"
        updateCollection()
    }

    private fun deterministicIndex(ean:String):Int {
        val digest=MessageDigest.getInstance("SHA-256").digest(ean.toByteArray(Charsets.UTF_8))
        var x=0L
        for (b in digest.take(8)) x=(x shl 8) or (b.toLong() and 255L)
        return Math.floorMod(x, cards.size.toLong()).toInt()
    }

    private fun updateCollection() {
        val owned=cards.filter { prefs.getBoolean(it.id,false) }
        collection.text="MOJE KOLEKCE (${owned.size}/${cards.size})\n\n" + if (owned.isEmpty()) "Zatím žádné karty." else owned.joinToString("\n") { String.format("#%03d  %s  —  %d/102",it.number,it.name,it.number) }
    }

    override fun onDestroy() { executor.shutdown(); super.onDestroy() }
}
