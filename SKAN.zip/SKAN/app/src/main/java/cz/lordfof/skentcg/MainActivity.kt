package cz.lordfof.skan

import android.Manifest
import android.app.Dialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    private lateinit var cardImage: ImageView
    private lateinit var cardInfo: TextView
    private lateinit var collectionButton: Button
    private val executor = Executors.newSingleThreadExecutor()
    private val scanning = AtomicBoolean(false)
    private val prefs by lazy { getSharedPreferences("collection", MODE_PRIVATE) }
    private lateinit var cards: List<Card>
    private var scannerDialog: Dialog? = null

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) openScannerDialog()
        else Toast.makeText(this, "Bez povolení kamery SKAN nemůže skenovat EAN kódy.", Toast.LENGTH_LONG).show()
    }

    data class Card(
        val id: String,
        val number: Int,
        val name: String,
        val type: String,
        val element: String,
        val stage: String,
        val evolvesFrom: String,
        val evolutionFamily: String,
        val evolutionOrder: Int,
        val category: String,
        val trainerSubtype: String,
        val energySubtype: String,
        val setId: String,
        val setName: String,
        val generation: Int,
        val imageSmall: String,
        val imageLarge: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        cards = loadCards()

        cardImage = findViewById(R.id.cardImage)
        cardInfo = findViewById(R.id.cardInfo)
        collectionButton = findViewById(R.id.collectionButton)

        findViewById<Button>(R.id.scan).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                openScannerDialog()
            } else {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
        collectionButton.setOnClickListener { showCollectionDialog() }
        updateCollectionButton()
    }

    private fun loadCards(): List<Card> {
        val result = mutableListOf<Card>()
        val files = assets.list("") ?: emptyArray()
        files.filter { it.endsWith("_cards.json") }.forEach { file ->
            val root = JSONObject(assets.open(file).bufferedReader().use { it.readText() })
            val setId = root.optString("setId", file.substringBefore("_cards.json"))
            val setName = root.optString("setName", setId)
            val defaultGeneration = root.optInt("generation", 1)
            val a = root.getJSONArray("cards")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val numberText = o.optString("number", (i + 1).toString())
                result += Card(
                    id = o.getString("id"),
                    number = numberText.toIntOrNull() ?: (i + 1),
                    name = o.getString("name"),
                    type = o.optString("cardType", "Karta"),
                    element = readTextOrArray(o, "element", "elements", "types"),
                    stage = o.optString("stage", o.optString("evolutionStage", "")),
                    evolvesFrom = o.optString("evolvesFrom", ""),
                    evolutionFamily = o.optString("evolutionFamily", ""),
                    evolutionOrder = o.optInt("evolutionOrder", 0),
                    category = o.optString("category", o.optString("cardType", "")),
                    trainerSubtype = o.optString("trainerSubtype", ""),
                    energySubtype = o.optString("energySubtype", ""),
                    setId = o.optString("setId", setId),
                    setName = o.optString("setName", setName),
                    generation = o.optInt("generation", defaultGeneration),
                    imageSmall = o.optString("imageSmall", o.optString("imageLarge")),
                    imageLarge = o.getString("imageLarge")
                )
            }
        }
        return result.sortedWith(compareBy<Card> { it.generation }.thenBy { it.setName }.thenBy { it.number })
    }

    private fun readTextOrArray(o: JSONObject, vararg keys: String): String {
        for (key in keys) {
            if (!o.has(key) || o.isNull(key)) continue
            val value = o.get(key)
            if (value is JSONArray) {
                return (0 until value.length()).joinToString(", ") { value.optString(it) }
            }
            val text = value.toString().trim()
            if (text.isNotEmpty()) return text
        }
        return ""
    }

    private fun openScannerDialog() {
        if (scannerDialog?.isShowing == true) return
        scanning.set(true)

        val dialog = Dialog(this)
        scannerDialog = dialog
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(245, 20, 20, 20))
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        root.addView(box, FrameLayout.LayoutParams(-1, -1))

        val title = TextView(this).apply {
            text = "SKAN !"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        box.addView(title, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val preview = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        box.addView(preview, LinearLayout.LayoutParams(dp(290), dp(290)).apply { gravity = Gravity.CENTER })

        val hint = TextView(this).apply {
            text = "Namiř čtvereček na EAN čárový kód"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        box.addView(hint, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        val close = Button(this).apply {
            text = "ZRUŠIT"
            setOnClickListener {
                scanning.set(false)
                dialog.dismiss()
            }
        }
        box.addView(close, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        dialog.setContentView(root)
        dialog.setCancelable(false)
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.90f).toInt(), (resources.displayMetrics.heightPixels * 0.76f).toInt())

        startCamera(preview, dialog)
    }

    private fun startCamera(preview: PreviewView, dialog: Dialog) {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor) { proxy ->
                    val media = proxy.image
                    if (media == null || !scanning.get()) {
                        proxy.close()
                        return@setAnalyzer
                    }
                    val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                    BarcodeScanning.getClient().process(image)
                        .addOnSuccessListener { codes ->
                            val code = codes.firstOrNull { it.rawValue?.matches(Regex("[0-9]{8,14}")) == true }?.rawValue
                            if (code != null && scanning.compareAndSet(true, false)) {
                                runOnUiThread {
                                    dialog.dismiss()
                                    scannerDialog = null
                                    showCard(code)
                                }
                            }
                        }
                        .addOnCompleteListener { proxy.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
                dialog.setOnDismissListener {
                    scanning.set(false)
                    provider.unbindAll()
                    scannerDialog = null
                }
            } catch (_: Exception) {
                scanning.set(false)
                dialog.dismiss()
                Toast.makeText(this, "Kameru se nepodařilo otevřít.", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun showCard(ean: String) {
        val card = cards[deterministicIndex(ean)]
        val now = System.currentTimeMillis()
        prefs.edit().putBoolean(card.id, true).putLong(foundAtKey(card.id), now).apply()
        Glide.with(this).load(card.imageLarge).into(cardImage)
        cardInfo.text = "${card.name}\n${card.type}\n${card.setName} · ${card.number}/${cards.count { it.setId == card.setId }}\nEAN: $ean\n✓ Automaticky přidáno do kolekce"
        updateCollectionButton()
    }

    private fun deterministicIndex(ean: String): Int {
        val digest = MessageDigest.getInstance("SHA-256").digest(ean.toByteArray(Charsets.UTF_8))
        var x = 0L
        for (b in digest.take(8)) x = (x shl 8) or (b.toLong() and 255L)
        return Math.floorMod(x, cards.size.toLong()).toInt()
    }

    private fun foundAtKey(id: String) = "foundAt_$id"
    private fun isOwned(card: Card) = prefs.getBoolean(card.id, false)

    private fun updateCollectionButton() {
        val owned = cards.count { isOwned(it) }
        collectionButton.text = "KOLEKCE  $owned/${cards.size}"
    }

    private fun showCollectionDialog() {
        val dialog = Dialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "MOJE KOLEKCE"
            textSize = 24f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(10))
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val filterRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val filterSpinner = makeSpinner(arrayOf("Nalezené", "Vše", "Element", "Energie", "Item", "Trainer"))
        val sortSpinner = makeSpinner(arrayOf("Datum nalezení", "Element", "Stadium vývoje", "Abecedy", "Pořadí na kartě"))
        filterRow.addView(filterSpinner, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        filterRow.addView(sortSpinner, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(filterRow)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val scroll = android.widget.ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })

        val close = Button(this).apply {
            text = "ZAVŘÍT"
            setOnClickListener { dialog.dismiss() }
        }
        root.addView(close, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val generations = cards.map { it.generation }.distinct().sorted()
        val singleSetOnly = cards.map { it.setId }.distinct().size == 1
        var selectedSet: String? = cards.firstOrNull()?.setId

        fun render() {
            content.removeAllViews()
            val filter = filterSpinner.selectedItem.toString()
            val sort = sortSpinner.selectedItem.toString()

            val visible = applyFilterAndSort(cards, selectedSet, filter, sort)
            if (singleSetOnly) {
                val set = cards.first()
                content.addView(sectionButton("${set.setName}  ${ownedCount(set.setId)}/${setTotal(set.setId)}", true) {})
                renderCards(content, visible)
                return
            }

            generations.forEach { generation ->
                val genSets = cards.filter { it.generation == generation }.distinctBy { it.setId }
                val header = sectionButton("Gen $generation  ${ownedCountGeneration(generation)}/${totalGeneration(generation)}", true) { }
                content.addView(header)
                val nested = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    visibility = if (generation == generations.first()) View.VISIBLE else View.GONE
                }
                header.setOnClickListener { nested.visibility = if (nested.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
                content.addView(nested)
                genSets.sortedBy { it.setName }.forEach { set ->
                    val setButton = sectionButton("${set.setName}  ${ownedCount(set.setId)}/${setTotal(set.setId)}", false) {
                        selectedSet = set.setId
                        render()
                    }
                    nested.addView(setButton)
                }
                if (generation == generations.first() && selectedSet == null) selectedSet = genSets.firstOrNull()?.setId
            }
            if (selectedSet != null) {
                val selectedTitle = TextView(this).apply {
                    text = "${cards.first { it.setId == selectedSet }.setName}"
                    textSize = 17f
                    setTextColor(Color.BLACK)
                    setPadding(dp(4), dp(8), dp(4), dp(4))
                }
                content.addView(selectedTitle)
                renderCards(content, visible)
            }
        }

        filterSpinner.setOnItemSelectedListener(simpleItemSelected { render() })
        sortSpinner.setOnItemSelectedListener(simpleItemSelected { render() })

        dialog.setContentView(root)
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), (resources.displayMetrics.heightPixels * 0.90f).toInt())
        render()
    }

    private fun makeSpinner(items: Array<String>): Spinner {
        val spinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        return spinner
    }

    private fun simpleItemSelected(action: () -> Unit) = object : android.widget.AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = action()
        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
    }

    private fun sectionButton(text: String, selected: Boolean, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = if (selected) 16f else 15f
        setOnClickListener { action() }
    }

    private fun ownedCount(setId: String) = cards.count { it.setId == setId && isOwned(it) }
    private fun setTotal(setId: String) = cards.count { it.setId == setId }
    private fun ownedCountGeneration(gen: Int) = cards.count { it.generation == gen && isOwned(it) }
    private fun totalGeneration(gen: Int) = cards.count { it.generation == gen }

    private fun applyFilterAndSort(source: List<Card>, setId: String?, filter: String, sort: String): List<Card> {
        var list = source.filter { setId == null || it.setId == setId }
        list = when (filter) {
            "Nalezené" -> list.filter { isOwned(it) }
            "Element" -> list.filter { it.category.equals("Pokémon", true) }
            "Energie" -> list.filter { it.category.equals("Energy", true) || it.category.equals("Energie", true) }
            "Item" -> list.filter { it.category.equals("Trainer", true) && it.trainerSubtype.equals("Item", true) }
            "Trainer" -> list.filter { it.category.equals("Trainer", true) && !it.trainerSubtype.equals("Item", true) }
            else -> list
        }
        return when (sort) {
            "Datum nalezení" -> list.sortedByDescending { prefs.getLong(foundAtKey(it.id), 0L) }
            "Element" -> list.sortedWith(compareBy<Card> { it.element.ifBlank { "~" } }.thenBy { it.evolutionFamily.ifBlank { it.name } }.thenBy { it.evolutionOrder }.thenBy { it.number })
            "Stadium vývoje" -> list.sortedWith(compareBy<Card> { it.evolutionFamily.ifBlank { "~" } }.thenBy { it.evolutionOrder }.thenBy { it.number })
            "Abecedy" -> list.sortedBy { it.name.lowercase() }
            else -> list.sortedBy { it.number }
        }
    }

    private fun renderCards(content: LinearLayout, setCards: List<Card>) {
        val grid = GridLayout(this).apply {
            columnCount = 3
            useDefaultMargins = true
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        setCards.forEach { card ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(3), dp(3), dp(8))
            }
            val image = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(96), dp(134))
                scaleType = ImageView.ScaleType.CENTER_CROP
                contentDescription = card.name
                alpha = if (isOwned(card)) 1f else 0.28f
                setOnClickListener { showCardViewer(card) }
            }
            Glide.with(this).load(card.imageSmall).into(image)
            tile.addView(image)
            tile.addView(TextView(this).apply {
                text = "#${card.number} ${if (isOwned(card)) "✓" else ""}"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.BLACK)
            })
            tile.setOnClickListener { showCardViewer(card) }
            grid.addView(tile, GridLayout.LayoutParams().apply {
                width = 0
                height = GridLayout.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            })
        }
        content.addView(grid)
    }

    private fun showCardViewer(card: Card) {
        val viewer = Dialog(this)
        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            isClickable = true
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = card.name
        }
        frame.addView(image, FrameLayout.LayoutParams(-1, -1).apply { setMargins(dp(16), dp(58), dp(16), dp(16)) })
        Glide.with(this).load(card.imageLarge).into(image)

        val back = Button(this).apply {
            text = "‹ ZPĚT"
            setOnClickListener { viewer.dismiss() }
        }
        frame.addView(back, FrameLayout.LayoutParams(dp(110), dp(52), Gravity.TOP or Gravity.START).apply { topMargin = dp(8); leftMargin = dp(8) })

        val info = TextView(this).apply {
            text = "${card.name}  •  ${card.setName} #${card.number}"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        frame.addView(info, FrameLayout.LayoutParams(-1, dp(52), Gravity.TOP).apply { topMargin = dp(8); leftMargin = dp(110); rightMargin = dp(8) })

        frame.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val edge = dp(70)
                if (event.x < edge || event.x > frame.width - edge) {
                    viewer.dismiss()
                    true
                } else false
            } else false
        }
        viewer.setContentView(frame)
        viewer.show()
        viewer.window?.setBackgroundDrawableResource(android.R.color.transparent)
        viewer.window?.setLayout((resources.displayMetrics.widthPixels * 0.96f).toInt(), (resources.displayMetrics.heightPixels * 0.94f).toInt())
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        scannerDialog?.dismiss()
        executor.shutdown()
        super.onDestroy()
    }
}
