package cz.lordfof.skan

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Dialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.*
import kotlin.math.abs
import kotlin.random.Random
import androidx.core.view.children
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    private lateinit var cardImage: ImageView
    private lateinit var cardName: TextView
    private lateinit var cardInfo: TextView
    private lateinit var cardSet: TextView
    private lateinit var collectionButton: Button
    private lateinit var decksButton: Button
    private lateinit var settingsButton: Button
    private lateinit var gameMenuButton: Button
    private lateinit var scanStyleButton: ScanStyleButton
    private lateinit var mainContent: LinearLayout
    private lateinit var homeUniverseLayer: FrameLayout
    private lateinit var lastCardPreview: LinearLayout
    private val executor = Executors.newSingleThreadExecutor()
    private val artworkExecutor = Executors.newSingleThreadExecutor()
    private val scanning = AtomicBoolean(false)
    private val barcodeScanner = BarcodeScanning.getClient()

    // Ochrana proti předčasnému/kolísavému přečtení EANu.
    // Kód musí být rozpoznán opakovaně jako stejný kód, jinak se sken nepřijme.
    private var candidateCode: String? = null
    private var candidateFormat: Int = -1
    private var candidateHits: Int = 0
    private var candidateStartedAt: Long = 0L
    private var candidateLastAt: Long = 0L
    private var candidateCenterX: Float = 0f
    private var candidateCenterY: Float = 0f
    private var candidateWidth: Float = 0f
    private val prefs by lazy { getSharedPreferences("collection", MODE_PRIVATE) }
    private lateinit var cards: List<Card>
    private var scannerDialog: Dialog? = null

    private val cameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openScannerDialog()
        else Toast.makeText(this, "Bez povolení kamery SKAN nemůže skenovat EAN kódy.", Toast.LENGTH_LONG).show()
    }

    data class Card(
        val id: String,
        val number: Int,
        val name: String,
        val type: String,
        val element: String,
        val stage: String,
        val evolvesFrom: String,
        val evolutionFamily: String,
        val evolutionOrder: Int,
        val category: String,
        val trainerSubtype: String,
        val energySubtype: String,
        val rarity: String,
        val rarityNumber: Int,
        val setId: String,
        val setName: String,
        val generation: Int,
        val imageSmall: String,
        val imageLarge: String,
        val scannable: Boolean = true
    )

    data class BrainrotStats(val hp: Int, val atk: Int, val def: Int, val spd: Int, val archetype: String, val ability: String)
    data class SkanItem(val id: String, val name: String, val rarity: String, val type: String, val power: Int, val description: String, val count: Int)
    data class SkanBoost(val id: String, val name: String, val scans: Int, val description: String, val rarity: String = "Běžný")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        cards = loadCards()

        cardImage = findViewById(R.id.cardImage)
        cardName = findViewById(R.id.cardName)
        cardInfo = findViewById(R.id.cardInfo)
        cardSet = findViewById(R.id.cardSet)
        collectionButton = findViewById(R.id.collectionButton)
        decksButton = findViewById(R.id.decksButton)
        settingsButton = findViewById(R.id.settingsButton)
        gameMenuButton = findViewById(R.id.gameMenuButton)
        mainContent = findViewById(R.id.mainContent)
        homeUniverseLayer = findViewById(R.id.homeUniverseLayer)
        lastCardPreview = findViewById(R.id.lastCardPreview)

        // Hlavní obrazovka je navigace mezi univerzy. Sken je globální:
        // při prvním skenu může styl SKAN! jemně ovlivnit šanci univerza; po uložení
        // má EAN jednu pevnou kartu a další skeny ji už nikdy nemění.
        cardImage.visibility = View.GONE
        lastCardPreview.visibility = View.GONE
        cardName.text = ""
        cardInfo.text = ""
        cardSet.text = ""

        scanStyleButton = findViewById(R.id.scan)
        scanStyleButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openScannerDialog()
            else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
        collectionButton.setOnClickListener { showCollectionUniversePicker() }
        decksButton.setOnClickListener { showDecksDialog() }
        settingsButton.setOnClickListener { showSettingsDialog() }
        gameMenuButton.setOnClickListener { showShopDialog() }
        gameMenuButton.text = "🛒"
        gameMenuButton.contentDescription = "Obchod"
        findViewById<Button>(R.id.activeBoostButton)?.setOnClickListener { showActiveBoostDialog() }
        refreshActiveBoostButton()
        updateCollectionButton()
        buildHomeUniverses()
    }

    private fun loadCards(): List<Card> {
        val result = mutableListOf<Card>()
        val files = assets.list("") ?: emptyArray()
        files.filter { it.endsWith("_cards.json") }.forEach { file ->
            val root = JSONObject(assets.open(file).bufferedReader().use { it.readText() })
            val setId = root.optString("setId", file.substringBefore("_cards.json"))
            val setName = root.optString("setName", setId)
            val defaultGeneration = root.optInt("generation", 1)
            val a = root.getJSONArray("cards")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val numberText = o.optString("number", (i + 1).toString())
                val rawRarity = o.optString("rarity", "Common")
                val normalizedRarity = if (setId.startsWith("brainrot_", true) && rawRarity.equals("Legendary", true)) {
                    val h = MessageDigest.getInstance("SHA-256").digest((o.getString("id") + ":legendary-convert").toByteArray())
                    if ((h[0].toInt() and 255) < 154) "Epic" else "Legendary"
                } else rawRarity
                result += Card(
                    id = o.getString("id"),
                    number = numberText.toIntOrNull() ?: (i + 1),
                    name = o.getString("name"),
                    type = o.optString("cardType", "Karta"),
                    element = readTextOrArray(o, "element", "elements", "types"),
                    stage = o.optString("stage", o.optString("evolutionStage", "")),
                    evolvesFrom = o.optString("evolvesFrom", ""),
                    evolutionFamily = o.optString("evolutionFamily", ""),
                    evolutionOrder = o.optInt("evolutionOrder", 0),
                    category = o.optString("category", o.optString("cardType", "")),
                    trainerSubtype = o.optString("trainerSubtype", ""),
                    energySubtype = o.optString("energySubtype", ""),
                    rarity = normalizedRarity,
                    rarityNumber = o.optInt("rarityNumber", rarityNumberFromName(normalizedRarity)),
                    setId = o.optString("setId", setId),
                    setName = o.optString("setName", setName),
                    generation = o.optInt("generation", defaultGeneration),
                    imageSmall = o.optString("imageSmall", o.optString("imageLarge")),
                    imageLarge = o.optString("imageLarge", ""),
                    scannable = o.optBoolean("scannable", true)
                )
            }
        }
        return result.sortedWith(compareBy<Card> { it.generation }.thenBy { it.setName }.thenBy { it.number })
    }

    private fun readTextOrArray(o: JSONObject, vararg keys: String): String {
        for (key in keys) {
            if (!o.has(key) || o.isNull(key)) continue
            val value = o.get(key)
            if (value is JSONArray) return (0 until value.length()).joinToString(", ") { value.optString(it) }
            val text = value.toString().trim()
            if (text.isNotEmpty()) return text
        }
        return ""
    }

    private data class Universe(
        val id: String,
        val title: String,
        val subtitle: String,
        val symbol: String,
        val colors: IntArray,
        val available: Boolean = false
    )

    private fun rarityDisplayName(rarity: String): String = when (rarity.lowercase()) {
        "common" -> "Běžný"
        "uncommon" -> "Neobyčejný"
        "rare" -> "Vzácný"
        "rare holo" -> "Vzácný Holo"
        "epic" -> "Epický"
        "legendary" -> "Legendární"
        else -> rarity
    }

    private fun rarityNumberFromName(rarity: String): Int = when (rarity.lowercase()) {
        "common" -> 2
        "uncommon" -> 4
        "rare" -> 6
        "rare holo" -> 8
        "legendary" -> 10
        "epic" -> 10
        else -> 4
    }

    private fun isBrainrot(card: Card): Boolean = card.setId.startsWith("brainrot_", true)

    private fun brainrotCardView(card: Card, width: Int, height: Int, interactive: Boolean = true, allowRemote: Boolean = true, navigationCards: List<Card> = cards.filter { it.setId == card.setId }): FrameLayout {
        val frame = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(35, 35, 42), Color.rgb(10, 10, 14))).apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(3), rarityFrameColor(card.rarity))
            }
            // Dekorativní PNG rámeček se vykreslí přes celý card frame; jeho průhledné
            // okno nechává artwork pod ním viditelný.
            clipToOutline = true
            elevation = dp(5).toFloat()
            if (interactive) setOnClickListener { showCardViewer(card, navigationCards) }
        }
        // Keep the artwork wholly inside the transparent opening of the rarity frame.
        // Insets are proportional to the source frame, so its 2:3 aspect ratio is preserved.
        val innerLeft = (width * 0.115f).toInt()
        val innerRight = (width * 0.115f).toInt()
        val innerTop = (height * 0.115f).toInt()
        val innerBottom = (height * 0.115f).toInt()
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(20, 20, 24))
            contentDescription = card.name
        }
        frame.addView(image, FrameLayout.LayoutParams(-1, -1).apply {
            leftMargin = innerLeft; rightMargin = innerRight
            topMargin = innerTop; bottomMargin = innerBottom
        })
        if (card.scannable && card.imageLarge.isNotBlank()) {
            val cached = cachedArtworkFile(card)
            if (cached != null) {
                Glide.with(this).load(cached)
                    .error(artworkFallback(card))
                    .into(image)
            } else if (allowRemote || isOwned(card)) {
                // Načti i file:///android_asset přes AssetManager; Glide neumí
                // tyto URI spolehlivě vykreslit ve velkém detailu.
                loadCardArtwork(image, card.imageLarge, artworkFallback(card))
            } else {
                image.setImageResource(artworkFallback(card))
            }
        } else {
            image.setImageResource(artworkFallback(card))
        }

        // Nenalezené karty zobrazují ztmavený artwork; název a údaje zůstávají čitelné uvnitř rámečku.
        if (!isOwned(card)) {
            image.alpha = 0.28f
            frame.addView(View(this).apply { setBackgroundColor(Color.argb(145, 0, 0, 0)) }, FrameLayout.LayoutParams(-1, -1))
        }

        val topShade = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(185,0,0,0), Color.TRANSPARENT))
        }
        frame.addView(topShade, FrameLayout.LayoutParams(-1, (height * 0.18f).toInt(), Gravity.TOP).apply { leftMargin = innerLeft; rightMargin = innerRight; topMargin = innerTop })

        val number = TextView(this).apply {
            text = "#${card.number}"
            textSize = 13f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setShadowLayer(5f, 1f, 1f, Color.BLACK)
            setPadding(dp(9), dp(6), 0, 0)
        }
        frame.addView(number, FrameLayout.LayoutParams(dp(75), dp(40), Gravity.TOP or Gravity.START).apply { leftMargin = innerLeft; topMargin = innerTop })

        val rarity = TextView(this).apply {
            text = card.rarityNumber.toString()
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(rarityFrameColor(card.rarity))
                setStroke(dp(1), Color.argb(180,255,255,255))
            }
        }
        frame.addView(rarity, FrameLayout.LayoutParams(dp(38), dp(38), Gravity.TOP or Gravity.END).apply {
            topMargin = innerTop + dp(7); rightMargin = innerRight + dp(7)
        })

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(9))
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.argb(220,0,0,0), Color.TRANSPARENT))
        }
        bottom.addView(TextView(this).apply {
            text = card.name
            textSize = if (width < dp(180)) 13f else 18f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(-1, -2))
        bottom.addView(TextView(this).apply {
            text = "${rarityDisplayName(card.rarity)}  •  ${rarityDropPercent(card.rarity, isBrainrot(card))}"
            textSize = if (width < dp(180)) 10f else 12f
            setTextColor(Color.LTGRAY)
        }, LinearLayout.LayoutParams(-1, -2))
        frame.addView(bottom, FrameLayout.LayoutParams(-1, dp(if (width < dp(180)) 55 else 76), Gravity.BOTTOM).apply { leftMargin = innerLeft; rightMargin = innerRight; bottomMargin = innerBottom })
        addRarityArtworkFrame(frame, card.rarity)
        frame.layoutParams = LinearLayout.LayoutParams(width, height)
        return frame
    }

    private fun rarityFrameColor(rarity: String): Int = when (rarity.lowercase()) {
        "common" -> Color.rgb(150, 92, 48)
        "uncommon" -> Color.rgb(65, 165, 95)
        "rare", "rare holo" -> Color.rgb(105, 190, 235)
        "epic" -> Color.rgb(150, 80, 210)
        "legendary" -> Color.rgb(245, 175, 35)
        else -> Color.rgb(125, 125, 135)
    }

    private fun rarityFrameResource(rarity: String): Int = when (rarity.lowercase()) {
        "common" -> R.drawable.rarity_frame_common
        "uncommon" -> R.drawable.rarity_frame_uncommon
        "rare", "rare holo" -> R.drawable.rarity_frame_rare
        "epic" -> R.drawable.rarity_frame_epic
        "legendary" -> R.drawable.rarity_frame_legendary
        else -> R.drawable.rarity_frame_common
    }

    private fun addRarityArtworkFrame(target: FrameLayout, rarity: String) {
        target.addView(ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            setImageResource(rarityFrameResource(rarity))
            contentDescription = "Rámeček rarity ${rarityDisplayName(rarity)}"
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }, FrameLayout.LayoutParams(-1, -1))
    }

    private fun rarityStrokeDrawable(rarity: String, radiusDp: Int = 14, strokeDp: Int = 3): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(strokeDp), rarityFrameColor(rarity))
        }

    // Domov má nyní pouze dvě aktivní kolekce. Ostatní univerza zůstávají v datech,
    // ale nejsou zobrazována v hlavní nabídce.
    private fun universeCatalog(): List<Universe> = listOf(
        Universe("pokemon", "POKÉMON", "Karty a sbírky", "⚡", intArrayOf(Color.rgb(35, 60, 130), Color.rgb(150, 25, 45)), true),
        Universe("brainrot", "BRAINROT", "Chaos a memy", "◉", intArrayOf(Color.rgb(80, 30, 110), Color.rgb(190, 65, 125)), true)
    )

    private fun buildHomeUniverses() {
        val root = findViewById<FrameLayout>(R.id.homeUniverseLayer) ?: return
        root.removeAllViews()

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setPadding(dp(8), dp(12), dp(8), dp(120))
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            clipToPadding = false
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        content.addView(TextView(this).apply {
            text = "🪙 SKAN Coins: ${coins()}"
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, dp(8))
        }, LinearLayout.LayoutParams(-1, -2))

        universeCatalog().forEach { universe ->
            val tile = createHomeImageTile(universe)
            tile.setOnClickListener { showUniverseMenu(universe) }
            content.addView(tile, LinearLayout.LayoutParams(-1, dp(218)).apply {
                setMargins(dp(4), dp(5), dp(4), dp(5))
            })
        }

        scroll.addView(content, FrameLayout.LayoutParams(-1, -2))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
    }

    private fun createHomeImageTile(universe: Universe): View = FrameLayout(this).apply {
        background = GradientDrawable().apply {
            cornerRadius = dp(24).toFloat()
            setColor(Color.BLACK)
            setStroke(dp(2), Color.rgb(255, 205, 20))
        }
        clipToOutline = true
        elevation = dp(4).toFloat()
        addView(ImageView(this@MainActivity).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageResource(if (universe.id == "pokemon") R.drawable.home_tile_pokemon else R.drawable.home_tile_brainrot)
        }, FrameLayout.LayoutParams(-1, -1))
        addView(View(this@MainActivity).apply { setBackgroundColor(Color.argb(25, 0, 0, 0)) }, FrameLayout.LayoutParams(-1, -1))
        val collected = ownedCountForUniverse(universe.id)
        val total = totalCountForUniverse(universe.id)
        addView(TextView(this@MainActivity).apply {
            text = "NASBÍRÁNO  $collected / $total KARET"
            textSize = 13f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.argb(235, 0, 0, 0))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(2), Color.rgb(255, 205, 20))
            }
            setPadding(dp(12), dp(7), dp(12), dp(7))
            elevation = dp(12).toFloat()
            contentDescription = "Nasbíráno $collected z $total karet"
        }, FrameLayout.LayoutParams(-2, dp(38), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(10) })
    }

    private fun coins(): Int = prefs.getInt("skanCoins", 0)
    private fun addCoins(amount: Int) { prefs.edit().putInt("skanCoins", (coins()+amount).coerceAtLeast(0)).apply(); refreshHomeRewards() }
    private fun refreshHomeRewards() { buildHomeUniverses() }
    private fun actionRewardTile(title: String, subtitle: String): View = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(dp(8),dp(8),dp(8),dp(8))
        background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(28,30,38),Color.rgb(12,13,18))).apply{cornerRadius=dp(18).toFloat();setStroke(dp(1),Color.rgb(70,74,88))}
        addView(TextView(this@MainActivity).apply{text=title;textSize=17f;setTextColor(Color.WHITE);setTypeface(typeface,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER})
        addView(TextView(this@MainActivity).apply{text=subtitle;textSize=10f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER})
    }

    private fun brainrotStats(card: Card): BrainrotStats {
        val h=MessageDigest.getInstance("SHA-256").digest(("stats:"+card.id).toByteArray())
        fun b(i:Int)=h[i].toInt() and 255
        val archetype=when(b(0)%4){0->"Útočník";1->"Tank";2->"Rychlík";else->"Vyvážený"}
        val mult=when(card.rarity.lowercase()){"common"->1.0;"uncommon"->1.12;"rare"->1.28;"epic"->1.48;"legendary"->1.72;else->1.0}
        var hp=(70+b(1)%51)*mult; var atk=(12+b(2)%15)*mult; var def=(8+b(3)%13)*mult; var spd=(8+b(4)%13)*mult
        when(archetype){"Útočník"->atk*=1.18;"Tank"->{hp*=1.22;def*=1.18;spd*=0.88};"Rychlík"->{spd*=1.25;atk*=0.94};}
        val ability=when(archetype){"Útočník"->"Zuřivý úder";"Tank"->"Neprůstřelný pancíř";"Rychlík"->"Bleskový tah";else->"Chaosový balans"}
        return BrainrotStats(hp.toInt(),atk.toInt(),def.toInt(),spd.toInt(),archetype,ability)
    }

    private fun itemList(): MutableList<SkanItem> {
        val raw=prefs.getString("skanItems","[]") ?: "[]"; val a=JSONArray(raw); val out=mutableListOf<SkanItem>()
        for(i in 0 until a.length()){val o=a.getJSONObject(i);out+=SkanItem(o.getString("id"),o.getString("name"),o.getString("rarity"),o.getString("type"),o.getInt("power"),o.getString("description"),o.getInt("count"))}; return out
    }
    private fun saveItems(items:List<SkanItem>){val a=JSONArray();items.forEach{a.put(JSONObject().apply{put("id",it.id);put("name",it.name);put("rarity",it.rarity);put("type",it.type);put("power",it.power);put("description",it.description);put("count",it.count)})};prefs.edit().putString("skanItems",a.toString()).apply()}
    private fun addItem(item:SkanItem){val l=itemList();val i=l.indexOfFirst{it.id==item.id};if(i>=0)l[i]=l[i].copy(count=l[i].count+1) else l.add(item);saveItems(l)}
    private fun boostList(): MutableList<SkanBoost> { val a=JSONArray(prefs.getString("skanBoosts","[]") ?: "[]");val o=mutableListOf<SkanBoost>();for(i in 0 until a.length()){val x=a.getJSONObject(i);o+=SkanBoost(x.getString("id"),x.getString("name"),x.getInt("scans"),x.getString("description"),x.optString("rarity","Běžný"))};return o }
    private fun saveBoosts(l:List<SkanBoost>){val a=JSONArray();l.forEach{a.put(JSONObject().apply{put("id",it.id);put("name",it.name);put("scans",it.scans);put("description",it.description);put("rarity",it.rarity)})};prefs.edit().putString("skanBoosts",a.toString()).apply()}
    private fun addBoost(id:String,name:String,scans:Int,desc:String,rarity:String="Běžný"){val l=boostList();val i=l.indexOfFirst{it.id==id};if(i>=0)l[i]=l[i].copy(scans=l[i].scans+scans)else l.add(SkanBoost(id,name,scans,desc,rarity));saveBoosts(l)}

    private fun rarityFromBucket(bucket:Int): String = when { bucket < 6000 -> "Běžný"; bucket < 8000 -> "Neobyčejný"; bucket < 9200 -> "Vzácný"; bucket < 9800 -> "Epický"; else -> "Legendární" }
    private fun rewardCoinsForRarity(rarity:String): Int = when(rarity.lowercase()){ "běžný","common"->1; "neobyčejný","uncommon"->5; "vzácný","rare"->10; "vzácný holo","rare holo"->10; "epický","epic"->25; "legendární","legendary"->75; else->1 }
    private fun eventChance(seed:String, basisPoints:Int):Boolean { val d=MessageDigest.getInstance("SHA-256").digest(seed.toByteArray()); val b=((d[0].toInt() and 255) shl 8) or (d[1].toInt() and 255); return b%10000 < basisPoints }
    private fun randomRewardForSeed(seed:String): Pair<String,Any?> {
        val d=MessageDigest.getInstance("SHA-256").digest(seed.toByteArray()); val b=d[2].toInt() and 255
        val rarity=rarityFromBucket((((d[3].toInt() and 255)*256)+(d[4].toInt() and 255))%10000)
        return when(b%3){
            0 -> "item" to SkanItem("item_${seed.hashCode()}", listOf("Plazmová čepel","Energetický štít","Regenerační ampule","Reroll token")[b%4], rarity, listOf("Zbraň","Štít","Heal","Reroll")[b%4], 8+(d[5].toInt() and 15), "Předmět získaný událostí.", 1)
            1 -> "ability" to SkanItem("ability_${seed.hashCode()}", listOf("Zuřivý úder","Pancéřová bariéra","Bleskový tah","Chaosový svitek")[b%4], rarity, "Schopnost", 8+(d[5].toInt() and 12), "Svitková schopnost pro Brainrota, maximálně 3 použití.", 3)
            else -> { val id=when(b%3){0->"luck";1->"brainrot";else->"rare"}; val name=when(id){"luck"->"Luck Boost";"brainrot"->"Brainrot Boost";else->"Rare Boost"}; "boost" to SkanBoost(id,name,3,"Dočasný bonus drop rate.",rarity) }
        }
    }
    private fun grantEventReward(seed:String, chanceBasisPoints:Int=2500): String {
        if(!eventChance(seed,chanceBasisPoints)) return ""
        val r=randomRewardForSeed(seed); when(r.first){"item","ability"->addItem(r.second as SkanItem);"boost"->{val b=r.second as SkanBoost;addBoost(b.id,b.name,b.scans,b.description,b.rarity)}}; return r.first
    }

    private fun itemFromEan(ean:String): SkanItem? { val r=MessageDigest.getInstance("SHA-256").digest(("item:"+ean).toByteArray()); if((r[0].toInt() and 255)>=205)return null; return randomRewardForSeed("item:$ean").second as? SkanItem }

    private fun showItemsDialog(){val d=Dialog(this);val root=darkDialogRoot();root.addView(dialogTitle("🎒 ITEMY  •  ${itemList().sumOf{it.count}}"));val l=itemList();if(l.isEmpty())root.addView(sectionButton("Zatím nemáš žádné itemy.",true));else l.sortedByDescending{raritySortRank(it.rarity)}.forEach{root.addView(sectionButton("${it.name}  •  ${it.rarity}  •  ×${it.count}\n${it.type} — ${it.description}",true))};root.addView(roundedButton("ZAVŘÍT"){d.dismiss()});d.setContentView(root);d.show();styleDialogWindow(d,.90f,.78f)}
    private fun showBoostsDialog(){val d=Dialog(this);val root=darkDialogRoot();root.addView(dialogTitle("🍀 BOOSTY"));val l=boostList();if(l.isEmpty())root.addView(sectionButton("Žádné aktivní boosty.",true));l.forEach{b->val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};row.addView(sectionButton("${b.name}  •  ${b.scans} skenů\n${b.description}",true),LinearLayout.LayoutParams(0,-2,1f));val use=roundedButton("AKTIVOVAT"){activateBoost(b.id,d)};row.addView(use,LinearLayout.LayoutParams(dp(120),-2));root.addView(row)};root.addView(roundedButton("ZAVŘÍT"){d.dismiss()});d.setContentView(root);d.show();styleDialogWindow(d,.94f,.78f)}
    private fun activateBoost(id:String,d:Dialog){if(activeBoostId().isNotBlank()&&activeBoostScans()>0){Toast.makeText(this,"Už máš aktivní boost. Nejprve ho dokonči.",Toast.LENGTH_SHORT).show();return};val l=boostList();val i=l.indexOfFirst{it.id==id};if(i<0)return;val b=l[i];prefs.edit().putString("activeBoost",b.id).putInt("activeBoostScans",b.scans).apply();l.removeAt(i);saveBoosts(l);refreshActiveBoostButton();Toast.makeText(this,"Aktivní boost: ${b.name} • ${b.scans} skenů",Toast.LENGTH_SHORT).show();d.dismiss()}
    private fun activeBoostId(): String = prefs.getString("activeBoost", "") ?: ""
    private fun activeBoostScans(): Int = prefs.getInt("activeBoostScans", 0)
    private fun consumeActiveBoost(){ val n=activeBoostScans(); if(n<=1) prefs.edit().remove("activeBoost").putInt("activeBoostScans",0).apply() else prefs.edit().putInt("activeBoostScans",n-1).apply(); refreshActiveBoostButton() }

    private fun activeBoostBonus(): Int = when(activeBoostId()){ "luck"->5; "brainrot"->10; "rare"->5; else->0 }
    private fun showActiveBoostDialog(){ val d=Dialog(this); val root=darkDialogRoot(); val id=activeBoostId(); if(id.isBlank()||activeBoostScans()<=0){root.addView(dialogTitle("🍀 ŽÁDNÝ AKTIVNÍ BOOST"));root.addView(sectionButton("Vyber boost v Obchodě nebo Inventáři.",true))}else{root.addView(dialogTitle("🍀 AKTIVNÍ BOOST"));val name=when(id){"luck"->"Luck Boost";"brainrot"->"Brainrot Boost";"rare"->"Rare Boost";else->id};root.addView(sectionButton("$name\nÚčinek: +${activeBoostBonus()} procentních bodů\nZbývá: ${activeBoostScans()} skenů",true));root.addView(sectionButton("Brainrot: Běžný ${effectiveBrainrotRates()[0]}% • Neobyčejný ${effectiveBrainrotRates()[1]}% • Vzácný ${effectiveBrainrotRates()[2]}% • Epický ${effectiveBrainrotRates()[3]}% • Legendární ${effectiveBrainrotRates()[4]}%",false));root.addView(sectionButton("Pokémon: Běžný ${effectivePokemonRates()[0]}% • Neobyčejný ${effectivePokemonRates()[1]}% • Vzácný ${effectivePokemonRates()[2]}% • Ultra ${effectivePokemonRates()[3]}%",false))};root.addView(roundedButton("ZAVŘÍT"){d.dismiss()});d.setContentView(root);d.show();styleDialogWindow(d,.86f,.55f)}
    private fun effectiveBrainrotRates(): IntArray { val bonus=activeBoostBonus(); if(activeBoostId()=="rare"||activeBoostId()=="luck"){ val r=intArrayOf(60,20,12,6,2); r[0]-=bonus; r[2]+=bonus/2; r[3]+=bonus/3; r[4]+=bonus-(bonus/2+bonus/3); return r }; if(activeBoostId()=="brainrot") return intArrayOf(60,20,12,6,2); return intArrayOf(60,20,12,6,2) }
    private fun effectivePokemonRates(): IntArray { val bonus=activeBoostBonus(); if(activeBoostId()=="rare"||activeBoostId()=="luck"){ val r=intArrayOf(75,17,6,2); r[0]-=bonus; r[2]+=bonus/2; r[3]+=bonus-(bonus/2); return r }; return intArrayOf(75,17,6,2) }
    private fun teamIds(): MutableList<String> = prefs.getString("brainrotTeam","[]")?.let{raw->try{val a=JSONArray(raw);MutableList(a.length()){a.getString(it)}}catch(_:Exception){mutableListOf()}} ?: mutableListOf()
    private fun saveTeam(ids:List<String>){val a=JSONArray();ids.take(3).forEach{a.put(it)};prefs.edit().putString("brainrotTeam",a.toString()).apply()}
    private fun addToTeam(card:Card){if(!isBrainrot(card)||!isOwned(card)){Toast.makeText(this,"Do týmu lze přidat jen nalezený Brainrot.",Toast.LENGTH_SHORT).show();return};val t=teamIds();if(card.id in t){Toast.makeText(this,"Brainrot už v týmu je.",Toast.LENGTH_SHORT).show();return};if(t.size>=3){Toast.makeText(this,"Tým už má 3 Brainroty.",Toast.LENGTH_SHORT).show();return};t.add(card.id);saveTeam(t);Toast.makeText(this,"${card.name} přidán do týmu.",Toast.LENGTH_SHORT).show()}
    private fun equippedItemId(card:Card):String = prefs.getString("equip_${card.id}","") ?: ""
    private fun equipItemToCard(card:Card,item:SkanItem){ prefs.edit().putString("equip_${card.id}",item.id).apply(); Toast.makeText(this,"${item.name} vybaven na ${card.name}.",Toast.LENGTH_SHORT).show() }
    private fun showTeamDialog(){val d=Dialog(this);val root=darkDialogRoot();root.addView(dialogTitle("♟ TÝM • ${teamIds().size}/3"));teamIds().forEachIndexed{i,id->cards.find{it.id==id}?.let{c->val eq=equippedItemId(c);root.addView(sectionButton("${i+1}. ${c.name} • ${rarityDisplayName(c.rarity)}\nVybaveno: ${itemList().find{x->x.id==eq}?.name ?: "nic"}",true));val equip=roundedButton("🎒 VYBAVIT ITEM / SVITEK"){val it=itemList().firstOrNull();if(it==null)Toast.makeText(this,"Nemáš item ani svitek.",Toast.LENGTH_SHORT).show()else equipItemToCard(c,it)};root.addView(equip)}};if(teamIds().isEmpty())root.addView(sectionButton("Přidej 3 Brainroty přes + Přidat do týmu.",false));root.addView(roundedButton("VYČISTIT TÝM"){saveTeam(emptyList());d.dismiss()});root.addView(roundedButton("ZAVŘÍT"){d.dismiss()});d.setContentView(root);d.show();styleDialogWindow(d,.9f,.78f)}

    private fun showTrainingDuelDialog(){
        val team = teamIds().mapNotNull { id -> cards.find { it.id == id && isBrainrot(it) && isOwned(it) } }
        if (team.size < 3) { Toast.makeText(this,"Pro Training Duel potřebuješ 3 nalezené Brainroty v týmu.",Toast.LENGTH_LONG).show(); return }
        showDuelDialog(team[0], team[1], true)
    }
    private fun showDuelDialog(player:Card,enemy:Card,training:Boolean){
        if(teamIds().size<3){ Toast.makeText(this,"Pro souboj potřebuješ 3 Brainroty v týmu.",Toast.LENGTH_SHORT).show(); return }
        val d=Dialog(this)
        val root=darkDialogRoot()
        root.addView(dialogTitle(if(training)"⚔ TRAINING DUEL" else "⚔ EAN DUEL"))

        var ph=brainrotStats(player).hp
        var eh=brainrotStats(enemy).hp
        var turnPlayer=true
        val status=TextView(this).apply{
            setTextColor(Color.WHITE); textSize=14f; gravity=Gravity.CENTER
            setPadding(dp(6),dp(4),dp(6),dp(4))
        }

        fun battleCard(card:Card, hpProvider:()->Int, alignEnd:Boolean): LinearLayout {
            val row=LinearLayout(this).apply{
                orientation=LinearLayout.HORIZONTAL
                gravity=if(alignEnd) Gravity.END else Gravity.START
                setPadding(dp(4),dp(2),dp(4),dp(2))
            }
            val image=ImageView(this).apply{ scaleType=ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.rgb(18,18,22)) }
            val imageWrap=FrameLayout(this).apply{
                background=rarityStrokeDrawable(card.rarity,14,3)
                setPadding(dp(3),dp(3),dp(3),dp(3))
            }
            imageWrap.addView(image,FrameLayout.LayoutParams(dp(122),dp(170)))
            val cached=cachedArtworkFile(card)
            if(cached!=null) loadCardArtwork(image,cached) else loadCardArtwork(image,card.imageLarge)

            val stats=LinearLayout(this).apply{
                orientation=LinearLayout.VERTICAL
                gravity=if(alignEnd) Gravity.END else Gravity.START
                setPadding(dp(8),dp(5),dp(8),dp(5))
            }
            val st=brainrotStats(card)
            stats.addView(TextView(this).apply{
                text=card.name; textSize=15f; setTextColor(Color.WHITE); setTypeface(typeface,android.graphics.Typeface.BOLD)
                gravity=if(alignEnd) Gravity.END else Gravity.START; maxLines=2; ellipsize=android.text.TextUtils.TruncateAt.END
            })
            stats.addView(TextView(this).apply{
                text="HP ${hpProvider()} / ${st.hp}\nATK ${st.atk}  •  DEF ${st.def}\nSPD ${st.spd}\n${st.archetype}\n${st.ability}"
                textSize=11f; setTextColor(Color.LTGRAY)
                gravity=if(alignEnd) Gravity.END else Gravity.START
            })
            if(alignEnd){ row.addView(stats,LinearLayout.LayoutParams(dp(170),-2)); row.addView(imageWrap) }
            else { row.addView(imageWrap); row.addView(stats,LinearLayout.LayoutParams(dp(170),-2)) }
            return row
        }

        val enemyRow=battleCard(enemy,{eh},true)
        val playerRow=battleCard(player,{ph},false)
        root.addView(TextView(this).apply{ text="SOUPEŘ".replace(" ",""); textSize=11f; setTextColor(Color.LTGRAY); gravity=Gravity.END; setPadding(0,dp(1),dp(8),0) },LinearLayout.LayoutParams(-1,-2))
        root.addView(enemyRow,LinearLayout.LayoutParams(-1,dp(180)))
        root.addView(status,LinearLayout.LayoutParams(-1,dp(46)))
        root.addView(TextView(this).apply{ text="TY"; textSize=11f; setTextColor(Color.LTGRAY); gravity=Gravity.START; setPadding(dp(8),dp(1),0,0) },LinearLayout.LayoutParams(-1,-2))
        root.addView(playerRow,LinearLayout.LayoutParams(-1,dp(180)))

        fun render(){ status.text="${if(turnPlayer)"TVŮJ TAH" else "TAH SOUPEŘE"}   •   ${player.name}: $ph HP   •   ${enemy.name}: $eh HP" }
        fun finishIfDone():Boolean{
            if(eh<=0||ph<=0){
                val reward=if(eh<=0){if(training)1 else 100}else{if(training)0 else -10}
                addCoins(reward)
                if(!training&&eh<=0) grantEventReward("duel:${player.id}:${enemy.id}:${System.currentTimeMillis()}",25)
                if(training&&eh<=0) grantEventReward("training-duel:${player.id}:${System.currentTimeMillis()}",250)
                Toast.makeText(this,"${if(eh<=0)"VÝHRA" else "PROHRA"} • ${if(reward>=0)"+" else ""}$reward Coins",Toast.LENGTH_LONG).show()
                d.dismiss(); return true
            }
            return false
        }
        fun enemyTurn(){
            if(eh<=0||ph<=0)return
            val es=brainrotStats(enemy); val ps=brainrotStats(player); val roll=Random.nextInt(1,21); val mode=Random.nextInt(100)
            if(mode<15&&itemList().isNotEmpty()){ val it=itemList().first(); if(it.type=="Zbraň") ph-=(it.power+roll/2) else if(it.type=="Heal") eh+=(it.power/2).coerceAtMost(es.hp-eh) else ph-=(it.power/2) }
            else if(mode<25) eh-=(es.spd/2+roll/2)
            else if(mode<32) ph-=(es.atk+Random.nextInt(4,11))
            else ph-=(es.atk+roll-ps.def/2).coerceAtLeast(1)
            turnPlayer=true; render(); finishIfDone()
        }
        fun endPlayerTurn(){ turnPlayer=false; render(); if(!finishIfDone()) root.postDelayed({enemyTurn()},850) }
        fun playerAttack(){
            if(!turnPlayer)return
            val ps=brainrotStats(player); val es=brainrotStats(enemy); val roll=Random.nextInt(1,21)
            eh-=(ps.atk+roll-es.def/2).coerceAtLeast(1); endPlayerTurn()
        }
        val attack=roundedButton("⚔ ZAÚTOČIT"){playerAttack()}
        attack.textSize=13f
        root.addView(attack,LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(4)})
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        fun smallAction(label:String,click:()->Unit){
            val b=roundedButton(label){click()}; b.textSize=11f; b.setPadding(dp(2),0,dp(2),0)
            actions.addView(b,LinearLayout.LayoutParams(0,dp(44),1f).apply{setMargins(dp(2),dp(3),dp(2),0)})
        }
        smallAction("🎒 ITEM"){ 
            if(!turnPlayer)return@smallAction
            val it=itemList().firstOrNull()
            if(it==null) Toast.makeText(this,"Nemáš item.",Toast.LENGTH_SHORT).show()
            else { val l=itemList(); val idx=l.indexOfFirst{x->x.id==it.id}; l[idx]=it.copy(count=it.count-1); if(l[idx].count<=0)l.removeAt(idx); saveItems(l); if(it.type=="Zbraň")eh-=(it.power+Random.nextInt(1,7)) else if(it.type=="Heal")ph+=(it.power*3).coerceAtMost(brainrotStats(player).hp-ph) else eh-=(it.power/2); endPlayerTurn() }
        }
        smallAction("🍀 BOOST"){ if(!turnPlayer)return@smallAction; val b=boostList().firstOrNull(); if(b==null)Toast.makeText(this,"Nemáš boost.",Toast.LENGTH_SHORT).show() else {activateBoost(b.id,d); endPlayerTurn()} }
        smallAction("✨ SCHOPNOST"){ 
            if(!turnPlayer)return@smallAction
            val it=itemList().firstOrNull{x->x.type=="Schopnost"}
            if(it==null) Toast.makeText(this,"Nemáš svitek schopnosti.",Toast.LENGTH_SHORT).show()
            else { val l=itemList(); val idx=l.indexOfFirst{x->x.id==it.id}; l[idx]=it.copy(count=it.count-1); if(l[idx].count<=0)l.removeAt(idx); saveItems(l); eh-=(it.power+Random.nextInt(1,7)); endPlayerTurn() }
        }
        root.addView(actions,LinearLayout.LayoutParams(-1,dp(50)))
        val close=roundedButton("ZAVŘÍT"){d.dismiss()}; close.textSize=12f
        root.addView(close,LinearLayout.LayoutParams(-1,dp(44)).apply{topMargin=dp(2)})
        render(); d.setContentView(root); d.show(); styleDialogWindow(d,.96f,.90f)
    }

    private fun showMemoryDialog(){
        val d=Dialog(this)
        val root=darkDialogRoot()
        root.addView(dialogTitle("🃏 TRAINING PEXESO"))
        val pool=cards.filter{isBrainrot(it)&&it.scannable}.shuffled().take(10)
        if(pool.size<10){
            root.addView(sectionButton("Pro Training Pexeso není dostupných 10 Brainrotů.",true))
            root.addView(roundedButton("ZAVŘÍT"){d.dismiss()})
            d.setContentView(root); d.show(); styleDialogWindow(d,.94f,.62f); return
        }
        val values=(0 until 10).flatMap{listOf(it,it)}.shuffled()
        val grid=GridLayout(this).apply{columnCount=4;useDefaultMargins=false}
        var opened=-1; var matches=0; var lives=10
        val cells=ArrayList<FrameLayout>()
        var livesLabel: TextView? = null
        fun updateLivesLabel(){ livesLabel?.text="Životy: $lives / 10 • Dvojice: $matches / 10" }
        fun showBack(cell:FrameLayout){
            cell.removeAllViews()
            cell.background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(48,25,65),Color.rgb(105,30,95))).apply{cornerRadius=dp(10).toFloat();setStroke(dp(1),Color.rgb(255,210,31))}
            cell.addView(TextView(this).apply{text="🧠\nBRAINROT";textSize=12f;setTextColor(Color.rgb(255,210,31));gravity=Gravity.CENTER;setTypeface(typeface,android.graphics.Typeface.BOLD)},FrameLayout.LayoutParams(-1,-1))
        }
        fun showFace(cell:FrameLayout,index:Int){
            val card=pool[values[index]]
            cell.removeAllViews(); cell.background=GradientDrawable().apply{cornerRadius=dp(10).toFloat();setStroke(dp(2),Color.rgb(255,210,31))}
            val image=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_CROP}
            cell.addView(image,FrameLayout.LayoutParams(-1,-1))
            loadCardArtwork(image,card.imageLarge.ifBlank{card.imageSmall})
            cell.addView(TextView(this).apply{text=card.name;setTextColor(Color.WHITE);textSize=10f;gravity=Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL;setTypeface(typeface,android.graphics.Typeface.BOLD);setShadowLayer(4f,0f,1f,Color.BLACK);setPadding(dp(2),0,dp(2),dp(3))},FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM))
        }
        fun resetUnmatched(a:Int,b:Int){
            grid.postDelayed({ if(cells[a].tag=="open" && cells[b].tag=="open"){showBack(cells[a]);showBack(cells[b]);cells[a].tag=null;cells[b].tag=null};opened=-1 },650)
        }
        values.forEachIndexed{idx,_ ->
            val cell=FrameLayout(this)
            cell.tag=null
            showBack(cell)
            cell.setOnClickListener{
                if(cell.tag=="matched" || cell.tag=="open") return@setOnClickListener
                cell.tag="open"; showFace(cell,idx)
                if(opened<0){opened=idx}
                else if(values[opened]==values[idx]){
                    cell.tag="matched";cells[opened].tag="matched";matches++;opened=-1
                    if(matches==10){
                        addCoins(1)
                        val reward = grantEventReward("training-memory:${System.currentTimeMillis()}",250)
                        val rewardText = if(reward.isNotBlank()) " + náhodný drop" else ""
                        Toast.makeText(this@MainActivity,"Training Pexeso vyhráno! +1 Coin$rewardText",Toast.LENGTH_LONG).show()
                        d.dismiss()
                    }
                } else {
                    lives--
                    updateLivesLabel()
                    Toast.makeText(this@MainActivity,"Chyba • životy: $lives",Toast.LENGTH_SHORT).show()
                    val first=opened; val second=idx
                    if(lives<=0){
                        Toast.makeText(this@MainActivity,"Training Pexeso prohráno.",Toast.LENGTH_LONG).show()
                        d.dismiss()
                    } else resetUnmatched(first,second)
                }
            }
            cells.add(cell)
            grid.addView(cell,GridLayout.LayoutParams().apply{width=0;height=dp(78);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(dp(3),dp(3),dp(3),dp(3))})
        }
        livesLabel = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize=15f
            gravity=Gravity.CENTER
            setPadding(dp(8),dp(6),dp(8),dp(10))
        }
        updateLivesLabel()
        root.addView(sectionButton("Najdi 10 dvojic • 20 karet • otočení vždy ukáže Brainrota",false))
        root.addView(livesLabel!!, LinearLayout.LayoutParams(-1,-2))
        root.addView(grid)
        root.addView(roundedButton("ZAVŘÍT"){d.dismiss()})
        d.setContentView(root);d.show();styleDialogWindow(d,.98f,.90f)
    }

    private fun showEanMemoryDialog(){
        val d=Dialog(this);val root=darkDialogRoot();root.addView(dialogTitle("🃏 EAN PEXESO"));val pool=cards.filter{isBrainrot(it)&&it.scannable}.shuffled().take(10);if(pool.size<10){root.addView(sectionButton("Není dost Brainrotů pro EAN Pexeso.",true));root.addView(roundedButton("ZAVŘÍT"){d.dismiss()});d.setContentView(root);d.show();styleDialogWindow(d,.9f,.55f);return};val vals=(0 until 10).flatMap{listOf(it,it)}.shuffled();val grid=GridLayout(this).apply{columnCount=4};var opened=-1;var matches=0;var lives=10;val buttons=ArrayList<Button>();fun reset(){buttons.forEach{it.text="🧠";it.tag=null};opened=-1};vals.forEachIndexed{idx,v->val b=Button(this).apply{text="🧠";setTextColor(Color.WHITE);setOnClickListener{if(tag!=null||idx==opened)return@setOnClickListener;tag=v;text=pool[v].name.take(6);if(opened<0)opened=idx else if(vals[opened]==v){matches++;if(matches==10){addCoins(75);grantEventReward("ean-memory:${System.currentTimeMillis()}",25);Toast.makeText(this@MainActivity,"EAN Pexeso vyhráno +75 Coins",Toast.LENGTH_LONG).show();d.dismiss()}}else{lives--;if(lives<=0)d.dismiss()else grid.postDelayed({reset()},550)}}};buttons.add(b);grid.addView(b,GridLayout.LayoutParams().apply{width=0;height=dp(64);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)})};root.addView(grid);root.addView(sectionButton("Najdi všech 10 dvojic • životy: 10",false));root.addView(roundedButton("ZAVŘÍT"){d.dismiss()});d.setContentView(root);d.show();styleDialogWindow(d,.96f,.90f)}

    private fun createUniverseTile(universe: Universe): View {
        val tile = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, universe.colors).apply {
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.argb(85, 255, 255, 255))
            }
            elevation = dp(3).toFloat()
            clipToOutline = true
        }

        val imageRes = when (universe.id.lowercase()) {
            "pokemon" -> R.drawable.universe_pokemon_tile
            "starwars" -> R.drawable.universe_starwars_tile
            "brainrot" -> R.drawable.universe_brainrot_tile
            "hotwheels" -> R.drawable.universe_hotwheels_tile
            else -> 0
        }
        if (imageRes != 0) {
            tile.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setImageResource(imageRes)
                adjustViewBounds = true
            }, FrameLayout.LayoutParams(-1, -1))
        } else {
            val glow = TextView(this).apply {
                text = universe.symbol
                textSize = 50f
                setTextColor(Color.argb(105, 255, 255, 255))
                gravity = Gravity.CENTER
            }
            tile.addView(glow, FrameLayout.LayoutParams(-1, -1))
        }
        // Postup sbírky přímo na hlavní dlaždici: unikátní karty / celkový počet.
        val owned = ownedCountForUniverse(universe.id)
        val total = totalCountForUniverse(universe.id)
        val countBadge = TextView(this).apply {
            text = "$owned / $total"
            textSize = 16f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(2), dp(10), dp(2))
            background = GradientDrawable().apply {
                setColor(Color.argb(215, 0, 0, 0))
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.argb(160, 255, 255, 255))
            }
            elevation = dp(8).toFloat()
        }
        tile.addView(countBadge, FrameLayout.LayoutParams(-2, dp(34), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            setMargins(dp(10), 0, dp(10), dp(8))
        })
        // Badge musí být vždy nad obrázkem dlaždice.
        countBadge.bringToFront()
        return tile
    }

    private fun cardsForUniverse(universeId: String): List<Card> = when (universeId.lowercase()) {
        "pokemon" -> cards.filter { it.setId.startsWith("base1", true) }
        "starwars" -> cards.filter { it.setId.startsWith("sw_", true) }
        "brainrot" -> cards.filter { it.setId.startsWith("brainrot_", true) }
        "hotwheels" -> cards.filter { it.setId.startsWith("hotwheels_", true) }
        "animals" -> cards.filter { it.setId.startsWith("animals_", true) }
        "monsters" -> cards.filter { it.setId.startsWith("monsters_", true) }
        "vehicles" -> cards.filter { it.setId.startsWith("vehicles_", true) }
        "everything" -> cards
        else -> emptyList()
    }

    private fun ownedCountForUniverse(universeId: String): Int {
        val ownedIds = scanMap().values.toSet()
        return cardsForUniverse(universeId).count { it.id in ownedIds || prefs.getBoolean(it.id, false) }
    }

    private fun totalCountForUniverse(universeId: String): Int = cardsForUniverse(universeId).size

        private fun installBlankSpaceBack(scroll: ScrollView, action: () -> Unit) {
        var downX = 0f
        var downY = 0f
        fun clickableHit(view: View, rawX: Float, rawY: Float): Boolean {
            if (view !== scroll && view.isClickable) {
                val rect = android.graphics.Rect()
                view.getGlobalVisibleRect(rect)
                if (rect.contains(rawX.toInt(), rawY.toInt())) return true
            }
            if (view is android.view.ViewGroup) {
                for (i in 0 until view.childCount) {
                    if (clickableHit(view.getChildAt(i), rawX, rawY)) return true
                }
            }
            return false
        }
        scroll.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY }
                MotionEvent.ACTION_UP -> {
                    val moved = kotlin.math.abs(event.rawX - downX) > dp(12) || kotlin.math.abs(event.rawY - downY) > dp(12)
                    if (!moved && !clickableHit(scroll, event.rawX, event.rawY)) {
                        action()
                    }
                }
            }
            false
        }
    }

    private fun showUniverseMenu(universe: Universe) {
        val dialog = Dialog(this)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        val scroll = ScrollView(this).apply { setPadding(dp(14), dp(22), dp(14), dp(90)) }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = universe.title
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setShadowLayer(6f, 1f, 1f, Color.BLACK)
            setPadding(0, dp(8), 0, dp(14))
        }
        content.addView(title, LinearLayout.LayoutParams(-1, -2))
        val grid = GridLayout(this).apply { columnCount = 2; useDefaultMargins = false }
        // Rozložení Brainrot menu: Kolekce přes celý řádek, poté Týmy/Předměty,
        // Schopnosti/Boosty a nakonec Training Duel/Pexeso. EAN Duel zde nemá duplicitní dlaždici.
        val actions = if (universe.id == "brainrot") listOf(
            Triple("collection", "KOLEKCE", "▦"),
            Triple("teams", "TÝMY", "♟"), Triple("items", "PŘEDMĚTY", "🎒"),
            Triple("abilities", "SCHOPNOSTI", "✨"), Triple("boosts", "BOOSTY", "🍀"),
            Triple("training", "TRAINING DUEL", "⚔"), Triple("memory", "TRAINING PEXESO", "🃏")
        ) else listOf(Triple("collection", "KOLEKCE", "▦"), Triple("teams", "TÝMY", "♟"), Triple("duel", "EAN DUEL", "⚔"))
        actions.forEach { (id, label, symbol) ->
            val tile = createActionTile(label, symbol, universe)
            tile.setOnClickListener {
                when (id) {
                    "collection" -> { showCollectionDialog(universe) }
                    "packs" -> { dialog.dismiss(); Toast.makeText(this, "Balíčky pro ${universe.title} budou v další části.", Toast.LENGTH_SHORT).show() }
                    "teams" -> { dialog.dismiss(); showTeamDialog() }
                    "items" -> { dialog.dismiss(); showItemsDialog() }
                    "boosts" -> { dialog.dismiss(); showBoostsDialog() }
                    "abilities" -> { dialog.dismiss(); showItemsDialog() }
                    "training" -> { dialog.dismiss(); showTrainingDuelDialog() }
                    "memory" -> { dialog.dismiss(); showMemoryDialog() }
                    "duel" -> { dialog.dismiss(); if(teamIds().size>=3) showDuelDialog(cards.find{it.id==teamIds()[0]} ?: cards.first(), cards.first{isBrainrot(it)&&it.id !in teamIds()}, false) else Toast.makeText(this,"Pro EAN Duel potřebuješ 3 Brainroty v týmu.",Toast.LENGTH_SHORT).show() }
                }
            }
            grid.addView(tile, GridLayout.LayoutParams().apply {
                width = 0; height = dp(126)
                columnSpec = if (universe.id == "brainrot" && id == "collection") GridLayout.spec(0, 2, 1f) else GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(6), dp(6), dp(6), dp(6))
            })
        }
        content.addView(grid, LinearLayout.LayoutParams(-1, -2))
        scroll.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        installBlankSpaceBack(scroll) { dialog.dismiss() }
        dialog.setContentView(root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.attributes = dialog.window?.attributes?.apply { dimAmount = 0.78f }
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun rarityDropPercent(rarity: String, brainrot: Boolean = false): String {
        val rates=if(brainrot) effectiveBrainrotRates() else effectivePokemonRates()
        val idx=if(brainrot) when(rarity.lowercase()){"common"->0;"uncommon"->1;"rare"->2;"epic"->3;"legendary"->4;else->-1} else when(rarity.lowercase()){"common"->0;"uncommon"->1;"rare"->2;"rare holo"->3;else->-1}
        return if(idx>=0) "${rates[idx]}%" else "—"
    }

    private fun addLockedCardOverlay(frame: FrameLayout, width: Int) {
        val lock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        lock.addView(TextView(this@MainActivity).apply {
            text = "🔒"
            textSize = if (width < dp(180)) 28f else 42f
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        lock.addView(TextView(this@MainActivity).apply {
            text = "NENASKENOVÁNO"
            textSize = if (width < dp(180)) 11f else 15f
            setTextColor(Color.rgb(255,210,31))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        frame.addView(lock, FrameLayout.LayoutParams(-1, -1))
    }

    private fun createBrainrotCollectionTile(universe: Universe): View {
        return FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, universe.colors).apply {
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.argb(90, 255, 255, 255))
            }
            elevation = dp(3).toFloat()
            clipToOutline = true
            addView(ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setImageResource(R.drawable.universe_brainrot_tile)
            }, FrameLayout.LayoutParams(-1, -1))
            addView(View(this@MainActivity).apply {
                setBackgroundColor(Color.argb(55, 0, 0, 0))
            }, FrameLayout.LayoutParams(-1, -1))
            addView(TextView(this@MainActivity).apply {
                text = "BRAINROT"
                textSize = 22f
                setTextColor(Color.WHITE)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                setShadowLayer(6f, 1f, 1f, Color.BLACK)
            }, FrameLayout.LayoutParams(-1, -1))
        }
    }

    private fun createActionTile(label: String, symbol: String, universe: Universe): View {
        val artwork = when (label) {
            "KOLEKCE" -> R.drawable.home_tile_collection
            "TÝMY" -> R.drawable.home_tile_teams
            "PŘEDMĚTY" -> R.drawable.home_tile_items
            "BOOSTY" -> R.drawable.home_tile_boosts
            "SCHOPNOSTI" -> R.drawable.home_tile_abilities
            "TRAINING DUEL", "EAN DUEL" -> R.drawable.home_tile_training_duel
            "TRAINING PEXESO" -> R.drawable.home_tile_training_memory
            else -> if (universe.id == "pokemon") R.drawable.home_tile_pokemon else R.drawable.home_tile_brainrot
        }
        return FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(universe.colors[0], universe.colors[1])).apply {
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.argb(150, 255, 205, 20))
            }
            clipToOutline = true
            elevation = dp(3).toFloat()
            addView(ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setImageResource(artwork)
                contentDescription = label
            }, FrameLayout.LayoutParams(-1, -1))
            addView(View(this@MainActivity).apply {
                setBackgroundColor(Color.argb(32, 0, 0, 0))
            }, FrameLayout.LayoutParams(-1, -1))
        }
    }

    private fun openScannerDialog() {
        if (scannerDialog?.isShowing == true) return
        resetScanCandidate()
        scanning.set(true)
        val dialog = Dialog(this)
        scannerDialog = dialog
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_dialog)
        }
        val preview = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(preview, LinearLayout.LayoutParams(dp(290), dp(290)).apply { gravity = Gravity.CENTER })
        root.addView(TextView(this).apply {
            text = "Namiř čtvereček na EAN čárový kód"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        root.addView(roundedButton("ZRUŠIT") { scanning.set(false); dialog.dismiss() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        dialog.setContentView(root)
        dialog.setCancelable(false)
        dialog.show()
        styleDialogWindow(dialog, 0.90f, 0.76f)
        startCamera(preview, dialog)
    }

    private fun startCamera(preview: PreviewView, dialog: Dialog) {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(executor) { proxy ->
                    val media = proxy.image
                    if (media == null || !scanning.get()) { proxy.close(); return@setAnalyzer }
                    val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                    barcodeScanner.process(image)
                        .addOnSuccessListener { codes ->
                            if (!scanning.get()) return@addOnSuccessListener

                            // Přijímáme jen skutečné EAN/UPC formáty a platný kontrolní součet.
                            // Když je v záběru více kódů, dáme přednost největšímu a nejcentrálnějšímu.
                            val candidate = codes
                                .mapNotNull { barcode ->
                                    val normalized = normalizeEan(barcode) ?: return@mapNotNull null
                                    val box = barcode.boundingBox
                                    if (box == null) return@mapNotNull null
                                    val centerX = (box.left + box.right) / 2f
                                    val centerY = (box.top + box.bottom) / 2f
                                    val area = box.width().toFloat() * box.height().toFloat()
                                    val frameCenter = image.width / 2f
                                    val centerDistance = kotlin.math.abs(centerX - frameCenter)
                                    Triple(barcode, normalized, area - centerDistance * 150f)
                                }
                                .maxByOrNull { it.third }

                            if (candidate == null) {
                                resetScanCandidate()
                            } else {
                                val barcode = candidate.first
                                val code = candidate.second
                                if (registerScanCandidate(code, barcode)) {
                                    if (scanning.compareAndSet(true, false)) {
                                        runOnUiThread {
                                            dialog.dismiss()
                                            scannerDialog = null
                                            showScanResult(code)
                                        }
                                    }
                                }
                            }
                        }
                        .addOnCompleteListener { proxy.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
                dialog.setOnDismissListener { scanning.set(false); provider.unbindAll(); scannerDialog = null }
            } catch (_: Exception) {
                scanning.set(false); dialog.dismiss(); Toast.makeText(this, "Kameru se nepodařilo otevřít.", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun normalizeEan(barcode: Barcode): String? {
        val raw = barcode.rawValue?.filter(Char::isDigit) ?: return null
        val normalized = when (barcode.format) {
            Barcode.FORMAT_EAN_13 -> if (raw.length == 13) raw else return null
            Barcode.FORMAT_EAN_8 -> if (raw.length == 8) raw else return null
            Barcode.FORMAT_UPC_A -> if (raw.length == 12) "0$raw" else return null
            else -> return null
        }
        return if (hasValidEanChecksum(normalized)) normalized else null
    }

    private fun hasValidEanChecksum(code: String): Boolean {
        if (code.length != 8 && code.length != 13) return false
        val digits = code.map { it - '0' }
        var sum = 0
        for (i in 0 until digits.lastIndex) {
            val positionFromRight = digits.lastIndex - i
            sum += if (positionFromRight % 2 == 1) digits[i] * 3 else digits[i]
        }
        val check = (10 - (sum % 10)) % 10
        return check == digits.last()
    }

    private fun registerScanCandidate(code: String, barcode: Barcode): Boolean {
        val now = System.currentTimeMillis()
        val box = barcode.boundingBox
        val centerX = box?.let { (it.left + it.right) / 2f } ?: 0f
        val centerY = box?.let { (it.top + it.bottom) / 2f } ?: 0f
        val width = box?.width()?.toFloat() ?: 0f

        val sameCandidate = candidateCode == code && candidateFormat == barcode.format
        val withinTime = candidateLastAt == 0L || now - candidateLastAt <= 700L
        val stablePosition = if (sameCandidate && candidateWidth > 0f && width > 0f) {
            val widthRatio = width / candidateWidth
            val positionOk = kotlin.math.abs(centerX - candidateCenterX) <= candidateWidth * 0.45f &&
                    kotlin.math.abs(centerY - candidateCenterY) <= candidateWidth * 0.70f
            positionOk && widthRatio in 0.55f..1.80f
        } else {
            true
        }

        if (sameCandidate && withinTime && stablePosition) {
            candidateHits += 1
        } else {
            candidateCode = code
            candidateFormat = barcode.format
            candidateHits = 1
            candidateStartedAt = now
        }

        candidateLastAt = now
        candidateCenterX = centerX
        candidateCenterY = centerY
        if (width > 0f) candidateWidth = width

        // Čtyři po sobě jdoucí stabilní snímky stejného EANu = potvrzený sken.
        return candidateHits >= 4 && now - candidateStartedAt <= 1500L
    }

    private fun resetScanCandidate() {
        candidateCode = null
        candidateFormat = -1
        candidateHits = 0
        candidateStartedAt = 0L
        candidateLastAt = 0L
        candidateCenterX = 0f
        candidateCenterY = 0f
        candidateWidth = 0f
    }

    private fun showScanResult(ean: String) {
        // První sken EANu použije právě zvolený SKAN! pouze jako jemnou preferenci univerza.
        // Jakmile je karta pro EAN jednou uložena, už se nikdy nemění a všechny další skeny
        // stejného EANu dostanou přesně tutéž kartu bez ohledu na zvolený styl tlačítka.
        val alreadyThisBarcode = hasScannedBarcode(ean)
        val card = if (alreadyThisBarcode) {
            deterministicCardForEan(ean, null)
        } else {
            deterministicCardForEan(ean, scanStyleButton.selectedStyleId())
        }
        if (!alreadyThisBarcode) {
            saveScan(ean, card)
            addCoins(rewardCoinsForRarity(card.rarity))
            grantEventReward("ean-reward:$ean",25)
            if (activeBoostScans() > 0) consumeActiveBoost()
            val duelRoll = MessageDigest.getInstance("SHA-256").digest(("duel:"+ean).toByteArray())[0].toInt() and 255
            if (duelRoll < 31 && isBrainrot(card) && teamIds().size >= 3) {
                val enemies = cards.filter { isBrainrot(it) && it.id != card.id && it.scannable }
                if (enemies.isNotEmpty()) card.let { showDuelDialog(it, enemies[(duelRoll and 255) % enemies.size], false) }
            } else if (duelRoll in 31..45) { showEanMemoryDialog() }
        }
        cacheCardArtwork(card)

        updateMainCard(card)
        updateCollectionButton()
        showUnifiedScanDialog(card, alreadyThisBarcode)
        if (homeUniverseLayer.visibility == View.VISIBLE) buildHomeUniverses()
        refreshActiveBoostButton()
    }

    private fun showUnifiedScanDialog(card: Card, duplicateBarcode: Boolean) {
        val dialog = Dialog(this)
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(18,20,27), Color.rgb(7,8,12))).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.rgb(65,70,82))
            }
        }
        panel.addView(TextView(this).apply {
            text = if (duplicateBarcode) "UŽ MÁŠ TUTO KARTU" else "NOVÁ KARTA!"
            textSize = 24f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val cardFrame = FrameLayout(this).apply {
            background = rarityStrokeDrawable(card.rarity, 16, 4)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            clipToOutline = true
            if (duplicateBarcode) alpha = 0.32f
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(12,12,16))
            contentDescription = card.name
        }
        cardFrame.addView(image, FrameLayout.LayoutParams(-1, -1))
        val cached = cachedArtworkFile(card)
        if (cached != null) loadCardArtwork(image, cached) else if (card.imageLarge.isNotBlank()) loadCardArtwork(image, card.imageLarge)
        val top = TextView(this).apply {
            text = "#${card.number}"
            textSize = 16f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setShadowLayer(5f, 1f, 1f, Color.BLACK)
            setPadding(dp(10), dp(8), 0, 0)
        }
        cardFrame.addView(top, FrameLayout.LayoutParams(dp(90), dp(42), Gravity.TOP or Gravity.START))
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(9))
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.argb(225,0,0,0), Color.TRANSPARENT))
        }
        bottom.addView(TextView(this).apply {
            text = card.name
            textSize = 17f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(-1, -2))
        bottom.addView(TextView(this).apply {
            text = "${rarityDisplayName(card.rarity)}  •  ${rarityDropPercent(card.rarity, isBrainrot(card))}"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, -2))
        cardFrame.addView(bottom, FrameLayout.LayoutParams(-1, dp(64), Gravity.BOTTOM))
        panel.addView(cardFrame, LinearLayout.LayoutParams(dp(250), dp(355)).apply { gravity = Gravity.CENTER; bottomMargin = dp(12) })
        panel.addView(TextView(this).apply {
            text = card.name
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        panel.addView(TextView(this).apply {
            text = if (isBrainrot(card)) { val s=brainrotStats(card); "${card.type}  •  #${card.number}  •  ${rarityDisplayName(card.rarity)}  •  ${rarityDropPercent(card.rarity, true)}  •  HP ${s.hp}  ATK ${s.atk}  DEF ${s.def}  SPD ${s.spd}" } else "${card.type}  •  #${card.number}  •  ${rarityDisplayName(card.rarity)}  •  ${rarityDropPercent(card.rarity, false)}"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(10))
        }, LinearLayout.LayoutParams(-1, -2))
        panel.addView(roundedButton("POKRAČOVAT") { dialog.dismiss() }, LinearLayout.LayoutParams(-1, -2))
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        dialog.setContentView(root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.attributes = dialog.window?.attributes?.apply { dimAmount = 0.82f }
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun showBrainrotScanDialog(card: Card, duplicateBarcode: Boolean) {
        val dialog = Dialog(this)
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(18,20,27), Color.rgb(7,8,12))).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.rgb(65,70,82))
            }
        }
        panel.addView(TextView(this).apply {
            text = if (duplicateBarcode) "UŽ MÁŠ TUTO KARTU" else "NOVÁ KARTA!"
            textSize = 24f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        val cardView = brainrotCardView(card, dp(250), dp(355), false)
        if (duplicateBarcode) {
            cardView.alpha = 0.32f
        }
        panel.addView(cardView, LinearLayout.LayoutParams(dp(250), dp(355)).apply { gravity = Gravity.CENTER; bottomMargin = dp(12) })
        panel.addView(TextView(this).apply {
            text = card.name; textSize = 21f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        panel.addView(TextView(this).apply {
            text = "YumCut Brainrot  •  #${card.number}  •  Rarita ${card.rarityNumber}/8"
            textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(10))
        }, LinearLayout.LayoutParams(-1, -2))
        val close = roundedButton("POKRAČOVAT") { dialog.dismiss() }
        panel.addView(close, LinearLayout.LayoutParams(-1, -2))
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        dialog.setContentView(root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.attributes = dialog.window?.attributes?.apply { dimAmount = 0.82f }
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun artworkCacheDir(): File = File(filesDir, "artwork_cache").apply { mkdirs() }

    private fun artworkCacheFile(card: Card): File {
        val hash = MessageDigest.getInstance("SHA-256")
            .digest(card.id.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return File(artworkCacheDir(), "$hash.img")
    }

    private fun cachedArtworkFile(card: Card): File? {
        val file = artworkCacheFile(card)
        return if (file.isFile && file.length() > 1024L) file else null
    }

    private fun artworkFallback(card: Card): Int =
        if (isBrainrot(card)) R.drawable.universe_brainrot_tile else R.drawable.universe_pokemon_tile

    private fun loadCardArtwork(imageView: ImageView, source: String, fallbackRes: Int = R.drawable.universe_brainrot_tile) {
        if (source.startsWith("file:///android_asset/")) {
            val path = source.removePrefix("file:///android_asset/")
            try {
                assets.open(path).use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream)
                    if (bitmap != null) {
                        imageView.setImageBitmap(bitmap)
                        return
                    }
                }
            } catch (_: Exception) { }
            imageView.setImageResource(fallbackRes)
            return
        }
        Glide.with(this).load(source)
            .placeholder(fallbackRes)
            .error(fallbackRes)
            .into(imageView)
    }

    private fun loadCardArtwork(imageView: ImageView, file: File, fallbackRes: Int = R.drawable.universe_brainrot_tile) {
        Glide.with(this).load(file).placeholder(fallbackRes).error(fallbackRes).into(imageView)
    }

    private fun cacheCardArtwork(card: Card) {
        val source = card.imageLarge
        if (!source.startsWith("http://") && !source.startsWith("https://")) return
        val target = artworkCacheFile(card)
        if (target.isFile && target.length() > 1024L) return

        artworkExecutor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(source).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 12000
                    instanceFollowRedirects = true
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "SKAN/1.0")
                }
                if (connection.responseCode in 200..299) {
                    val tmp = File(target.parentFile, target.name + ".tmp")
                    connection.inputStream.use { input ->
                        FileOutputStream(tmp).use { output -> input.copyTo(output) }
                    }
                    if (tmp.length() > 1024L) {
                        if (target.exists()) target.delete()
                        tmp.renameTo(target)
                    } else tmp.delete()
                }
            } catch (_: Exception) {
                File(target.parentFile, target.name + ".tmp").delete()
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun updateMainCard(card: Card) {
        if (card.imageLarge.isBlank()) {
            Glide.with(this).clear(cardImage)
            cardImage.setImageDrawable(null)
            cardImage.contentDescription = "Skutečná karta: ${card.name}"
        } else {
            val cached = cachedArtworkFile(card)
            if (cached != null) loadCardArtwork(cardImage, cached) else loadCardArtwork(cardImage, card.imageLarge)
        }
        cardName.text = card.name
        cardInfo.text = card.type
        cardSet.text = "${card.setName} · ${card.number}/${cards.count { it.setId == card.setId }}"
    }

    private fun showMainScanResult(card: Card, duplicateBarcode: Boolean) {
        homeUniverseLayer.visibility = View.VISIBLE
        lastCardPreview.visibility = View.VISIBLE
        cardImage.visibility = View.VISIBLE
        cardImage.translationX = 0f
        cardImage.alpha = if (duplicateBarcode) 0.32f else 1f
        cardName.alpha = 1f
        cardInfo.alpha = 1f
        cardSet.alpha = 1f
        cardInfo.text = if (duplicateBarcode) "JIŽ NASKENOVÁNO" else "Poslední naskenovaná karta"
        cardName.text = card.name
        cardSet.text = "${if(isBrainrot(card))"BRAINROT" else card.setName} · #${card.number}/${cards.count { it.setId == card.setId }}"
        cardImage.setOnClickListener { showCardViewer(card, cards.filter { it.setId == card.setId }) }
        cardImage.setOnTouchListener { _, event ->
            if(event.action==MotionEvent.ACTION_UP){ showCardViewer(card, cards.filter { it.setId == card.setId }); true } else true
        }
    }

    private fun animateMainCardOut(direction: Float) {
        if (cardImage.visibility != View.VISIBLE) return
        cardImage.isClickable = false
        val move = ObjectAnimator.ofFloat(cardImage, View.TRANSLATION_X, 0f, direction)
        val fade = ObjectAnimator.ofFloat(cardImage, View.ALPHA, cardImage.alpha, 0f)
        AnimatorSet().apply {
            playTogether(move, fade)
            duration = 300
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    cardImage.visibility = View.INVISIBLE
                    cardImage.translationX = 0f
                    cardImage.alpha = 1f
                    cardImage.isClickable = true
                    cardName.text = ""
                    cardInfo.text = ""
                    cardSet.text = ""
                    cardName.alpha = 1f
                    cardInfo.alpha = 1f
                    cardSet.alpha = 1f
                    homeUniverseLayer.visibility = View.VISIBLE
                    buildHomeUniverses()
                }
            })
            start()
        }
    }

    private fun deterministicCardForEan(ean: String, selectedStyle: String?): Card {
        val digest = MessageDigest.getInstance("SHA-256").digest(ean.toByteArray(Charsets.UTF_8))

        // Globální loot: EAN -> univerzum -> set -> rarita -> karta.
        // Při prvním skenu může zvolený SKAN! jemně posunout šanci ve prospěch svého univerza.
        // Po uložení EANu se karta už nikdy nepřeroluje.
        fun byte(index: Int): Int = digest[index].toInt() and 0xFF

        val universes = listOf(
            "pokemon" to cards.filter { it.setId.startsWith("base1") },
            "starwars" to cards.filter { it.setId.startsWith("sw_") && it.scannable },
            "brainrot" to cards.filter { it.setId.startsWith("brainrot_") && it.scannable }
        ).filter { it.second.isNotEmpty() }

        if (universes.isEmpty()) return cards.first()

        val universeBucket = ((byte(0) shl 8) or byte(1)) % 100
        // Globální rozdělení mezi aktuálními dvěma aktivními univerzy:
        // bez zaměření 50/50, tlačítko SKAN! přidá vybranému tématu +10 procentních bodů.
        // Tím vzniká 60/40 nebo 40/60. Další univerzum později dostane vlastní podíl.
        val focus = selectedStyle?.takeIf { it == "pokemon" || it == "brainrot" }
        val activeBoost = activeBoostId()
        val pokemonPercent = when {
            activeBoost == "brainrot" -> 40
            else -> when (focus) {
            "pokemon" -> 60
            "brainrot" -> 40
            else -> 50
            }
        }
        val universe = if (universeBucket < pokemonPercent) {
            universes.firstOrNull { it.first == "pokemon" }
        } else {
            universes.firstOrNull { it.first == "brainrot" }
        } ?: universes.first()

        val universeCards = universe.second
        val setIds = universeCards.map { it.setId }.distinct()
        val setId = setIds[byte(2) % setIds.size]
        val setCards = universeCards.filter { it.setId == setId }

        val rarityBucket = ((byte(3) shl 8) or byte(4)) % 10_000
        val brainrotLoot = universe.first == "brainrot"
        val active = activeBoostId()
        val rates = if (brainrotLoot) effectiveBrainrotRates() else effectivePokemonRates()
        val adjustedBucket = rarityBucket
        val rarity = if (brainrotLoot) {
            when {
                adjustedBucket < rates[0]*100 -> "Common"
                adjustedBucket < (rates[0]+rates[1])*100 -> "Uncommon"
                adjustedBucket < (rates[0]+rates[1]+rates[2])*100 -> "Rare"
                adjustedBucket < (rates[0]+rates[1]+rates[2]+rates[3])*100 -> "Epic"
                else -> "Legendary"
            }
        } else {
            when {
                adjustedBucket < rates[0]*100 -> "Common"
                adjustedBucket < (rates[0]+rates[1])*100 -> "Uncommon"
                adjustedBucket < (rates[0]+rates[1]+rates[2])*100 -> "Rare"
                else -> "Rare Holo"
            }
        }
        val rarityPool = setCards.filter { it.rarity.equals(rarity, true) }
        val pool = if (rarityPool.isNotEmpty()) rarityPool else setCards
        if (pool.isEmpty()) return cards.first()

        fun cardWeight(card: Card): Int {
            val cardHash = MessageDigest.getInstance("SHA-256").digest(card.id.toByteArray(Charsets.UTF_8))
            val bucket = cardHash[0].toInt() and 0xFF
            return when { 51 > bucket -> 8; 128 > bucket -> 3; else -> 1 }
        }

        var totalWeight = 0L
        pool.forEach { totalWeight += cardWeight(it) }
        var indexSeed = 0L
        for (i in 5..31) indexSeed = (indexSeed shl 5) xor (digest[i % digest.size].toLong() and 31L)
        val target = Math.floorMod(indexSeed, totalWeight)
        var cumulative = 0L
        for (card in pool) {
            cumulative += cardWeight(card)
            if (target < cumulative) return card
        }
        return pool.last()
    }

    private fun scanMap(): MutableMap<String, String> {
        val raw = prefs.getString("scanMap", "{}") ?: "{}"
        val obj = JSONObject(raw)
        return obj.keys().asSequence().associateWith { obj.optString(it) }.toMutableMap()
    }

    private fun saveScan(ean: String, card: Card) {
        val map = scanMap()
        map[ean] = card.id
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k, v) }
        prefs.edit()
            .putString("scanMap", obj.toString())
            .putBoolean(card.id, true)
            .putLong(foundAtKey(card.id), System.currentTimeMillis())
            .apply()
    }

    private fun hasScannedBarcode(ean: String): Boolean = scanMap().containsKey(ean)

    private fun copyCount(card: Card): Int {
        val mapped = scanMap().values.count { it == card.id }
        return if (mapped > 0) mapped else if (prefs.getBoolean(card.id, false)) 1 else 0
    }

    private fun uniqueOwned(card: Card) = copyCount(card) > 0
    private fun foundAtKey(id: String) = "foundAt_$id"
    private fun favoriteKey(id: String) = "favorite_$id"
    private fun isOwned(card: Card) = uniqueOwned(card)
    private fun isFavorite(card: Card) = prefs.getBoolean(favoriteKey(card.id), false)

    private fun updateCollectionButton() {
        collectionButton.contentDescription = "Kolekce ${cards.count { isOwned(it) }}/${cards.size}"
    }

    private fun showCollectionUniversePicker() {
        val dialog = Dialog(this)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        val scroll = ScrollView(this).apply { setPadding(dp(14), dp(28), dp(14), dp(28)) }
        val grid = GridLayout(this).apply { columnCount = 2; useDefaultMargins = false }
        universeCatalog().forEach { universe ->
            val tile = createUniverseTile(universe)
            tile.setOnClickListener {
                dialog.dismiss()
                showCollectionDialog(universe)
            }
            grid.addView(tile, GridLayout.LayoutParams().apply {
                width = 0; height = dp(132)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(6), dp(6), dp(6), dp(6))
            })
        }
        scroll.addView(grid, FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        dialog.setContentView(root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.attributes = dialog.window?.attributes?.apply { dimAmount = 0.78f }
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun showCollectionDialog(universe: Universe) {
        // Kolekce je samostatná plocha bez vnitřního „okna“.
        // Okolí zůstává ztlumené a na první úrovni jsou pouze dlaždice setů.
        val dialog = Dialog(this)
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setPadding(dp(18), dp(34), dp(18), dp(24))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        // Každé univerzum má vlastní kolekci. EAN loot se nikdy nepřerolovává;
        // pouze zde zobrazujeme obsah daného univerza.
        val universeCards = when (universe.id.lowercase()) {
            "pokemon" -> cards.filter { it.setId.startsWith("base1") }
            "starwars" -> cards.filter { it.setId.startsWith("sw_") }
            "brainrot" -> cards.filter { it.setId.startsWith("brainrot_") }
            else -> emptyList()
        }

        val generations = universeCards.map { it.generation }.distinct().sorted()
        val sets = universeCards.map { it.setId }.distinct()
        val collapsedGenerations = mutableSetOf<Int>()
        var currentSetId: String? = null

        lateinit var render: () -> Unit

        // Kliknutí do prázdného prostoru funguje jako „Zpět“. Když jsme uvnitř
        // konkrétního setu, vrátíme se na seznam setů; jinak se zavře tato plocha
        // a pod ní zůstane otevřené menu daného univerza.
        installBlankSpaceBack(scroll) {
            if (currentSetId != null) render() else dialog.dismiss()
        }

        fun renderSetCards(setId: String) {
            currentSetId = setId
            content.removeAllViews()
            val set = universeCards.firstOrNull { it.setId == setId } ?: return
            val setCards = universeCards.filter { it.setId == setId }

            var selectedMode = "Vše"
            var selectedElement = "Všechny elementy"
            var selectedSort = "Datum nalezení"

            val page = FrameLayout(this)
            content.addView(page, LinearLayout.LayoutParams(-1, -1))

            val cardsScroll = ScrollView(this).apply {
                isFillViewport = true
                setPadding(dp(6), dp(58), dp(6), dp(18))
            }
            val cardsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            cardsScroll.addView(cardsContainer, FrameLayout.LayoutParams(-1, -1))
            page.addView(cardsScroll, FrameLayout.LayoutParams(-1, -1))

            val controls = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(4), dp(8), dp(4))
            }

            fun smallRoundButton(symbol: String, description: String, action: () -> Unit): Button = Button(this).apply {
                text = symbol
                textSize = 19f
                setTextColor(Color.WHITE)
                contentDescription = description
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, 0)
                background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_dialog)
                setOnClickListener { action() }
            }

            fun refreshCards() {
                cardsContainer.removeAllViews()
                renderCards(
                    cardsContainer,
                    applyFilterAndSort(setCards, selectedMode, selectedElement, selectedSort),
                    selectedMode
                )
            }

            val backButton = smallRoundButton("‹", if (universe.id.equals("brainrot", true)) "Zpět na Brainrot" else "Zpět na sety") {
                if (universe.id.equals("brainrot", true)) dialog.dismiss() else render()
            }
            controls.addView(backButton, LinearLayout.LayoutParams(dp(44), dp(44)))

            val spacer = Space(this)
            controls.addView(spacer, LinearLayout.LayoutParams(0, dp(44), 1f))

            lateinit var filterButton: Button
            filterButton = smallRoundButton("☷", "Filtry") {
                val brainrot = universe.id.equals("brainrot", true)
                val options = if (brainrot) {
                    listOf("Vše", "Nalezené", "Rarita", "Herní hodnota", "Oblíbené")
                } else {
                    listOf("Vše", "Nalezené", "Oblíbené", "Pokémon", "Energie", "Item", "Trainer")
                }
                val popup = PopupWindow(this).apply {
                    isFocusable = true
                    elevation = dp(8).toFloat()
                    setBackgroundDrawable(ColorDrawable(Color.rgb(35, 35, 35)))
                }
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                options.forEach { option ->
                    box.addView(Button(this).apply {
                        text = option
                        textSize = 14f
                        setTextColor(Color.WHITE)
                        background = ColorDrawable(Color.TRANSPARENT)
                        gravity = Gravity.START or Gravity.CENTER_VERTICAL
                        setOnClickListener {
                            if (brainrot && option == "Rarita") {
                                popup.dismiss()
                                showBrainrotSubmenu(filterButton, "Rarita", listOf("Vše", "Běžný", "Neobyčejný", "Vzácný", "Epický", "Legendární")) { value ->
                                    val internal = mapOf("Běžný" to "Common", "Neobyčejný" to "Uncommon", "Vzácný" to "Rare", "Epický" to "Epic", "Legendární" to "Legendary")[value] ?: value
                                    selectedMode = if (value == "Vše") "Vše" else "Rarita:$internal"
                                    refreshCards()
                                }
                            } else if (brainrot && option == "Herní hodnota") {
                                popup.dismiss()
                                showBrainrotSubmenu(filterButton, "Herní hodnota", listOf("Vše", "1", "2", "3", "4", "5", "6", "7", "8")) { value ->
                                    selectedMode = if (value == "Vše") "Vše" else "Hodnota:$value"
                                    refreshCards()
                                }
                            } else {
                                selectedMode = option
                                popup.dismiss()
                                refreshCards()
                            }
                        }
                    }, LinearLayout.LayoutParams(dp(190), dp(42)))
                }
                val elements = availableElements(setCards)
                if (elements.isNotEmpty()) {
                    box.addView(View(this).apply { setBackgroundColor(Color.DKGRAY) }, LinearLayout.LayoutParams(-1, dp(1)))
                    box.addView(Button(this).apply {
                        text = if (selectedElement == "Všechny elementy") "Elementy" else "Element: $selectedElement"
                        textSize = 14f
                        setTextColor(Color.WHITE)
                        background = ColorDrawable(Color.TRANSPARENT)
                        gravity = Gravity.START or Gravity.CENTER_VERTICAL
                        setOnClickListener {
                            popup.dismiss()
                            val ep = PopupWindow(this@MainActivity).apply {
                                isFocusable = true
                                elevation = dp(8).toFloat()
                                setBackgroundDrawable(ColorDrawable(Color.rgb(35, 35, 35)))
                            }
                            val eb = LinearLayout(this@MainActivity).apply {
                                orientation = LinearLayout.VERTICAL
                                setPadding(dp(8), dp(8), dp(8), dp(8))
                            }
                            (listOf("Všechny elementy") + elements).forEach { element ->
                                eb.addView(Button(this@MainActivity).apply {
                                    text = element
                                    textSize = 14f
                                    setTextColor(Color.WHITE)
                                    background = ColorDrawable(Color.TRANSPARENT)
                                    gravity = Gravity.START or Gravity.CENTER_VERTICAL
                                    setOnClickListener {
                                        selectedElement = element
                                        ep.dismiss()
                                        refreshCards()
                                    }
                                }, LinearLayout.LayoutParams(dp(190), dp(42)))
                            }
                            ep.contentView = eb
                            ep.width = dp(210)
                            ep.height = WindowManager.LayoutParams.WRAP_CONTENT
                            ep.showAsDropDown(filterButton, -dp(165), -dp(48))
                        }
                    }, LinearLayout.LayoutParams(dp(190), dp(42)))
                }
                popup.contentView = box
                popup.width = dp(210)
                popup.height = WindowManager.LayoutParams.WRAP_CONTENT
                popup.showAsDropDown(filterButton, -dp(165), -dp(48))
            }

            lateinit var sortButton: Button
            sortButton = smallRoundButton("↕", "Řazení") {
                val options = if (universe.id.equals("brainrot", true)) {
                    arrayOf("Datum nalezení", "Rarita", "Herní hodnota", "Abecedně", "Oblíbené")
                } else {
                    arrayOf("Datum nalezení", "Rarita", "Element", "Stadium vývoje", "Abecedně", "Pořadí na kartě")
                }
                val popup = PopupWindow(this).apply {
                    isFocusable = true
                    elevation = dp(8).toFloat()
                    setBackgroundDrawable(ColorDrawable(Color.rgb(35, 35, 35)))
                }
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                options.forEach { option ->
                    box.addView(Button(this).apply {
                        text = option
                        textSize = 14f
                        setTextColor(Color.WHITE)
                        background = ColorDrawable(Color.TRANSPARENT)
                        gravity = Gravity.START or Gravity.CENTER_VERTICAL
                        setOnClickListener {
                            selectedSort = option
                            popup.dismiss()
                            refreshCards()
                        }
                    }, LinearLayout.LayoutParams(dp(190), dp(42)))
                }
                popup.contentView = box
                popup.width = dp(210)
                popup.height = WindowManager.LayoutParams.WRAP_CONTENT
                popup.showAsDropDown(sortButton, -dp(165), -dp(48))
            }

            controls.addView(filterButton, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(6) })
            controls.addView(sortButton, LinearLayout.LayoutParams(dp(44), dp(44)))
            page.addView(controls, FrameLayout.LayoutParams(-1, dp(54), Gravity.TOP))

            refreshCards()
        }

        fun renderSetTiles(container: LinearLayout, setCards: List<Card>) {
            val grid = GridLayout(this).apply {
                columnCount = 2
                alignmentMode = GridLayout.ALIGN_BOUNDS
                useDefaultMargins = false
                setPadding(dp(4), dp(4), dp(4), dp(10))
            }
            setCards.distinctBy { it.setId }.sortedBy { it.setName }.forEach { set ->
                val tile = setTile(set)
                tile.setOnClickListener { renderSetCards(set.setId) }
                grid.addView(tile, GridLayout.LayoutParams().apply {
                    width = 0
                    height = dp(122)
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(dp(5), dp(5), dp(5), dp(5))
                })
            }
            container.addView(grid)
        }

        render = {
            currentSetId = null
            content.removeAllViews()
            if (universeCards.isEmpty()) {
                content.addView(TextView(this).apply {
                    text = "Kolekce ${universe.title} je zatím prázdná."
                    textSize = 20f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    setPadding(dp(24), dp(120), dp(24), dp(24))
                }, LinearLayout.LayoutParams(-1, -2))
            } else if (universe.id.equals("brainrot", true)) {
                // Brainrot má jen jednu společnou kolekci: po otevření KOLEKCE
                // jdeme rovnou na karty, bez mezikroku se setem.
                renderSetCards(sets.first())
            } else if (sets.size == 1) {
                renderSetTiles(content, universeCards)
            } else {
                generations.forEach { gen ->
                    val genSets = universeCards.filter { it.generation == gen }.distinctBy { it.setId }.sortedBy { it.setName }
                    val genHeader = sectionButton("Gen $gen  ${ownedCountGeneration(gen)}/${totalGeneration(gen)}", true)
                    content.addView(genHeader)
                    val genBody = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        visibility = if (collapsedGenerations.contains(gen)) View.GONE else View.VISIBLE
                    }
                    genHeader.setOnClickListener {
                        if (!collapsedGenerations.add(gen)) collapsedGenerations.remove(gen)
                        render()
                    }
                    content.addView(genBody)
                    if (genBody.visibility == View.VISIBLE) renderSetTiles(genBody, genSets)
                }
            }
        }

        dialog.setContentView(root)
        dialog.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK && event.action == android.view.KeyEvent.ACTION_UP) {
                if (currentSetId != null) {
                    if (universe.id.equals("brainrot", true)) dialog.dismiss() else render()
                    true
                } else {
                    dialog.dismiss()
                    true
                }
            } else false
        }
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.attributes = dialog.window?.attributes?.apply { dimAmount = 0.72f }
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        render()
    }

    private fun setTile(set: Card): LinearLayout {
        val tile = FrameLayout(this).apply {
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_dialog)
            clipToOutline = true
            elevation = dp(3).toFloat()
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(35, 35, 35))
            when {
                set.setId.equals("base1", true) || set.setName.equals("Base Set", true) -> setImageResource(R.drawable.base_set_tile)
                set.setId.startsWith("sw_") -> setImageResource(R.drawable.universe_starwars_tile)
                set.setId.startsWith("brainrot_") -> setImageResource(R.drawable.universe_brainrot_tile)
            }
        }
        tile.addView(image, FrameLayout.LayoutParams(-1, -1))

        val shade = View(this).apply { setBackgroundColor(Color.argb(80, 0, 0, 0)) }
        tile.addView(shade, FrameLayout.LayoutParams(-1, -1))

        val title = TextView(this).apply {
            text = set.setName
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setShadowLayer(5f, 1f, 1f, Color.BLACK)
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(10), dp(8), dp(8), dp(4))
        }
        tile.addView(title, FrameLayout.LayoutParams(-1, -2, Gravity.TOP or Gravity.START))

        val count = TextView(this).apply {
            text = "${ownedCount(set.setId)}/${setTotal(set.setId)}"
            textSize = 15f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setShadowLayer(4f, 1f, 1f, Color.BLACK)
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(8), dp(4), dp(10), dp(8))
        }
        tile.addView(count, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM or Gravity.END))
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tile, LinearLayout.LayoutParams(-1, -1))
        }
    }

    private fun showBrainrotSubmenu(anchor: View, title: String, options: List<String>, onSelect: (String) -> Unit) {
        val popup = PopupWindow(this).apply {
            isFocusable = true
            elevation = dp(8).toFloat()
            setBackgroundDrawable(ColorDrawable(Color.rgb(35, 35, 35)))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(8), dp(4), dp(8), dp(8))
        })
        options.forEach { option ->
            box.addView(Button(this).apply {
                text = if (title == "Rarita") rarityDisplayName(option) else option
                textSize = 14f
                setTextColor(Color.WHITE)
                background = ColorDrawable(Color.TRANSPARENT)
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener { popup.dismiss(); onSelect(option) }
            }, LinearLayout.LayoutParams(dp(190), dp(42)))
        }
        popup.contentView = box
        popup.width = dp(210)
        popup.height = WindowManager.LayoutParams.WRAP_CONTENT
        popup.showAsDropDown(anchor, -dp(165), -dp(48))
    }

    private fun availableElements(source: List<Card>): List<String> = source.flatMap { it.element.split(",", "/", "|") }.map { it.trim() }.filter { it.isNotEmpty() }.distinct().sorted()

    private fun applyFilterAndSort(source: List<Card>, mode: String, element: String, sort: String): List<Card> {
        var list = when {
            mode == "Nalezené" -> source.filter { isOwned(it) }
            mode == "Oblíbené" -> source.filter { isFavorite(it) }
            mode.startsWith("Rarita:") -> source.filter { it.rarity.equals(mode.substringAfter(":"), true) }
            mode.startsWith("Hodnota:") -> source.filter { it.rarityNumber == mode.substringAfter(":").toIntOrNull() }
            mode == "Pokémon" -> source.filter { it.category.equals("Pokémon", true) }
            mode == "Energie" -> source.filter { it.category.equals("Energy", true) || it.category.equals("Energie", true) }
            mode == "Item" -> source.filter { it.category.equals("Trainer", true) && it.trainerSubtype.equals("Item", true) }
            mode == "Trainer" -> source.filter { it.category.equals("Trainer", true) && !it.trainerSubtype.equals("Item", true) }
            else -> source
        }
        if (element != "Všechny elementy") {
            list = list.filter { it.element.split(",", "/", "|").map { e -> e.trim() }.any { it.equals(element, true) } }
        }

        val sorted = when (sort) {
            "Datum nalezení" -> list.sortedWith(compareByDescending<Card> { prefs.getLong(foundAtKey(it.id), 0L) }.thenBy { it.number })
            "Rarita" -> list.sortedWith(compareBy<Card> { raritySortRank(it.rarity) }.thenBy { it.name.lowercase() }.thenBy { it.number })
            "Herní hodnota" -> list.sortedWith(compareBy<Card> { it.rarityNumber }.thenBy { it.name.lowercase() }.thenBy { it.number })
            "Oblíbené" -> list.sortedWith(compareByDescending<Card> { isFavorite(it) }.thenBy { it.number })
            "Element" -> list.sortedWith(compareBy<Card> { it.element.ifBlank { "~" } }.thenBy { it.evolutionFamily.ifBlank { it.name } }.thenBy { it.evolutionOrder }.thenBy { it.number })
            "Stadium vývoje" -> list.sortedWith(compareBy<Card> { it.evolutionFamily.ifBlank { "~" } }.thenBy { it.evolutionOrder }.thenBy { it.number })
            "Abecedně", "Abecedy" -> list.sortedWith(compareBy<Card> { it.name.lowercase() }.thenBy { it.number })
            else -> list.sortedBy { it.number }
        }

        // Globální pravidlo kolekcí: nalezené vždy první, ale uvnitř skupiny
        // se přesně zachová právě zvolené řazení.
        return sorted.sortedWith(compareByDescending<Card> { isOwned(it) })
    }

    private fun raritySortRank(rarity: String): Int = when (rarity.lowercase()) {
        "common" -> 1
        "uncommon" -> 2
        "rare", "rare holo" -> 3
        "epic" -> 4
        "legendary" -> 5
        else -> 99
    }

    private fun renderCards(content: LinearLayout, setCards: List<Card>, mode: String) {
        if (setCards.isEmpty()) {
            content.addView(TextView(this).apply { text = "Žádné karty neodpovídají filtru."; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(dp(8), dp(18), dp(8), dp(18)) })
            return
        }
        val grid = GridLayout(this).apply { columnCount = 3; useDefaultMargins = true; setPadding(dp(4), dp(4), dp(4), dp(8)) }
        setCards.forEach { card ->
            val copies = copyCount(card)
            val repeat = if (mode == "Nalezené" && copies > 1) copies else 1
            repeat(repeat) {
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(3), dp(3), dp(3), dp(8))
                }
                val cardView = brainrotCardView(
                    card, dp(100), dp(150), interactive = true,
                    allowRemote = true, navigationCards = setCards
                )
                tile.addView(cardView)
                val copyLabel = if (copies > 1) "×$copies" else ""
                if (copyLabel.isNotBlank() || isFavorite(card)) {
                    tile.addView(TextView(this).apply {
                        text = listOf(copyLabel, if (isFavorite(card)) "♥" else "").filter { it.isNotBlank() }.joinToString("  ")
                        textSize = 11f
                        gravity = Gravity.CENTER
                        setTextColor(Color.WHITE)
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                    })
                }
                grid.addView(tile, GridLayout.LayoutParams().apply {
                    width = 0
                    height = GridLayout.LayoutParams.WRAP_CONTENT
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                })
            }
        }
        content.addView(grid)
    }

    private fun showLockedCardViewer(card: Card) {
        showCardViewer(card, cards.filter { it.setId == card.setId })
    }

    private fun showCardViewer(card: Card, navigationCards: List<Card> = cards.filter { it.setId == card.setId }) {
        if (navigationCards.isEmpty()) return
        val viewer = Dialog(this)
        val ordered = navigationCards.distinctBy { it.id }
        var index = ordered.indexOfFirst { it.id == card.id }.coerceAtLeast(0)
        var downX = 0f
        var downY = 0f

        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
        }

        fun render(current: Card) {
            frame.removeAllViews()
            val owned = isOwned(current)
            val maxWidth = (resources.displayMetrics.widthPixels * 0.88f).toInt()
            val maxHeight = (resources.displayMetrics.heightPixels * 0.66f).toInt()
            val width = minOf(maxWidth, (maxHeight / 1.5f).toInt())
            val height = (width * 1.5f).toInt()
            val innerLeft = (width * 0.115f).toInt()
            val innerRight = (width * 0.115f).toInt()
            val innerTop = (height * 0.115f).toInt()
            val innerBottom = (height * 0.115f).toInt()
            val cardFrame = FrameLayout(this).apply {
                background = rarityStrokeDrawable(current.rarity, 18, 1)
                clipToOutline = true
            }

            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Color.rgb(12, 12, 16))
                contentDescription = current.name
            }
            cardFrame.addView(image, FrameLayout.LayoutParams(-1, -1).apply {
                leftMargin = innerLeft; rightMargin = innerRight
                topMargin = innerTop; bottomMargin = innerBottom
            })
            if (current.imageLarge.isNotBlank()) {
                val cached = cachedArtworkFile(current)
                val fallbackRes = artworkFallback(current)
                if (current.imageLarge.startsWith("file:///android_asset/")) {
                    loadCardArtwork(image, current.imageLarge, fallbackRes)
                } else {
                    val fallbackSmall = current.imageSmall.takeIf { it.isNotBlank() && it != current.imageLarge }
                    val remoteRequest = Glide.with(this).load(current.imageLarge)
                        .placeholder(fallbackRes)
                        .error(fallbackRes)
                    if (fallbackSmall != null) remoteRequest.error(Glide.with(this).load(fallbackSmall).error(fallbackRes))
                    if (cached != null) {
                        Glide.with(this).load(cached)
                            .placeholder(fallbackRes)
                            .error(remoteRequest)
                            .into(image)
                    } else {
                        remoteRequest.into(image)
                    }
                }
            } else if (current.imageSmall.isNotBlank()) {
                loadCardArtwork(image, current.imageSmall, artworkFallback(current))
            } else {
                image.setImageResource(artworkFallback(current))
            }

            if (!owned) {
                image.alpha = 0.30f
                cardFrame.addView(View(this).apply { setBackgroundColor(Color.argb(155, 0, 0, 0)) }, FrameLayout.LayoutParams(-1, -1))
            }

            val top = TextView(this).apply {
                text = "#${current.number}"
                textSize = 18f
                setTextColor(Color.WHITE)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setShadowLayer(6f, 1f, 1f, Color.BLACK)
                setPadding(dp(14), dp(10), 0, 0)
            }
            cardFrame.addView(top, FrameLayout.LayoutParams(dp(110), dp(48), Gravity.TOP or Gravity.START).apply { leftMargin = innerLeft; topMargin = innerTop })

            val gameValue = TextView(this).apply {
                text = current.rarityNumber.toString()
                textSize = 18f
                setTextColor(Color.WHITE)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    cornerRadius = dp(9).toFloat()
                    setColor(rarityFrameColor(current.rarity))
                    setStroke(dp(1), Color.argb(190,255,255,255))
                }
            }
            cardFrame.addView(gameValue, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.TOP or Gravity.END).apply {
                topMargin = innerTop + dp(8); rightMargin = innerRight + dp(8)
            })

            val bottom = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(10), dp(14), dp(12))
                background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.argb(235,0,0,0), Color.TRANSPARENT))
            }
            bottom.addView(TextView(this).apply {
                text = current.name
                textSize = 21f
                setTextColor(Color.WHITE)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(-1, -2))
            bottom.addView(TextView(this).apply {
                text = "${rarityDisplayName(current.rarity)}  •  ${rarityDropPercent(current.rarity, isBrainrot(current))}"
                textSize = 13f
                setTextColor(Color.LTGRAY)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }, LinearLayout.LayoutParams(-1, -2))
            if (isBrainrot(current)) {
                val bs = brainrotStats(current)
                val statsRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(4), 0, 0)
                }
                listOf("❤️" to bs.hp, "⚔️" to bs.atk, "🛡️" to bs.def, "⚡" to bs.spd).forEach { (icon, value) ->
                    statsRow.addView(TextView(this).apply {
                        text = "$icon $value"
                        textSize = 13f
                        setTextColor(Color.WHITE)
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        gravity = Gravity.CENTER
                        maxLines = 1
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                }
                bottom.addView(statsRow, LinearLayout.LayoutParams(-1, -2))
                bottom.addView(TextView(this).apply {
                    text = "${bs.archetype} • ${bs.ability}"
                    textSize = 11f
                    setTextColor(Color.LTGRAY)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }, LinearLayout.LayoutParams(-1, -2))
            }
            cardFrame.addView(bottom, FrameLayout.LayoutParams(-1, dp(if (isBrainrot(current)) 132 else 76), Gravity.BOTTOM).apply { leftMargin = innerLeft; rightMargin = innerRight; bottomMargin = innerBottom })
            addRarityArtworkFrame(cardFrame, current.rarity)

            frame.addView(cardFrame, FrameLayout.LayoutParams(width, height, Gravity.CENTER).apply { bottomMargin = dp(46) })

            val position = TextView(this).apply {
                text = "${index + 1} / ${ordered.size}"
                textSize = 13f
                setTextColor(Color.LTGRAY)
                gravity = Gravity.CENTER
            }
            frame.addView(position, FrameLayout.LayoutParams(-1, dp(30), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(94) })

            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            val favoriteButton = iconButton(if (isFavorite(current)) "♥" else "♡", "Oblíbené")
            favoriteButton.setOnClickListener {
                val newValue = !isFavorite(current)
                prefs.edit().putBoolean(favoriteKey(current.id), newValue).apply()
                favoriteButton.text = if (newValue) "♥" else "♡"
                updateCollectionButton()
            }
            val deckButton = iconButton("+", "Do balíčku")
            deckButton.setOnClickListener { showDeckPicker(current) }
            val closeButton = iconButton("×", "Zavřít")
            closeButton.setOnClickListener { viewer.dismiss() }
            actions.addView(favoriteButton, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(6) })
            actions.addView(deckButton, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(6) })
            if (isBrainrot(current) && owned) { val teamButton=iconButton("♟","Přidat do týmu"); teamButton.setOnClickListener { addToTeam(current) }; actions.addView(teamButton, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(6) }) }
            actions.addView(closeButton, LinearLayout.LayoutParams(dp(56), dp(56)))
            frame.addView(actions, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { rightMargin = dp(18); bottomMargin = dp(18) })
        }

        frame.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (kotlin.math.abs(dx) > dp(70) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.2f) {
                        if (dx < 0 && index < ordered.lastIndex) { index++; render(ordered[index]) }
                        else if (dx > 0 && index > 0) { index--; render(ordered[index]) }
                    }
                    true
                }
                else -> true
            }
        }

        render(ordered[index])
        viewer.setContentView(frame)
        viewer.setCanceledOnTouchOutside(true)
        viewer.show()
        viewer.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        viewer.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        viewer.window?.attributes = viewer.window?.attributes?.apply { dimAmount = 0.72f }
        viewer.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun refreshActiveBoostButton(){ findViewById<Button>(R.id.activeBoostButton)?.apply{val id=activeBoostId();val n=activeBoostScans();visibility=if(id.isNotBlank()&&n>0)View.VISIBLE else View.GONE;text="🍀\n$n";contentDescription="Aktivní boost: $id • $n skenů"} }

    private fun shopPrice(tier:String,rarity:String):Int {
        val base=when(tier.lowercase()){"slabý"->500;"střední"->700;"silný"->1000;else->500}
        val extra=when(rarity.lowercase()){"vzácný"->200;"epický"->500;else->0}
        return base+extra
    }
    private fun shopOfferRarities(): MutableMap<String,String> {
        val stored=prefs.getString("shopOfferRarities","") ?: ""
        val map=mutableMapOf<String,String>()
        if(stored.isNotBlank()) stored.split(";").forEach{val x=it.split("=");if(x.size==2)map[x[0]]=x[1]}
        if(map.size==9) return map
        val rs=listOf("Běžný","Vzácný","Epický")
        listOf("boost_slabý","boost_střední","boost_silný","item_slabý","item_střední","item_silný","ability_slabý","ability_střední","ability_silný").forEach{map[it]=rs.random()}
        saveShopOfferRarities(map); return map
    }
    private fun saveShopOfferRarities(map:Map<String,String>){prefs.edit().putString("shopOfferRarities",map.entries.joinToString(";"){"${it.key}=${it.value}"}).apply()}
    private fun refreshShopOffersEveryTenOpens(): MutableMap<String,String>{
        var opens=prefs.getInt("shopOpenCount",0)+1
        var offers=shopOfferRarities()
        if(opens%10==0){
            val rs=listOf("Běžný","Vzácný","Epický"); offers=offers.mapValues{rs.random()}.toMutableMap(); saveShopOfferRarities(offers)
        }
        prefs.edit().putInt("shopOpenCount",opens).apply(); return offers
    }
    private fun randomShopItem(tier:String,rarity:String,kind:String):SkanItem{
        val pool=when(kind){
            "item"->listOf("Regenerační ampule" to "Heal","Plazmová čepel" to "Zbraň","Energetický štít" to "Štít","Reroll token" to "Reroll")
            else->listOf("Zuřivý úder" to "Schopnost","Pancéřová bariéra" to "Schopnost","Bleskový tah" to "Schopnost","Chaosový svitek" to "Schopnost")
        }
        val chosen=pool.random()
        val power=when(tier.lowercase()){"slabý"->10;"střední"->18;else->30}
        return SkanItem("shop_${kind}_${System.currentTimeMillis()}_${Random.nextInt(10000)}",chosen.first,rarity,chosen.second,power,"Zakoupeno v SKAN Obchodě • $tier • $rarity",if(kind=="ability")3 else 1)
    }
    private fun shopOfferSpec(kind:String,tier:String,key:String,rarity:String): Triple<String,String,Int> {
        val seed=MessageDigest.getInstance("SHA-256").digest(("shop:$key:$rarity:$tier").toByteArray())
        val idx=(seed[0].toInt() and 255)
        val power=when(tier.lowercase()){"slabý"->10;"střední"->18;else->30}
        return when(kind){
            "boost" -> {
                val data=when(tier.lowercase()){
                    "slabý"->Triple("Luck Boost","+5 p. b. k lepším raritám",5)
                    "střední"->Triple("Rare Boost","+5 p. b. ke vzácnějším dropům",7)
                    else->Triple("Brainrot Boost","+10 p. b. pro Brainroty",5)
                }
                Triple(data.first,data.second,data.third)
            }
            "item" -> {
                val pool=listOf(
                    "Regenerační ampule" to "Obnoví část HP",
                    "Plazmová čepel" to "Silný přímý útok",
                    "Energetický štít" to "Pomůže snížit přijaté poškození",
                    "Reroll token" to "Umožní přerolovat akci"
                )
                val pick=pool[idx%pool.size]; Triple(pick.first,pick.second,power)
            }
            else -> {
                val pool=listOf(
                    "Zuřivý úder" to "Silný útok proti soupeři",
                    "Pancéřová bariéra" to "Zvýhodní obranu",
                    "Bleskový tah" to "Zvýhodní rychlost a tah",
                    "Chaosový svitek" to "Nepředvídatelný speciální efekt"
                )
                val pick=pool[idx%pool.size]; Triple(pick.first,pick.second,power)
            }
        }
    }

    private fun shopItemFromOffer(kind:String,tier:String,key:String,rarity:String):SkanItem{
        val spec=shopOfferSpec(kind,tier,key,rarity)
        val type=if(kind=="ability")"Schopnost" else when(spec.first){"Regenerační ampule"->"Heal";"Plazmová čepel"->"Zbraň";"Energetický štít"->"Štít";else->"Reroll"}
        return SkanItem("shop_${key}_$rarity",spec.first,rarity,type,spec.third,spec.second,if(kind=="ability")3 else 1)
    }

    private fun showShopDialog(){
        val d=Dialog(this)
        val root=FrameLayout(this)
        root.addView(ImageView(this).apply{scaleType=ImageView.ScaleType.FIT_XY;setImageResource(R.drawable.shop_window)},FrameLayout.LayoutParams(-1,-1))
        val offers=refreshShopOffersEveryTenOpens()
        val overlay=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(300),dp(20),dp(24))}

        fun product(kind:String,tier:String,key:String):TextView{
            val rarity=offers[key] ?: "Běžný"
            val price=shopPrice(tier,rarity)
            val spec=shopOfferSpec(kind,tier,key,rarity)
            return TextView(this).apply{
                text="${spec.first}\n$tier • $rarity • $price Coins\n${spec.second}"
                textSize=10f
                setTextColor(Color.WHITE)
                setTypeface(typeface,android.graphics.Typeface.BOLD)
                gravity=Gravity.CENTER
                setPadding(dp(5),dp(4),dp(5),dp(4))
                maxLines=3
                ellipsize=android.text.TextUtils.TruncateAt.END
                setShadowLayer(4f,0f,1f,Color.BLACK)
                setOnClickListener{
                    if(coins()<price){Toast.makeText(this@MainActivity,"Nedostatek Coins.",Toast.LENGTH_SHORT).show();return@setOnClickListener}
                    addCoins(-price)
                    if(kind=="boost"){
                        val boostId=when(tier.lowercase()){"slabý"->"luck";"střední"->"rare";else->"brainrot"}
                        addBoost(boostId,spec.first,spec.third,spec.second,rarity)
                    }else addItem(shopItemFromOffer(kind,tier,key,rarity))
                    Toast.makeText(this@MainActivity,"Zakoupeno • ${spec.first} • $rarity",Toast.LENGTH_LONG).show()
                    d.dismiss()
                }
            }
        }
        fun row(kind:String,tiers:List<Pair<String,String>>){
            val r=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
            tiers.forEach{(tier,key)->r.addView(product(kind,tier,key),LinearLayout.LayoutParams(0,dp(155),1f).apply{setMargins(dp(3),dp(2),dp(3),dp(2))})}
            overlay.addView(r,LinearLayout.LayoutParams(-1,dp(160)))
        }
        row("boost",listOf("slabý" to "boost_slabý","střední" to "boost_střední","silný" to "boost_silný"))
        row("item",listOf("slabý" to "item_slabý","střední" to "item_střední","silný" to "item_silný"))
        row("ability",listOf("slabý" to "ability_slabý","střední" to "ability_střední","silný" to "ability_silný"))
        overlay.addView(Space(this),LinearLayout.LayoutParams(-1,0,1f))
        overlay.addView(Button(this).apply{
            text="ZAVŘÍT";isAllCaps=false;textSize=16f;setTextColor(Color.BLACK);setTypeface(typeface,android.graphics.Typeface.BOLD)
            background=ColorDrawable(Color.TRANSPARENT);setOnClickListener{d.dismiss()}
        },LinearLayout.LayoutParams(-1,dp(78)))
        root.addView(overlay,FrameLayout.LayoutParams(-1,-1))
        d.setContentView(root);d.show();styleDialogWindow(d,.86f,.90f)
    }

    private fun showGameMenuDialog() {
        val dialog = Dialog(this)
        val root = darkDialogRoot()
        root.addView(dialogTitle("🎮 HERNÍ MENU"))
        root.addView(sectionButton("🎒  ITEMY\nInventář itemů", false).apply {
            setOnClickListener { dialog.dismiss(); showItemsDialog() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(sectionButton("🍀  BOOSTY\nAktivní boosty", false).apply {
            setOnClickListener { dialog.dismiss(); showBoostsDialog() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(sectionButton("⚔  TRAINING DUEL\nSouboj vlastních Brainrotů", false).apply {
            setOnClickListener { dialog.dismiss(); showTrainingDuelDialog() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(sectionButton("🃏  PEXESO\nHra o odměny", false).apply {
            setOnClickListener { dialog.dismiss(); showMemoryDialog() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(roundedButton("ZAVŘÍT") { dialog.dismiss() },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        dialog.setContentView(root)
        dialog.show()
        styleDialogWindow(dialog, 0.86f, 0.68f)
    }

    // Patch Notes 0.6.1: Training Pexeso now has 10 pairs/20 cards, no Coin reward, Brainrot artwork on flip, fixed Training Duel crash, and shop offers use 500/700/1000 base prices with rarity bonuses 0/200/500 and refresh every 10 shop opens.
    private fun showSettingsDialog() {
        val dialog = Dialog(this)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.TRANSPARENT)
        root.addView(ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            setImageResource(R.drawable.settings_window)
            contentDescription = "Nastavení SKAN"
        }, FrameLayout.LayoutParams(-1, -1))

        // Umístění je relativní k celé grafice, takže text zůstane v tlačítkách
        // i při různých poměrech stran a velikostech displeje.
        val versionButton = settingsOverlayButton("VERZE 0.7.0", false) {}
        val patchButton = settingsOverlayButton("PATCH NOTES", true) {
            dialog.dismiss()
            showPatchNotesDialog()
        }
        val closeButton = settingsOverlayButton("ZAVŘÍT", true) { dialog.dismiss() }
        root.addView(versionButton)
        root.addView(patchButton)
        root.addView(closeButton)
        root.addOnLayoutChangeListener { _, _, _, _, height, _, _, _, _ ->
            if (height > 0) {
                val specs = listOf(versionButton to 0.300f, patchButton to 0.440f, closeButton to 0.570f)
                specs.forEach { (button, centerY) ->
                    val buttonHeight = (height * 0.105f).toInt()
                    val params = (button.layoutParams as? FrameLayout.LayoutParams)
                        ?: FrameLayout.LayoutParams(-1, buttonHeight)
                    params.width = (root.width * 0.80f).toInt()
                    params.height = buttonHeight
                    params.leftMargin = (root.width * 0.10f).toInt()
                    params.topMargin = (height * centerY).toInt() - buttonHeight / 2
                    params.gravity = Gravity.TOP or Gravity.START
                    button.layoutParams = params
                }
            }
        }
        dialog.setContentView(root)
        dialog.show()
        styleDialogWindow(dialog, 0.72f, 0.90f)
    }

    private fun settingsOverlayButton(label: String, enabled: Boolean, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(Color.BLACK)
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        background = ColorDrawable(Color.TRANSPARENT)
        isEnabled = true
        isClickable = enabled
        if (enabled) setOnClickListener { action() }
        gravity = Gravity.CENTER
        minHeight = 0
        minimumHeight = 0
        stateListAnimator = null
        elevation = 0f
    }

    private fun showPatchNotesDialog() {
        val dialog = Dialog(this)
        val root = darkDialogRoot()
        root.addView(dialogTitle("PATCH NOTES"))
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
        }
        val text = TextView(this).apply {
            text = """
SKAN 0.7.3 — POMĚR STRAN, CELÉ KARTY A DLAŽDICE

• Karty v detailu zachovávají poměr stran rámečku 2:3; rám se už nenatahuje podle výšky obrazovky.
• Artwork, číslo, rarita, název a údaje jsou umístěné uvnitř průhledného okna rámečku, ne pod jeho okraji.
• Seznam karet používá jednotný celý náhled s názvem a raritou přímo uvnitř rámečku; ztmavení neobjevených karet zůstává.
• Grafické dlaždice menu zobrazují celou dodanou grafiku bez ořezu okrajů. Pořadí menu zůstává: Kolekce přes celý řádek; Týmy/Předměty; Schopnosti/Boosty; Training Duel/Training Pexeso.

SKAN 0.7.2 — FINÁLNÍ GRAFICKÉ RÁMEČKY A VIDITELNÝ ARTWORK

• Použity dodané dřevěné/královské rámečky podle rarity: hnědý, zelený, modrý, fialový a legendární zlatý/červený.
• Střed každého rámečku je průhledný, takže artwork karty zůstává viditelný v seznamu i v detailu celé karty.
• Rámečky zůstávají viditelné také u ztmavených, dosud nenaskenovaných karet; jejich artwork se stále zobrazuje pod tmavou vrstvou.
• Brainrot menu: Kolekce přes celý řádek; Týmy/Předměty; Schopnosti/Boosty; dole Training Duel/Training Pexeso.
• Odstraněna duplicitní dlaždice EAN Duel z Brainrot menu; herní funkce zůstává v aplikaci.

SKAN 0.7.0 — OPRAVA GRAFIKY A NÁHLEDŮ

• Opraveno načítání lokálních obrázků karet v detailu; obrázky z Android assets se načítají přímo přes AssetManager místo nespolehlivého Glide URI.
• Náhled celé karty už nezůstane prázdný/šedý při chybě načtení vzdáleného obrázku; zobrazí bezpečný grafický fallback podle univerza.
• Nenaskenované Brainrot karty znovu načítají ztmavené náhledy artworku v kolekci.
• Nabídka Brainrot používá grafické dlaždice Kolekce, Týmy, Předměty, Boosty, Schopnosti, Training Duel a Training Pexeso místo obyčejných fialových tlačítek.
• Historie Patch Notes zůstává zachována a nová verze je uvedena jako první.
• Hlavní obrazovka, počty nasbíraných karet, herní systémy a podpisový workflow zůstávají zachovány.

SKAN 0.6.9 — OPRAVA NÁHLEDU KARTY A NASTAVENÍ

• Nastavení používá grafické pozadí s pořadím VERZE, PATCH NOTES a ZAVŘÍT.
• Náhled celé karty zkouší při selhání velkého artworku načíst menší artwork.
• Spodní panel Brainrot karty obsahuje název, raritu, HP, ATK, DEF, SPD a schopnost.

SKAN 0.6.8 — POČTY KARET NA HLAVNÍ OBRAZOVCE

• Na dlaždicích Pokémon a Brainrot je zobrazen počet unikátních nasbíraných karet z celkového počtu.
• Zachována původní grafika dlaždic a navigace.

SKAN 0.6.6 — GRAFICKÉ MENU BRAINROT

• Nabídka Brainrot používá obrazové dlaždice pro Kolekci, Týmy, Předměty, Boosty, Schopnosti, Training Duel a Training Pexeso.
• Dlaždice zachovávají poměr stran a neobsahují další textové popisky přes grafiku.

SKAN 0.6.4 — UPRAVENÝ DOMOV, OBCHOD A SOUBOJ

• Hlavní obrazovka zobrazuje pouze Pokémon a Brainrot, každý jako velkou celoplošnou dlaždici pod sebou.
• STAR WARS a ostatní dočasně nezobrazovaná univerza byla z hlavní nabídky odstraněna.
• Nastavení a Obchod dostaly nové kulaté grafické ikony.
• Okna Nastavení a Obchodu používají nové grafické podklady SKAN.
• Funkce kolekcí, skenování, soubojů, itemů, boostů a ostatních herních systémů zůstávají beze změny.

• Obchod nyní používá jednotlivé grafické rámečky pro každou nabídku; v každém je čitelný název, síla, rarita, cena a popis.
• Battle obrazovka nyní používá skutečné náhledy obou Brainrot karet, jejich statistiky a malé ovládací prvky dole.
• Nastavení používá pořadí VERZE nahoře, PATCH NOTES uprostřed a ZAVŘÍT dole s černým textem uprostřed grafických tlačítek.

• Training Pexeso: výhra dává +1 Coin a zároveň ponechává 2,5% šanci na náhodný item, schopnost nebo boost.
• Při prohře Training Pexesa se nedává Coin ani náhodný drop.
• V průběhu Pexesa se aktuální počet životů zobrazuje přímo v okně hry.
• Rarita každé síly v obchodě se vybírá samostatně náhodně z Obyčejný / Vzácný / Epický a každá nabídka se obnovuje podle pravidla 10 otevření.

SKAN 0.6.3 — NOVÝ VZHLED HLAVNÍ NABÍDKY

• Hlavní obrazovka zobrazuje pouze Pokémon a Brainrot, každý jako velkou celoplošnou dlaždici pod sebou.
• STAR WARS a ostatní dočasně nezobrazovaná univerza byla z hlavní nabídky odstraněna.
• Nastavení a Obchod dostaly nové kulaté grafické ikony a grafická okna.
• Herní systémy zůstaly dostupné přes herní menu.

SKAN 0.6.1 — OPRAVY PEXESA, SOUBOJE A OBCHODU

• Training Pexeso má 10 dvojic, tedy 20 karet, a výhra už nedává Coin.
• Otočené karty v Training Pexesu zobrazují artwork náhodně vybraných Brainrotů z databáze; neotočené mají Brainrot-themed zadní stranu.
• Training Pexeso stále může mít 2,5% náhodný drop itemu, schopnosti nebo boostu.
• Opravena chyba, kvůli které mohl Training Duel spadnout při spuštění.
• Obchod používá ceny slabý 500 / střední 700 / silný 1000 Coins.
• Rarita nabídky v obchodě je Obyčejný / Vzácný / Epický a nabídky se náhodně obnovují každé 10. otevření.
• Bonus ceny rarity: Obyčejný +0, Vzácný +200, Epický +500 Coins.
• Zakoupený item nebo svitek je náhodně vybraný z nabídky a odpovídá zobrazené raritě.

SKAN 0.6.0 — VELKÝ SOUBOJOVÝ A ODMĚNOVÝ BUILD

• Coins: Training Duel +1, Training Pexeso +1, EAN Duel výhra +100 / prohra -10. Běžný sken odměňuje podle rarity.
• Brainrot rarity sjednoceny a část původních Legendárních byla deterministicky převedena na Epické.
• Boosty mají skutečný vliv na generátor a jen jeden může být aktivní.
• Přidány týmy 3 Brainrotů, itemy, svitky schopností a jejich vybavení.
• Přidán obchod s Coins a rozšířený battle systém.
• Training Pexeso používá Brainrot karty a odměny.
• Nenaskenované karty zůstávají v seznamu bez artworku a detail jej ukazuje pouze zašeděný.

SKAN 0.5.4 — HLAVNÍ OBRAZOVKA A HERNÍ MENU

• Zrušena kolekce VOZIDLA / HOT WHEELS z hlavní nabídky i výběru kolekcí.
• Itemy, Boosty, Training Duel a Pexeso jsou přesunuty z hlavní obrazovky do kompaktního výsuvného herního menu vedle Nastavení.
• Opravena chyba v katalogu univerz, která bránila kompilaci aplikace.
• Hlavní obrazovka zůstává přehledná a nové herní funkce nejsou zobrazené jako velké dlaždice.
• Herní funkce jsou stále dostupné jedním klepnutím z hlavní obrazovky.

SKAN 0.5.0 — BRAINROT HERNA A ODMĚNY

• Brainroty dostaly deterministické statistiky HP, ATK, DEF, SPD, archetyp a speciální schopnost.
• Přidány itemy získávané skenováním a samostatný inventář itemů.
• Přidány SKAN Coins a odměny za skeny, duely a pexeso.
• Přidány Boosty s omezeným počtem skenů: Luck Boost, Brainrot Boost a Rare Boost.
• Přidány náhodné duely při skenování a Training Duel s vlastním Brainrotem.
• Přidáno Pexeso s náhodnými odměnami.
• Přidány hlavní dlaždice Itemy, Boosty, Training Duel a Pexeso.
• Náhledy Brainrotů nyní zobrazují bojové statistiky a schopnost.
• Nenaskenované karty zůstávají skryté v seznamu a v detailu používají ztmavený artwork s NENASKENOVÁNO.
• Pokémon drop rates zůstávají 75 % / 17 % / 6 % / 2 % a Brainrot 60 % / 20 % / 12 % / 6 % / 2 %; generátor používá stejné hodnoty jako UI.
• Boosty mají omezené trvání na počet skenů a aktivní boost je viditelný na hlavní obrazovce.

SKAN 0.4.4 — AKTUÁLNÍ

• Brainrot nalezené karty nyní mají viditelný barevný rámeček podle rarity stejně jako Pokémon.
• Brainrot filtr nově obsahuje Vše, Nalezené, Rarita, Herní hodnota a Oblíbené.
• Ve všech univerzech jsou nalezené karty vždy první; zvolené řazení se stále uplatňuje uvnitř nalezených i nenalezených.
• Brainrot swipe nyní používá přesně aktuálně filtrovaný a seřazený seznam.

SKAN 0.4.3 — AKTUÁLNÍ

• Rarity jsou nyní v celé aplikaci česky: Běžný, Neobyčejný, Vzácný, Epický, Legendární.
• Přidáno zobrazení „Vzácný Holo“ pro Pokémon karty.
• Přidána kompletní historie Patch Notes přímo do aplikace.
• Nejnovější změny jsou nahoře a starší verze lze procházet posunutím nahoru/dolů.

SKAN 0.4.2

• Brainrot karty v kolekci dostaly rámečky podle rarity stejně jako Pokémon.
• Swipe v náhledu postupuje přesně podle aktuálně seřazeného seznamu.
• Přidáno řazení podle rarity pro Pokémon i Brainrot.
• Brainrot filtry: rarita, herní hodnota 1–8 a oblíbené.
• Brainrot řazení: datum nalezení, rarita, herní hodnota, abecedně a oblíbené.
• Herní hodnota 1–8 je viditelná i ve velkém náhledu.

SKAN 0.4.1

• Opraveno sestavení: rarity rámeček používá správnou funkci.
• Brainrot rarity: Běžný 60 %, Neobyčejný 20 %, Vzácný 12 %, Epický 6 %, Legendární 2 %.
• Pokémon rarity: Běžný 75 %, Neobyčejný 17 %, Vzácný 6 %, Vzácný Holo 2 %.
• Globální poměr Pokémon/Brainrot: 50/50; zaměření SKAN! jej mění na 60/40 nebo 40/60.

SKAN 0.4.0

• Sjednocený náhled Pokémon a Brainrot karet.
• Přidán swipe doleva/doprava mezi otevřenými kartami.
• Nenaskenované karty zobrazují ztmavený artwork s označením NENASKENOVÁNO.
• Rámečky rarity: Běžný hnědý, Neobyčejný zelený, Vzácný světle modrý, Epický fialový, Legendární oranžový/žlutý.
• Rarita a drop rate zůstávají viditelné u odemčených karet.

SKAN 0.3.9

• Globální loot Pokémon/Brainrot 50/50.
• Zaměření SKAN! na Pokémon: 60 % Pokémon / 40 % Brainrot.
• Zaměření SKAN! na Brainrot: 40 % Pokémon / 60 % Brainrot.
• Brainrot rarity: Běžný 60 %, Neobyčejný 20 %, Vzácný 12 %, Epický 6 %, Legendární 2 %.
• Pokémon rarity: Běžný 75 %, Neobyčejný 17 %, Vzácný 6 %, Vzácný Holo 2 %.

SKAN 0.3.8

• Brainrot drop rates byly změněny na Běžný 70 %, Neobyčejný 15 %, Vzácný 12 %, Legendární 3 %.
• Starší Epic metadata byla normalizována na Legendary.

SKAN 0.3.7

• Opraveno klikání na nenaskenované karty.
• Nenaskenaná karta otevře velký náhled artworku ztmavený přes overlay NENASKENOVÁNO.
• Odemčené karty zobrazují raritu a drop rate i v kolekci a náhledu.

SKAN 0.3.6

• Přidáno tlačítko Nastavení.
• Přidána obrazovka Patch Notes.
• Nenaskenované karty lze otevřít z kolekce.
• Náhled nenaskenované karty zobrazuje ztmavený artwork.

SKAN 0.3.5

• Duplicitní skenovaný výsledek se zobrazí ztmavený.
• Číslo karty je viditelné v kolekci i u zamčených karet.
• Zamčené karty zobrazují raritu a drop chance.
• Pokémon drop rates: Běžný 75 %, Neobyčejný 17 %, Vzácný 6 %, Vzácný Holo 2 %.
• Zachována deterministická vazba EAN → karta.
• Zachováno ukládání kolekce.
""".trimIndent()
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(6), dp(4), dp(6), dp(16))
        }
        scroll.addView(text)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(roundedButton("ZAVŘÍT") { dialog.dismiss() })
        dialog.setContentView(root)
        dialog.show()
        styleDialogWindow(dialog, 0.90f, 0.78f)
    }

    private fun iconButton(symbol: String, description: String): Button = Button(this).apply {
        text = symbol
        contentDescription = description
        textSize = 27f
        setTextColor(Color.WHITE)
        isAllCaps = false
        gravity = Gravity.CENTER
        includeFontPadding = false
        background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_icon_button)
        minWidth = 0
        minHeight = 0
        setPadding(0, 0, 0, 0)
    }

    private fun showDecksDialog() {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle("MOJE BALÍČKY"))
        root.addView(roundedButton("＋ NOVÝ BALÍČEK") { showNewDeckDialog(dialog) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        renderDeckList(root, dialog)
        root.addView(roundedButton("ZAVŘÍT") { dialog.dismiss() })
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.88f, 0.72f)
    }

    private fun showNewDeckDialog(parent: Dialog) {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle("NOVÝ BALÍČEK"))
        val input = EditText(this).apply { hint = "Název balíčku"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 18f; setSingleLine(true); background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_edit) }
        root.addView(input, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(roundedButton("ZRUŠIT") { dialog.dismiss() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        row.addView(roundedButton("VYTVOŘIT") {
            val name = input.text.toString().trim()
            if (name.isNotBlank()) { saveDeckNames(getDeckNames().toMutableSet().apply { add(name) }); dialog.dismiss(); parent.dismiss(); showDecksDialog() }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
        root.addView(row)
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.82f, 0.34f)
        input.requestFocus(); dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
    }

    private fun renderDeckList(root: LinearLayout, dialog: Dialog) {
        root.findViewWithTag<View>("deckList")?.let { root.removeView(it) }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "deckList" }
        getDeckNames().sorted().forEach { name ->
            val b = sectionButton("$name  •  ${getDeckCards(name).size} karet", true); b.setOnClickListener { showDeck(name) }; list.addView(b)
        }
        root.addView(list, (root.childCount - 1).coerceAtLeast(1))
    }

    private fun showNewDeckAndAddDialog(card: Card) {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle("NOVÝ BALÍČEK"))
        val input = EditText(this).apply { hint = "Název balíčku"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 18f; setSingleLine(true); background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_edit) }
        root.addView(input, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(roundedButton("ZRUŠIT") { dialog.dismiss() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        row.addView(roundedButton("VYTVOŘIT") {
            val name = input.text.toString().trim()
            if (name.isNotBlank()) { saveDeckNames(getDeckNames().toMutableSet().apply { add(name) }); addCardToDeck(name, card); dialog.dismiss(); Toast.makeText(this, "Přidáno do balíčku $name", Toast.LENGTH_SHORT).show() }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
        root.addView(row)
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.82f, 0.34f)
        input.requestFocus(); dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
    }

    private fun showDeckPicker(card: Card) {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle("PŘIDAT DO BALÍČKU"))
        getDeckNames().sorted().forEach { name ->
            val b = sectionButton(name, true); b.setOnClickListener { addCardToDeck(name, card); dialog.dismiss(); Toast.makeText(this, "Přidáno do balíčku $name", Toast.LENGTH_SHORT).show() }; root.addView(b)
        }
        root.addView(roundedButton("＋ NOVÝ BALÍČEK") { dialog.dismiss(); showNewDeckAndAddDialog(card) })
        root.addView(roundedButton("ZRUŠIT") { dialog.dismiss() })
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.84f, 0.64f)
    }

    private fun showDeck(name: String) {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle(name))
        val filter = makeSpinner(arrayOf("Vše", "Pokémon", "Energie", "Item", "Trainer", "Oblíbené")); root.addView(filter)
        val scroll = ScrollView(this); val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(roundedButton("ZAVŘÍT") { dialog.dismiss() })
        fun render() {
            content.removeAllViews()
            var list = cards.filter { getDeckCards(name).contains(it.id) }
            list = when (filter.selectedItem.toString()) {
                "Pokémon" -> list.filter { it.category.equals("Pokémon", true) }
                "Energie" -> list.filter { it.category.equals("Energy", true) || it.category.equals("Energie", true) }
                "Item" -> list.filter { it.category.equals("Trainer", true) && it.trainerSubtype.equals("Item", true) }
                "Trainer" -> list.filter { it.category.equals("Trainer", true) && !it.trainerSubtype.equals("Item", true) }
                "Oblíbené" -> list.filter { isFavorite(it) }
                else -> list
            }
            renderCards(content, list.sortedBy { it.number }, "Vše")
        }
        filter.onItemSelected { render() }
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.94f, 0.86f); render()
    }

    private fun getDeckNames(): Set<String> = prefs.getStringSet("deckNames", setOf("Můj balíček")) ?: setOf("Můj balíček")
    private fun saveDeckNames(names: Set<String>) { prefs.edit().putStringSet("deckNames", names).apply() }
    private fun getDeckCards(name: String): Set<String> = prefs.getStringSet("deck_$name", emptySet()) ?: emptySet()
    private fun addCardToDeck(name: String, card: Card) { prefs.edit().putStringSet("deck_$name", getDeckCards(name).toMutableSet().apply { add(card.id) }).apply() }

    private fun ownedCount(setId: String) = cards.count { it.setId == setId && isOwned(it) }
    private fun setTotal(setId: String) = cards.count { it.setId == setId }
    private fun ownedCountGeneration(gen: Int) = cards.count { it.generation == gen && isOwned(it) }
    private fun totalGeneration(gen: Int) = cards.count { it.generation == gen }

    private fun darkDialogRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_dialog)
    }
    private fun dialogTitle(text: String) = TextView(this).apply { this.text = text; textSize = 24f; setTextColor(Color.rgb(255,210,31)); setTypeface(typeface, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(10)) }
    private fun roundedButton(text: String, action: (View) -> Unit): Button = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 15f; setTextColor(Color.BLACK); setTypeface(typeface, android.graphics.Typeface.BOLD); background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_button); setOnClickListener(action); minHeight = dp(48)
    }
    private fun sectionButton(text: String, bold: Boolean): Button = roundedButton(text) {}.apply { textSize = if (bold) 16f else 15f; setOnClickListener(null) }
    private fun makeSpinner(items: Array<String>): Spinner {
        val spinner = Spinner(this)
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View = TextView(this@MainActivity).apply { text = items[position]; setTextColor(Color.WHITE); textSize = 13f; setPadding(dp(8), dp(10), dp(8), dp(10)) }
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); spinner.adapter = adapter; return spinner
    }
    private fun Spinner.onItemSelected(action: () -> Unit) = setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener { override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = action(); override fun onNothingSelected(parent: AdapterView<*>?) {} })

    private fun styleDialogWindow(dialog: Dialog, widthFraction: Float, heightFraction: Float) {
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * widthFraction).toInt(), (resources.displayMetrics.heightPixels * heightFraction).toInt())
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        barcodeScanner.close()
        executor.shutdownNow()
        artworkExecutor.shutdownNow()
        super.onDestroy()
    }

}
