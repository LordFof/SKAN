package cz.lordfof.skan

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Dialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.*
import kotlin.math.abs
import kotlin.random.Random
import androidx.core.view.children
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    private lateinit var cardImage: ImageView
    private lateinit var cardName: TextView
    private lateinit var cardInfo: TextView
    private lateinit var cardSet: TextView
    private lateinit var collectionButton: Button
    private lateinit var decksButton: Button
    private lateinit var settingsButton: Button
    private lateinit var gameMenuButton: Button
    private lateinit var scanStyleButton: ScanStyleButton
    private lateinit var mainContent: LinearLayout
    private lateinit var homeUniverseLayer: FrameLayout
    private val executor = Executors.newSingleThreadExecutor()
    private val artworkExecutor = Executors.newSingleThreadExecutor()
    private val scanning = AtomicBoolean(false)
    private val barcodeScanner = BarcodeScanning.getClient()

    // Ochrana proti předčasnému/kolísavému přečtení EANu.
    // Kód musí být rozpoznán opakovaně jako stejný kód, jinak se sken nepřijme.
    private var candidateCode: String? = null
    private var candidateFormat: Int = -1
    private var candidateHits: Int = 0
    private var candidateStartedAt: Long = 0L
    private var candidateLastAt: Long = 0L
    private var candidateCenterX: Float = 0f
    private var candidateCenterY: Float = 0f
    private var candidateWidth: Float = 0f
    private val prefs by lazy { getSharedPreferences("collection", MODE_PRIVATE) }
    private lateinit var cards: List<Card>
    private var scannerDialog: Dialog? = null

    private val cameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openScannerDialog()
        else Toast.makeText(this, "Bez povolení kamery SKAN nemůže skenovat EAN kódy.", Toast.LENGTH_LONG).show()
    }

    data class Card(
        val id: String,
        val number: Int,
        val name: String,
        val type: String,
        val element: String,
        val stage: String,
        val evolvesFrom: String,
        val evolutionFamily: String,
        val evolutionOrder: Int,
        val category: String,
        val trainerSubtype: String,
        val energySubtype: String,
        val rarity: String,
        val rarityNumber: Int,
        val setId: String,
        val setName: String,
        val generation: Int,
        val imageSmall: String,
        val imageLarge: String,
        val scannable: Boolean = true
    )

    data class BrainrotStats(val hp: Int, val atk: Int, val def: Int, val spd: Int, val archetype: String, val ability: String)
    data class SkanItem(val id: String, val name: String, val rarity: String, val type: String, val power: Int, val description: String, val count: Int)
    data class SkanBoost(val id: String, val name: String, val scans: Int, val description: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        cards = loadCards()

        cardImage = findViewById(R.id.cardImage)
        cardName = findViewById(R.id.cardName)
        cardInfo = findViewById(R.id.cardInfo)
        cardSet = findViewById(R.id.cardSet)
        collectionButton = findViewById(R.id.collectionButton)
        decksButton = findViewById(R.id.decksButton)
        settingsButton = findViewById(R.id.settingsButton)
        gameMenuButton = findViewById(R.id.gameMenuButton)
        mainContent = findViewById(R.id.mainContent)
        homeUniverseLayer = findViewById(R.id.homeUniverseLayer)

        // Hlavní obrazovka je navigace mezi univerzy. Sken je globální:
        // při prvním skenu může styl SKAN! jemně ovlivnit šanci univerza; po uložení
        // má EAN jednu pevnou kartu a další skeny ji už nikdy nemění.
        cardImage.visibility = View.INVISIBLE
        cardName.text = ""
        cardInfo.text = ""
        cardSet.text = ""

        scanStyleButton = findViewById(R.id.scan)
        scanStyleButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openScannerDialog()
            else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
        collectionButton.setOnClickListener { showCollectionUniversePicker() }
        decksButton.setOnClickListener { showDecksDialog() }
        settingsButton.setOnClickListener { showSettingsDialog() }
        gameMenuButton.setOnClickListener { showGameMenuDialog() }
        updateCollectionButton()
        buildHomeUniverses()
    }

    private fun loadCards(): List<Card> {
        val result = mutableListOf<Card>()
        val files = assets.list("") ?: emptyArray()
        files.filter { it.endsWith("_cards.json") }.forEach { file ->
            val root = JSONObject(assets.open(file).bufferedReader().use { it.readText() })
            val setId = root.optString("setId", file.substringBefore("_cards.json"))
            val setName = root.optString("setName", setId)
            val defaultGeneration = root.optInt("generation", 1)
            val a = root.getJSONArray("cards")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val numberText = o.optString("number", (i + 1).toString())
                val rawRarity = o.optString("rarity", "Common")
                val normalizedRarity = if (setId.startsWith("brainrot_", true) && rawRarity.equals("Epic", true)) "Legendary" else rawRarity
                result += Card(
                    id = o.getString("id"),
                    number = numberText.toIntOrNull() ?: (i + 1),
                    name = o.getString("name"),
                    type = o.optString("cardType", "Karta"),
                    element = readTextOrArray(o, "element", "elements", "types"),
                    stage = o.optString("stage", o.optString("evolutionStage", "")),
                    evolvesFrom = o.optString("evolvesFrom", ""),
                    evolutionFamily = o.optString("evolutionFamily", ""),
                    evolutionOrder = o.optInt("evolutionOrder", 0),
                    category = o.optString("category", o.optString("cardType", "")),
                    trainerSubtype = o.optString("trainerSubtype", ""),
                    energySubtype = o.optString("energySubtype", ""),
                    rarity = normalizedRarity,
                    rarityNumber = o.optInt("rarityNumber", rarityNumberFromName(normalizedRarity)),
                    setId = o.optString("setId", setId),
                    setName = o.optString("setName", setName),
                    generation = o.optInt("generation", defaultGeneration),
                    imageSmall = o.optString("imageSmall", o.optString("imageLarge")),
                    imageLarge = o.optString("imageLarge", ""),
                    scannable = o.optBoolean("scannable", true)
                )
            }
        }
        return result.sortedWith(compareBy<Card> { it.generation }.thenBy { it.setName }.thenBy { it.number })
    }

    private fun readTextOrArray(o: JSONObject, vararg keys: String): String {
        for (key in keys) {
            if (!o.has(key) || o.isNull(key)) continue
            val value = o.get(key)
            if (value is JSONArray) return (0 until value.length()).joinToString(", ") { value.optString(it) }
            val text = value.toString().trim()
            if (text.isNotEmpty()) return text
        }
        return ""
    }

    private data class Universe(
        val id: String,
        val title: String,
        val subtitle: String,
        val symbol: String,
        val colors: IntArray,
        val available: Boolean = false
    )

    private fun rarityDisplayName(rarity: String): String = when (rarity.lowercase()) {
        "common" -> "Běžný"
        "uncommon" -> "Neobyčejný"
        "rare" -> "Vzácný"
        "rare holo" -> "Vzácný Holo"
        "epic" -> "Epický"
        "legendary" -> "Legendární"
        else -> rarity
    }

    private fun rarityNumberFromName(rarity: String): Int = when (rarity.lowercase()) {
        "common" -> 2
        "uncommon" -> 4
        "rare" -> 6
        "rare holo" -> 8
        "legendary" -> 10
        "epic" -> 10
        else -> 4
    }

    private fun isBrainrot(card: Card): Boolean = card.setId.startsWith("brainrot_", true)

    private fun brainrotCardView(card: Card, width: Int, height: Int, interactive: Boolean = true, allowRemote: Boolean = true, navigationCards: List<Card> = cards.filter { it.setId == card.setId }): FrameLayout {
        val frame = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(35, 35, 42), Color.rgb(10, 10, 14))).apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(3), rarityFrameColor(card.rarity))
            }
            // Stejný viditelný barevný rámeček jako u Pokémon karet.
            setPadding(dp(3), dp(3), dp(3), dp(3))
            clipToOutline = true
            elevation = dp(5).toFloat()
            if (interactive) setOnClickListener { showCardViewer(card, navigationCards) }
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(20, 20, 24))
            contentDescription = card.name
        }
        frame.addView(image, FrameLayout.LayoutParams(-1, -1))
        if (card.scannable && card.imageLarge.isNotBlank()) {
            val cached = cachedArtworkFile(card)
            if (cached != null) {
                loadCardArtwork(image, cached)
            } else if (allowRemote || isOwned(card)) {
                // Naskenovaná karta se zobrazí ihned z URL, pokud ještě nestihl
                // doběhnout lokální cache. Po stažení už kolekce používá jen cache.
                loadCardArtwork(image, card.imageLarge)
            }
        } else if (!card.scannable) {
            addLockedCardOverlay(frame, width)
        }

        // Karty, které ještě nebyly nalezené, nikdy neukazují artwork ani název.
        if (card.scannable && !isOwned(card)) {
            image.setImageDrawable(null)
            image.setBackgroundColor(Color.rgb(12, 12, 16))
            addLockedCardOverlay(frame, width)
        }

        val topShade = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(185,0,0,0), Color.TRANSPARENT))
        }
        frame.addView(topShade, FrameLayout.LayoutParams(-1, dp(58), Gravity.TOP))

        val number = TextView(this).apply {
            text = "#${card.number}"
            textSize = 13f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setShadowLayer(5f, 1f, 1f, Color.BLACK)
            setPadding(dp(9), dp(6), 0, 0)
        }
        frame.addView(number, FrameLayout.LayoutParams(dp(75), dp(40), Gravity.TOP or Gravity.START))

        val rarity = TextView(this).apply {
            text = card.rarityNumber.toString()
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(rarityFrameColor(card.rarity))
                setStroke(dp(1), Color.argb(180,255,255,255))
            }
        }
        frame.addView(rarity, FrameLayout.LayoutParams(dp(38), dp(38), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(7); rightMargin = dp(7)
        })

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(9))
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.argb(220,0,0,0), Color.TRANSPARENT))
        }
        bottom.addView(TextView(this).apply {
            text = card.name
            textSize = if (width < dp(180)) 13f else 18f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(-1, -2))
        bottom.addView(TextView(this).apply {
            text = if (isBrainrot(card)) { val s=brainrotStats(card); "${rarityDisplayName(card.rarity)}  •  ${rarityDropPercent(card.rarity, true)}  •  ${s.hp}/${s.atk}/${s.def}/${s.spd}" } else "${rarityDisplayName(card.rarity)}  •  ${rarityDropPercent(card.rarity, false)}"
            textSize = if (width < dp(180)) 10f else 12f
            setTextColor(Color.LTGRAY)
        }, LinearLayout.LayoutParams(-1, -2))
        frame.addView(bottom, FrameLayout.LayoutParams(-1, dp(if (width < dp(180)) 55 else 76), Gravity.BOTTOM))
        frame.layoutParams = LinearLayout.LayoutParams(width, height)
        return frame
    }

    private fun rarityFrameColor(rarity: String): Int = when (rarity.lowercase()) {
        "common" -> Color.rgb(150, 92, 48)
        "uncommon" -> Color.rgb(65, 165, 95)
        "rare", "rare holo" -> Color.rgb(105, 190, 235)
        "epic" -> Color.rgb(150, 80, 210)
        "legendary" -> Color.rgb(245, 175, 35)
        else -> Color.rgb(125, 125, 135)
    }

    private fun rarityStrokeDrawable(rarity: String, radiusDp: Int = 14, strokeDp: Int = 3): GradientDrawable =
        GradientDrawable().apply {
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(strokeDp), rarityFrameColor(rarity))
        }

    private fun universeCatalog(): List<Universe> = listOf(
        Universe("pokemon", "POKÉMON", "Karty a sbírky", "⚡", intArrayOf(Color.rgb(35, 60, 130), Color.rgb(150, 25, 45)), true),
        Universe("starwars", "STAR WARS", "Galaxie", "★", intArrayOf(Color.rgb(15, 15, 18), Color.rgb(80, 80, 92))),
        Universe("brainrot", "BRAINROT", "Chaos a memy", "◉", intArrayOf(Color.rgb(80, 30, 110), Color.rgb(190, 65, 125))),
        Universe("animals", "ZVÍŘATA", "Divoká i domácí", "♞", intArrayOf(Color.rgb(25, 90, 65), Color.rgb(120, 150, 45))),
        Universe("monsters", "MONSTRA", "Tvory z temnoty", "☠", intArrayOf(Color.rgb(35, 20, 55), Color.rgb(105, 35, 120)))
    )

    private fun buildHomeUniverses() {
        val root = findViewById<FrameLayout>(R.id.homeUniverseLayer) ?: return
        root.removeAllViews()
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setPadding(dp(10), dp(18), dp(10), dp(92))
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val grid = GridLayout(this).apply { columnCount = 2; useDefaultMargins = false }
        universeCatalog().forEach { universe ->
            val tile = createUniverseTile(universe)
            tile.setOnClickListener { showUniverseMenu(universe) }
            grid.addView(tile, GridLayout.LayoutParams().apply {
                width = 0
                height = dp(138)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(6), dp(6), dp(6), dp(6))
            })
        }
        content.addView(TextView(this).apply {
            text = "🪙 SKAN Coins: ${coins()}"
            textSize = 18f; setTextColor(Color.WHITE); setTypeface(typeface,android.graphics.Typeface.BOLD); gravity=Gravity.CENTER
            setPadding(0,dp(4),0,dp(10))
        }, LinearLayout.LayoutParams(-1,-2))
        content.addView(grid, LinearLayout.LayoutParams(-1, -2))

        scroll.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
    }

    private fun coins(): Int = prefs.getInt("skanCoins", 0)
    private fun addCoins(amount: Int) { prefs.edit().putInt("skanCoins", (coins()+amount).coerceAtLeast(0)).apply(); refreshHomeRewards() }
    private fun refreshHomeRewards() { buildHomeUniverses() }
    private fun actionRewardTile(title: String, subtitle: String): View = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(dp(8),dp(8),dp(8),dp(8))
        background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(28,30,38),Color.rgb(12,13,18))).apply{cornerRadius=dp(18).toFloat();setStroke(dp(1),Color.rgb(70,74,88))}
        addView(TextView(this@MainActivity).apply{text=title;textSize=17f;setTextColor(Color.WHITE);setTypeface(typeface,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER})
        addView(TextView(this@MainActivity).apply{text=subtitle;textSize=10f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER})
    }

    private fun brainrotStats(card: Card): BrainrotStats {
        val h=MessageDigest.getInstance("SHA-256").digest(("stats:"+card.id).toByteArray())
        fun b(i:Int)=h[i].toInt() and 255
        val archetype=when(b(0)%4){0->"Útočník";1->"Tank";2->"Rychlík";else->"Vyvážený"}
        val mult=when(card.rarity.lowercase()){"common"->1.0;"uncommon"->1.12;"rare"->1.28;"epic"->1.48;"legendary"->1.72;else->1.0}
        var hp=(70+b(1)%51)*mult; var atk=(12+b(2)%15)*mult; var def=(8+b(3)%13)*mult; var spd=(8+b(4)%13)*mult
        when(archetype){"Útočník"->atk*=1.18;"Tank"->{hp*=1.22;def*=1.18;spd*=0.88};"Rychlík"->{spd*=1.25;atk*=0.94};}
        val ability=when(archetype){"Útočník"->"Zuřivý úder";"Tank"->"Neprůstřelný pancíř";"Rychlík"->"Bleskový tah";else->"Chaosový balans"}
        return BrainrotStats(hp.toInt(),atk.toInt(),def.toInt(),spd.toInt(),archetype,ability)
    }

    private fun itemList(): MutableList<SkanItem> {
        val raw=prefs.getString("skanItems","[]") ?: "[]"; val a=JSONArray(raw); val out=mutableListOf<SkanItem>()
        for(i in 0 until a.length()){val o=a.getJSONObject(i);out+=SkanItem(o.getString("id"),o.getString("name"),o.getString("rarity"),o.getString("type"),o.getInt("power"),o.getString("description"),o.getInt("count"))}; return out
    }
    private fun saveItems(items:List<SkanItem>){val a=JSONArray();items.forEach{a.put(JSONObject().apply{put("id",it.id);put("name",it.name);put("rarity",it.rarity);put("type",it.type);put("power",it.power);put("description",it.description);put("count",it.count)})};prefs.edit().putString("skanItems",a.toString()).apply()}
    private fun addItem(item:SkanItem){val l=itemList();val i=l.indexOfFirst{it.id==item.id};if(i>=0)l[i]=l[i].copy(count=l[i].count+1) else l.add(item);saveItems(l)}
    private fun boostList(): MutableList<SkanBoost> { val a=JSONArray(prefs.getString("skanBoosts","[]") ?: "[]");val o=mutableListOf<SkanBoost>();for(i in 0 until a.length()){val x=a.getJSONObject(i);o+=SkanBoost(x.getString("id"),x.getString("name"),x.getInt("scans"),x.getString("description"))};return o }
    private fun saveBoosts(l:List<SkanBoost>){val a=JSONArray();l.forEach{a.put(JSONObject().apply{put("id",it.id);put("name",it.name);put("scans",it.scans);put("description",it.description)})};prefs.edit().putString("skanBoosts",a.toString()).apply()}
    private fun addBoost(id:String,name:String,scans:Int,desc:String){val l=boostList();val i=l.indexOfFirst{it.id==id};if(i>=0)l[i]=l[i].copy(scans=l[i].scans+scans)else l.add(SkanBoost(id,name,scans,desc));saveBoosts(l)}

    private fun itemFromEan(ean:String): SkanItem? { val d=MessageDigest.getInstance("SHA-256").digest(("item:"+ean).toByteArray()); if((d[0].toInt() and 255)>=205)return null; val r=(d[1].toInt() and 255)%100; val rarity=when{r<65->"Běžný";r<90->"Neobyčejný";r<98->"Vzácný";else->"Legendární"};val defs=listOf("Zbraň" to "Plazmová čepel","Štít" to "Energetický štít","Heal" to "Regenerační ampule","Reroll" to "Reroll token","Boost" to "Skenovací boost");val x=defs[(d[2].toInt() and 255)%defs.size];return SkanItem("${x.second.lowercase().replace(" ","_")}_$rarity",x.second,rarity,x.first,5+(d[3].toInt() and 15),"Jednorázový předmět získaný skenem.",1)}

    private fun showItemsDialog(){val d=Dialog(this);val root=darkDialogRoot();root.addView(dialogTitle("🎒 ITEMY  •  ${itemList().sumOf{it.count}}"));val l=itemList();if(l.isEmpty())root.addView(sectionButton("Zatím nemáš žádné itemy.",true));else l.sortedByDescending{raritySortRank(it.rarity)}.forEach{root.addView(sectionButton("${it.name}  •  ${it.rarity}  •  ×${it.count}\n${it.type} — ${it.description}",true))};root.addView(roundedButton("ZAVŘÍT"){d.dismiss()});d.setContentView(root);d.show();styleDialogWindow(d,.90f,.78f)}
    private fun showBoostsDialog(){val d=Dialog(this);val root=darkDialogRoot();root.addView(dialogTitle("🍀 BOOSTY"));val l=boostList();if(l.isEmpty())root.addView(sectionButton("Žádné aktivní boosty.",true));l.forEach{b->val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};row.addView(sectionButton("${b.name}  •  ${b.scans} skenů\n${b.description}",true),LinearLayout.LayoutParams(0,-2,1f));val use=roundedButton("AKTIVOVAT"){activateBoost(b.id,d)};row.addView(use,LinearLayout.LayoutParams(dp(120),-2));root.addView(row)};root.addView(roundedButton("ZAVŘÍT"){d.dismiss()});d.setContentView(root);d.show();styleDialogWindow(d,.94f,.78f)}
    private fun activateBoost(id:String,d:Dialog){val l=boostList();val i=l.indexOfFirst{it.id==id};if(i<0)return;val b=l[i];prefs.edit().putString("activeBoost",b.id).putInt("activeBoostScans",b.scans).apply();l.removeAt(i);saveBoosts(l);Toast.makeText(this,"Aktivní boost: ${b.name} • ${b.scans} skenů",Toast.LENGTH_SHORT).show();d.dismiss()}
    private fun activeBoostId(): String = prefs.getString("activeBoost", "") ?: ""
    private fun activeBoostScans(): Int = prefs.getInt("activeBoostScans", 0)
    private fun consumeActiveBoost(){ val n=activeBoostScans(); if(n<=1) prefs.edit().remove("activeBoost").putInt("activeBoostScans",0).apply() else prefs.edit().putInt("activeBoostScans",n-1).apply() }

    private fun showTrainingDuelDialog(){val owned=cards.filter{isBrainrot(it)&&isOwned(it)};if(owned.size<2){Toast.makeText(this,"Pro Training Duel potřebuješ alespoň 2 nalezené Brainroty.",Toast.LENGTH_LONG).show();return};val a=owned[0];val b=owned[1];showDuelDialog(a,b,true)}
    private fun showDuelDialog(player:Card,enemy:Card,training:Boolean){val d=Dialog(this);val root=darkDialogRoot();root.addView(dialogTitle(if(training)"⚔ TRAINING DUEL" else "⚔ NÁHODNÝ DUEL"));var ph=brainrotStats(player).hp;var eh=brainrotStats(enemy).hp;val status=TextView(this).apply{setTextColor(Color.WHITE);textSize=16f;gravity=Gravity.CENTER};root.addView(status);fun render(){status.text="${player.name}: $ph HP\nVS\n${enemy.name}: $eh HP"};render();val buttons=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};buttons.addView(roundedButton("⚔ ZAÚTOČIT"){val ps=brainrotStats(player);val es=brainrotStats(enemy);val roll=Random.nextInt(1,21);val dmg=(ps.atk+roll-es.def/2).coerceAtLeast(1);eh-=dmg;if(eh>0){val er=Random.nextInt(1,21);ph-=(es.atk+er-ps.def/2).coerceAtLeast(1)};render();if(eh<=0||ph<=0){addCoins(if(eh<=0)25 else 5);Toast.makeText(this,"Duel skončil. Odměna: ${if(eh<=0)25 else 5} Coins",Toast.LENGTH_LONG).show();d.dismiss()}});buttons.addView(roundedButton("🎒 POUŽÍT ITEM"){val it=itemList().firstOrNull();if(it==null)Toast.makeText(this,"Nemáš item.",Toast.LENGTH_SHORT).show()else{val l=itemList();val idx=l.indexOfFirst{x->x.id==it.id};l[idx]=it.copy(count=it.count-1);if(l[idx].count<=0)l.removeAt(idx);saveItems(l);when(it.type){"Zbraň"->eh-=(it.power+Random.nextInt(1,7));"Štít"->ph+=(it.power*2).coerceAtMost(brainrotStats(player).hp-ph);"Heal"->ph+=(it.power*3).coerceAtMost(brainrotStats(player).hp-ph);"Reroll"->{ val roll=Random.nextInt(1,21); eh-=(brainrotStats(player).atk+roll); Toast.makeText(this,"Reroll: nový hod ${roll}.",Toast.LENGTH_SHORT).show() };"Boost"->addBoost("luck","Luck Boost",3,"+lepší rarity na 3 skeny")};render()}});buttons.addView(roundedButton("✨ SCHOPNOST"){val ps=brainrotStats(player);when(ps.archetype){"Útočník"->eh-=(ps.atk+Random.nextInt(8,18));"Tank"->ph+=(ps.def).coerceAtMost(brainrotStats(player).hp-ph);"Rychlík"->eh-=(ps.spd/2+Random.nextInt(4,10));else-> {ph+=(ps.def/2).coerceAtMost(brainrotStats(player).hp-ph);eh-=(ps.atk/2)}};render()});buttons.addView(roundedButton("🍀 POUŽÍT BOOST"){val b=boostList().firstOrNull();if(b==null)Toast.makeText(this,"Nemáš boost.",Toast.LENGTH_SHORT).show()else{activateBoost(b.id,d)}});root.addView(buttons);root.addView(roundedButton("ZAVŘÍT"){d.dismiss()});d.setContentView(root);d.show();styleDialogWindow(d,.90f,.75f)}

    private fun showMemoryDialog(){val d=Dialog(this);val root=darkDialogRoot();root.addView(dialogTitle("🃏 PEXESO"));val status=TextView(this).apply{text="Najdi 3 dvojice. Každý pokus je skrytý; výhra dá náhodnou odměnu.";setTextColor(Color.WHITE);setPadding(dp(8),dp(8),dp(8),dp(8))};root.addView(status);val grid=GridLayout(this).apply{columnCount=3};val vals=(1..6).flatMap{listOf(it,it)}.shuffled();var opened=0;var matches=0;vals.forEachIndexed{idx,v->val b=Button(this).apply{text="?";setTextColor(Color.WHITE);setOnClickListener{if(text=="?"){text="${v}";opened++;if(opened==2){val shown=grid.children.filterIsInstance<Button>().filter{it.text.toString()!="?"}.map{it.text.toString()};if(shown.count{it==v.toString()}>=2){matches++}; if(matches>=3){val reward=Random.nextInt(0,3);when(reward){0->addCoins(30);1->addItem(SkanItem("pex_item","Pexeso item","Běžný","Heal",8,"Odměna z pexesa.",1));2->{ val bid=when(Random.nextInt(3)){0->"luck";1->"brainrot";else->"rare"}; val bn=when(bid){"luck"->"Luck Boost";"brainrot"->"Brainrot Boost";else->"Rare Boost"}; val bd=when(bid){"luck"->"+lepší rarity na 3 skeny";"brainrot"->"+šance na Brainrot na 3 skeny";else->"+šance na vzácnost na 3 skeny"}; addBoost(bid,bn,3,bd)}};Toast.makeText(this@MainActivity,"Vyhráno!",Toast.LENGTH_LONG).show();d.dismiss()}else{grid.postDelayed({grid.children.filterIsInstance<Button>().forEach{if(it.text.toString()!="?")it.text="?"};opened=0},450)}}}}};grid.addView(b,GridLayout.LayoutParams().apply{width=0;height=dp(70);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)})};root.addView(grid);root.addView(roundedButton("ZAVŘÍT"){d.dismiss()});d.setContentView(root);d.show();styleDialogWindow(d,.92f,.75f)}

    private fun createUniverseTile(universe: Universe): View {
        val tile = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, universe.colors).apply {
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.argb(85, 255, 255, 255))
            }
            elevation = dp(3).toFloat()
            clipToOutline = true
        }

        val imageRes = when (universe.id.lowercase()) {
            "pokemon" -> R.drawable.universe_pokemon_tile
            "starwars" -> R.drawable.universe_starwars_tile
            "brainrot" -> R.drawable.universe_brainrot_tile
            "hotwheels" -> R.drawable.universe_hotwheels_tile
            else -> 0
        }
        if (imageRes != 0) {
            tile.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setImageResource(imageRes)
                adjustViewBounds = true
            }, FrameLayout.LayoutParams(-1, -1))
        } else {
            val glow = TextView(this).apply {
                text = universe.symbol
                textSize = 50f
                setTextColor(Color.argb(105, 255, 255, 255))
                gravity = Gravity.CENTER
            }
            tile.addView(glow, FrameLayout.LayoutParams(-1, -1))
        }
        // Postup sbírky přímo na hlavní dlaždici: unikátní karty / celkový počet.
        val owned = ownedCountForUniverse(universe.id)
        val total = totalCountForUniverse(universe.id)
        val countBadge = TextView(this).apply {
            text = "$owned / $total"
            textSize = 16f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(2), dp(10), dp(2))
            background = GradientDrawable().apply {
                setColor(Color.argb(215, 0, 0, 0))
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.argb(160, 255, 255, 255))
            }
            elevation = dp(8).toFloat()
        }
        tile.addView(countBadge, FrameLayout.LayoutParams(-2, dp(34), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            setMargins(dp(10), 0, dp(10), dp(8))
        })
        // Badge musí být vždy nad obrázkem dlaždice.
        countBadge.bringToFront()
        return tile
    }

    private fun cardsForUniverse(universeId: String): List<Card> = when (universeId.lowercase()) {
        "pokemon" -> cards.filter { it.setId.startsWith("base1", true) }
        "starwars" -> cards.filter { it.setId.startsWith("sw_", true) }
        "brainrot" -> cards.filter { it.setId.startsWith("brainrot_", true) }
        "hotwheels" -> cards.filter { it.setId.startsWith("hotwheels_", true) }
        "animals" -> cards.filter { it.setId.startsWith("animals_", true) }
        "monsters" -> cards.filter { it.setId.startsWith("monsters_", true) }
        "vehicles" -> cards.filter { it.setId.startsWith("vehicles_", true) }
        "everything" -> cards
        else -> emptyList()
    }

    private fun ownedCountForUniverse(universeId: String): Int {
        val ownedIds = scanMap().values.toSet()
        return cardsForUniverse(universeId).count { it.id in ownedIds || prefs.getBoolean(it.id, false) }
    }

    private fun totalCountForUniverse(universeId: String): Int = cardsForUniverse(universeId).size

        private fun installBlankSpaceBack(scroll: ScrollView, action: () -> Unit) {
        var downX = 0f
        var downY = 0f
        fun clickableHit(view: View, rawX: Float, rawY: Float): Boolean {
            if (view !== scroll && view.isClickable) {
                val rect = android.graphics.Rect()
                view.getGlobalVisibleRect(rect)
                if (rect.contains(rawX.toInt(), rawY.toInt())) return true
            }
            if (view is android.view.ViewGroup) {
                for (i in 0 until view.childCount) {
                    if (clickableHit(view.getChildAt(i), rawX, rawY)) return true
                }
            }
            return false
        }
        scroll.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY }
                MotionEvent.ACTION_UP -> {
                    val moved = kotlin.math.abs(event.rawX - downX) > dp(12) || kotlin.math.abs(event.rawY - downY) > dp(12)
                    if (!moved && !clickableHit(scroll, event.rawX, event.rawY)) {
                        action()
                    }
                }
            }
            false
        }
    }

    private fun showUniverseMenu(universe: Universe) {
        val dialog = Dialog(this)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        val scroll = ScrollView(this).apply { setPadding(dp(14), dp(22), dp(14), dp(90)) }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = universe.title
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setShadowLayer(6f, 1f, 1f, Color.BLACK)
            setPadding(0, dp(8), 0, dp(14))
        }
        content.addView(title, LinearLayout.LayoutParams(-1, -2))
        val grid = GridLayout(this).apply { columnCount = 2; useDefaultMargins = false }
        val actions = listOf(
            Triple("collection", "KOLEKCE", "▦"),
            Triple("packs", "BALÍČKY", "▣"),
            Triple("teams", "TÝMY", "♟"),
            Triple("duel", "EAN DUEL", "⚔")
        )
        actions.forEach { (id, label, symbol) ->
            val tile = createActionTile(label, symbol, universe)
            tile.setOnClickListener {
                when (id) {
                    "collection" -> { showCollectionDialog(universe) }
                    "packs" -> { dialog.dismiss(); Toast.makeText(this, "Balíčky pro ${universe.title} budou v další části.", Toast.LENGTH_SHORT).show() }
                    "teams" -> { dialog.dismiss(); Toast.makeText(this, "Týmy pro ${universe.title} budou navázané na EAN duel.", Toast.LENGTH_SHORT).show() }
                    "duel" -> { dialog.dismiss(); Toast.makeText(this, "EAN Duel připravíme až s výměnou karet a souboji.", Toast.LENGTH_SHORT).show() }
                }
            }
            grid.addView(tile, GridLayout.LayoutParams().apply {
                width = 0; height = dp(126)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(6), dp(6), dp(6), dp(6))
            })
        }
        content.addView(grid, LinearLayout.LayoutParams(-1, -2))
        scroll.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        installBlankSpaceBack(scroll) { dialog.dismiss() }
        dialog.setContentView(root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.attributes = dialog.window?.attributes?.apply { dimAmount = 0.78f }
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun rarityDropPercent(rarity: String, brainrot: Boolean = false): String {
        if (brainrot) return when (rarity.lowercase()) {
            "common" -> "60%"
            "uncommon" -> "20%"
            "rare" -> "12%"
            "epic" -> "6%"
            "legendary" -> "2%"
            else -> "—"
        }
        return when (rarity.lowercase()) {
            "common" -> "75%"
            "uncommon" -> "17%"
            "rare" -> "6%"
            "rare holo" -> "2%"
            else -> "—"
        }
    }

    private fun addLockedCardOverlay(frame: FrameLayout, width: Int) {
        val lock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        lock.addView(TextView(this@MainActivity).apply {
            text = "🔒"
            textSize = if (width < dp(180)) 28f else 42f
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        lock.addView(TextView(this@MainActivity).apply {
            text = "NENASKENOVÁNO"
            textSize = if (width < dp(180)) 11f else 15f
            setTextColor(Color.rgb(255,210,31))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        frame.addView(lock, FrameLayout.LayoutParams(-1, -1))
    }

    private fun createBrainrotCollectionTile(universe: Universe): View {
        return FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, universe.colors).apply {
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.argb(90, 255, 255, 255))
            }
            elevation = dp(3).toFloat()
            clipToOutline = true
            addView(ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.FIT_XY
                setImageResource(R.drawable.universe_brainrot_tile)
            }, FrameLayout.LayoutParams(-1, -1))
            addView(View(this@MainActivity).apply {
                setBackgroundColor(Color.argb(55, 0, 0, 0))
            }, FrameLayout.LayoutParams(-1, -1))
            addView(TextView(this@MainActivity).apply {
                text = "BRAINROT"
                textSize = 22f
                setTextColor(Color.WHITE)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                setShadowLayer(6f, 1f, 1f, Color.BLACK)
            }, FrameLayout.LayoutParams(-1, -1))
        }
    }

    private fun createActionTile(label: String, symbol: String, universe: Universe): View {
        return FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(universe.colors[0], universe.colors[1])).apply {
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.argb(90, 255, 255, 255))
            }
            elevation = dp(3).toFloat()
            val icon = TextView(this@MainActivity).apply {
                text = symbol; textSize = 38f; setTextColor(Color.argb(90,255,255,255)); gravity = Gravity.CENTER
            }
            addView(icon, FrameLayout.LayoutParams(-1,-1))
            addView(TextView(this@MainActivity).apply {
                text = label; textSize = 17f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER; setShadowLayer(5f,1f,1f,Color.BLACK)
            }, FrameLayout.LayoutParams(-1,-1))
        }
    }

    private fun openScannerDialog() {
        if (scannerDialog?.isShowing == true) return
        resetScanCandidate()
        scanning.set(true)
        val dialog = Dialog(this)
        scannerDialog = dialog
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_dialog)
        }
        val preview = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(preview, LinearLayout.LayoutParams(dp(290), dp(290)).apply { gravity = Gravity.CENTER })
        root.addView(TextView(this).apply {
            text = "Namiř čtvereček na EAN čárový kód"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        root.addView(roundedButton("ZRUŠIT") { scanning.set(false); dialog.dismiss() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        dialog.setContentView(root)
        dialog.setCancelable(false)
        dialog.show()
        styleDialogWindow(dialog, 0.90f, 0.76f)
        startCamera(preview, dialog)
    }

    private fun startCamera(preview: PreviewView, dialog: Dialog) {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(executor) { proxy ->
                    val media = proxy.image
                    if (media == null || !scanning.get()) { proxy.close(); return@setAnalyzer }
                    val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                    barcodeScanner.process(image)
                        .addOnSuccessListener { codes ->
                            if (!scanning.get()) return@addOnSuccessListener

                            // Přijímáme jen skutečné EAN/UPC formáty a platný kontrolní součet.
                            // Když je v záběru více kódů, dáme přednost největšímu a nejcentrálnějšímu.
                            val candidate = codes
                                .mapNotNull { barcode ->
                                    val normalized = normalizeEan(barcode) ?: return@mapNotNull null
                                    val box = barcode.boundingBox
                                    if (box == null) return@mapNotNull null
                                    val centerX = (box.left + box.right) / 2f
                                    val centerY = (box.top + box.bottom) / 2f
                                    val area = box.width().toFloat() * box.height().toFloat()
                                    val frameCenter = image.width / 2f
                                    val centerDistance = kotlin.math.abs(centerX - frameCenter)
                                    Triple(barcode, normalized, area - centerDistance * 150f)
                                }
                                .maxByOrNull { it.third }

                            if (candidate == null) {
                                resetScanCandidate()
                            } else {
                                val barcode = candidate.first
                                val code = candidate.second
                                if (registerScanCandidate(code, barcode)) {
                                    if (scanning.compareAndSet(true, false)) {
                                        runOnUiThread {
                                            dialog.dismiss()
                                            scannerDialog = null
                                            showScanResult(code)
                                        }
                                    }
                                }
                            }
                        }
                        .addOnCompleteListener { proxy.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
                dialog.setOnDismissListener { scanning.set(false); provider.unbindAll(); scannerDialog = null }
            } catch (_: Exception) {
                scanning.set(false); dialog.dismiss(); Toast.makeText(this, "Kameru se nepodařilo otevřít.", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun normalizeEan(barcode: Barcode): String? {
        val raw = barcode.rawValue?.filter(Char::isDigit) ?: return null
        val normalized = when (barcode.format) {
            Barcode.FORMAT_EAN_13 -> if (raw.length == 13) raw else return null
            Barcode.FORMAT_EAN_8 -> if (raw.length == 8) raw else return null
            Barcode.FORMAT_UPC_A -> if (raw.length == 12) "0$raw" else return null
            else -> return null
        }
        return if (hasValidEanChecksum(normalized)) normalized else null
    }

    private fun hasValidEanChecksum(code: String): Boolean {
        if (code.length != 8 && code.length != 13) return false
        val digits = code.map { it - '0' }
        var sum = 0
        for (i in 0 until digits.lastIndex) {
            val positionFromRight = digits.lastIndex - i
            sum += if (positionFromRight % 2 == 1) digits[i] * 3 else digits[i]
        }
        val check = (10 - (sum % 10)) % 10
        return check == digits.last()
    }

    private fun registerScanCandidate(code: String, barcode: Barcode): Boolean {
        val now = System.currentTimeMillis()
        val box = barcode.boundingBox
        val centerX = box?.let { (it.left + it.right) / 2f } ?: 0f
        val centerY = box?.let { (it.top + it.bottom) / 2f } ?: 0f
        val width = box?.width()?.toFloat() ?: 0f

        val sameCandidate = candidateCode == code && candidateFormat == barcode.format
        val withinTime = candidateLastAt == 0L || now - candidateLastAt <= 700L
        val stablePosition = if (sameCandidate && candidateWidth > 0f && width > 0f) {
            val widthRatio = width / candidateWidth
            val positionOk = kotlin.math.abs(centerX - candidateCenterX) <= candidateWidth * 0.45f &&
                    kotlin.math.abs(centerY - candidateCenterY) <= candidateWidth * 0.70f
            positionOk && widthRatio in 0.55f..1.80f
        } else {
            true
        }

        if (sameCandidate && withinTime && stablePosition) {
            candidateHits += 1
        } else {
            candidateCode = code
            candidateFormat = barcode.format
            candidateHits = 1
            candidateStartedAt = now
        }

        candidateLastAt = now
        candidateCenterX = centerX
        candidateCenterY = centerY
        if (width > 0f) candidateWidth = width

        // Čtyři po sobě jdoucí stabilní snímky stejného EANu = potvrzený sken.
        return candidateHits >= 4 && now - candidateStartedAt <= 1500L
    }

    private fun resetScanCandidate() {
        candidateCode = null
        candidateFormat = -1
        candidateHits = 0
        candidateStartedAt = 0L
        candidateLastAt = 0L
        candidateCenterX = 0f
        candidateCenterY = 0f
        candidateWidth = 0f
    }

    private fun showScanResult(ean: String) {
        // První sken EANu použije právě zvolený SKAN! pouze jako jemnou preferenci univerza.
        // Jakmile je karta pro EAN jednou uložena, už se nikdy nemění a všechny další skeny
        // stejného EANu dostanou přesně tutéž kartu bez ohledu na zvolený styl tlačítka.
        val alreadyThisBarcode = hasScannedBarcode(ean)
        val card = if (alreadyThisBarcode) {
            deterministicCardForEan(ean, null)
        } else {
            deterministicCardForEan(ean, scanStyleButton.selectedStyleId())
        }
        if (!alreadyThisBarcode) {
            saveScan(ean, card)
            addCoins(10)
            itemFromEan(ean)?.let { item ->
                addItem(item)
                if (item.type == "Boost") {
                    val boostId = when ((item.id.hashCode().ushr(1)) % 3) { 0 -> "luck"; 1 -> "brainrot"; else -> "rare" }
                    val boostName = when (boostId) { "luck" -> "Luck Boost"; "brainrot" -> "Brainrot Boost"; else -> "Rare Boost" }
                    val boostDesc = when (boostId) { "luck" -> "+lepší rarity na 3 skeny"; "brainrot" -> "+šance na Brainrot na 3 skeny"; else -> "+šance na vzácnost na 3 skeny" }
                    addBoost(boostId, boostName, 3, boostDesc)
                }
            }
            if (activeBoostScans() > 0) consumeActiveBoost()
            val duelRoll = MessageDigest.getInstance("SHA-256").digest(("duel:"+ean).toByteArray())[0].toInt() and 255
            if (duelRoll < 31 && isBrainrot(card)) {
                val enemies = cards.filter { isBrainrot(it) && it.id != card.id && it.scannable }
                if (enemies.isNotEmpty()) card.let { showDuelDialog(it, enemies[(duelRoll and 255) % enemies.size], false) }
            }
        }
        cacheCardArtwork(card)

        updateMainCard(card)
        updateCollectionButton()
        showUnifiedScanDialog(card, alreadyThisBarcode)
        if (homeUniverseLayer.visibility == View.VISIBLE) buildHomeUniverses()
    }

    private fun showUnifiedScanDialog(card: Card, duplicateBarcode: Boolean) {
        val dialog = Dialog(this)
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(18,20,27), Color.rgb(7,8,12))).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.rgb(65,70,82))
            }
        }
        panel.addView(TextView(this).apply {
            text = if (duplicateBarcode) "UŽ MÁŠ TUTO KARTU" else "NOVÁ KARTA!"
            textSize = 24f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val cardFrame = FrameLayout(this).apply {
            background = rarityStrokeDrawable(card.rarity, 16, 4)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            clipToOutline = true
            if (duplicateBarcode) alpha = 0.32f
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(12,12,16))
            contentDescription = card.name
        }
        cardFrame.addView(image, FrameLayout.LayoutParams(-1, -1))
        val cached = cachedArtworkFile(card)
        if (cached != null) loadCardArtwork(image, cached) else if (card.imageLarge.isNotBlank()) loadCardArtwork(image, card.imageLarge)
        val top = TextView(this).apply {
            text = "#${card.number}"
            textSize = 16f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setShadowLayer(5f, 1f, 1f, Color.BLACK)
            setPadding(dp(10), dp(8), 0, 0)
        }
        cardFrame.addView(top, FrameLayout.LayoutParams(dp(90), dp(42), Gravity.TOP or Gravity.START))
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(9))
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.argb(225,0,0,0), Color.TRANSPARENT))
        }
        bottom.addView(TextView(this).apply {
            text = card.name
            textSize = 17f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(-1, -2))
        bottom.addView(TextView(this).apply {
            text = "${rarityDisplayName(card.rarity)}  •  ${rarityDropPercent(card.rarity, isBrainrot(card))}"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, -2))
        cardFrame.addView(bottom, FrameLayout.LayoutParams(-1, dp(64), Gravity.BOTTOM))
        panel.addView(cardFrame, LinearLayout.LayoutParams(dp(250), dp(355)).apply { gravity = Gravity.CENTER; bottomMargin = dp(12) })
        panel.addView(TextView(this).apply {
            text = card.name
            textSize = 21f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        panel.addView(TextView(this).apply {
            text = if (isBrainrot(card)) { val s=brainrotStats(card); "${card.type}  •  #${card.number}  •  ${rarityDisplayName(card.rarity)}  •  ${rarityDropPercent(card.rarity, true)}  •  HP ${s.hp}  ATK ${s.atk}  DEF ${s.def}  SPD ${s.spd}" } else "${card.type}  •  #${card.number}  •  ${rarityDisplayName(card.rarity)}  •  ${rarityDropPercent(card.rarity, false)}"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(10))
        }, LinearLayout.LayoutParams(-1, -2))
        panel.addView(roundedButton("POKRAČOVAT") { dialog.dismiss() }, LinearLayout.LayoutParams(-1, -2))
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        dialog.setContentView(root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.attributes = dialog.window?.attributes?.apply { dimAmount = 0.82f }
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun showBrainrotScanDialog(card: Card, duplicateBarcode: Boolean) {
        val dialog = Dialog(this)
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(18,20,27), Color.rgb(7,8,12))).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), Color.rgb(65,70,82))
            }
        }
        panel.addView(TextView(this).apply {
            text = if (duplicateBarcode) "UŽ MÁŠ TUTO KARTU" else "NOVÁ KARTA!"
            textSize = 24f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        val cardView = brainrotCardView(card, dp(250), dp(355), false)
        if (duplicateBarcode) {
            cardView.alpha = 0.32f
        }
        panel.addView(cardView, LinearLayout.LayoutParams(dp(250), dp(355)).apply { gravity = Gravity.CENTER; bottomMargin = dp(12) })
        panel.addView(TextView(this).apply {
            text = card.name; textSize = 21f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))
        panel.addView(TextView(this).apply {
            text = "YumCut Brainrot  •  #${card.number}  •  Rarita ${card.rarityNumber}/8"
            textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(10))
        }, LinearLayout.LayoutParams(-1, -2))
        val close = roundedButton("POKRAČOVAT") { dialog.dismiss() }
        panel.addView(close, LinearLayout.LayoutParams(-1, -2))
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        dialog.setContentView(root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.attributes = dialog.window?.attributes?.apply { dimAmount = 0.82f }
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun artworkCacheDir(): File = File(filesDir, "artwork_cache").apply { mkdirs() }

    private fun artworkCacheFile(card: Card): File {
        val hash = MessageDigest.getInstance("SHA-256")
            .digest(card.id.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return File(artworkCacheDir(), "$hash.img")
    }

    private fun cachedArtworkFile(card: Card): File? {
        val file = artworkCacheFile(card)
        return if (file.isFile && file.length() > 1024L) file else null
    }

    private fun loadCardArtwork(imageView: ImageView, source: String) {
        if (source.startsWith("file:///android_asset/")) {
            val path = source.removePrefix("file:///android_asset/")
            try {
                assets.open(path).use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream)
                    if (bitmap != null) {
                        imageView.setImageBitmap(bitmap)
                        return
                    }
                }
            } catch (_: Exception) { }
        }
        Glide.with(this).load(source).placeholder(android.R.color.darker_gray).into(imageView)
    }

    private fun loadCardArtwork(imageView: ImageView, file: File) {
        Glide.with(this).load(file).placeholder(android.R.color.darker_gray).into(imageView)
    }

    private fun cacheCardArtwork(card: Card) {
        val source = card.imageLarge
        if (!source.startsWith("http://") && !source.startsWith("https://")) return
        val target = artworkCacheFile(card)
        if (target.isFile && target.length() > 1024L) return

        artworkExecutor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(source).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 12000
                    instanceFollowRedirects = true
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "SKAN/1.0")
                }
                if (connection.responseCode in 200..299) {
                    val tmp = File(target.parentFile, target.name + ".tmp")
                    connection.inputStream.use { input ->
                        FileOutputStream(tmp).use { output -> input.copyTo(output) }
                    }
                    if (tmp.length() > 1024L) {
                        if (target.exists()) target.delete()
                        tmp.renameTo(target)
                    } else tmp.delete()
                }
            } catch (_: Exception) {
                File(target.parentFile, target.name + ".tmp").delete()
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun updateMainCard(card: Card) {
        if (card.imageLarge.isBlank()) {
            Glide.with(this).clear(cardImage)
            cardImage.setImageDrawable(null)
            cardImage.contentDescription = "Skutečná karta: ${card.name}"
        } else {
            val cached = cachedArtworkFile(card)
            if (cached != null) loadCardArtwork(cardImage, cached) else loadCardArtwork(cardImage, card.imageLarge)
        }
        cardName.text = card.name
        cardInfo.text = card.type
        cardSet.text = "${card.setName} · ${card.number}/${cards.count { it.setId == card.setId }}"
    }

    private fun showMainScanResult(card: Card, duplicateBarcode: Boolean) {
        // Sken je globální a není vázaný na zvolené univerzum. Po výsledku
        // dočasně schováme navigaci univerzů, aby byla karta dominantní.
        homeUniverseLayer.visibility = View.GONE
        // Výsledek skenu není dialog: karta se zobrazí přímo na hlavní obrazovce.
        cardImage.visibility = View.VISIBLE
        cardImage.translationX = 0f
        cardImage.alpha = if (duplicateBarcode) 0.32f else 1f
        cardName.alpha = 1f
        cardInfo.alpha = 1f
        cardSet.alpha = 1f
        cardInfo.text = if (duplicateBarcode) "JIŽ NASKENOVÁNO" else card.type
        cardName.text = card.name
        cardSet.text = "${card.setName} · ${card.number}/${cards.count { it.setId == card.setId }}"

        // Kliknutí na kartu ji odsunuje mimo obrazovku a připraví černou plochu pro další sken.
        cardImage.setOnClickListener { view ->
            val direction = if (view.x + view.width / 2f < resources.displayMetrics.widthPixels / 2f) {
                -resources.displayMetrics.widthPixels.toFloat()
            } else {
                resources.displayMetrics.widthPixels.toFloat()
            }
            animateMainCardOut(direction)
        }
        cardImage.setOnTouchListener { view, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val direction = if (event.x < view.width / 2f) -resources.displayMetrics.widthPixels.toFloat() else resources.displayMetrics.widthPixels.toFloat()
                animateMainCardOut(direction)
                true
            } else true
        }
    }

    private fun animateMainCardOut(direction: Float) {
        if (cardImage.visibility != View.VISIBLE) return
        cardImage.isClickable = false
        val move = ObjectAnimator.ofFloat(cardImage, View.TRANSLATION_X, 0f, direction)
        val fade = ObjectAnimator.ofFloat(cardImage, View.ALPHA, cardImage.alpha, 0f)
        AnimatorSet().apply {
            playTogether(move, fade)
            duration = 300
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    cardImage.visibility = View.INVISIBLE
                    cardImage.translationX = 0f
                    cardImage.alpha = 1f
                    cardImage.isClickable = true
                    cardName.text = ""
                    cardInfo.text = ""
                    cardSet.text = ""
                    cardName.alpha = 1f
                    cardInfo.alpha = 1f
                    cardSet.alpha = 1f
                    homeUniverseLayer.visibility = View.VISIBLE
                    buildHomeUniverses()
                }
            })
            start()
        }
    }

    private fun deterministicCardForEan(ean: String, selectedStyle: String?): Card {
        val digest = MessageDigest.getInstance("SHA-256").digest(ean.toByteArray(Charsets.UTF_8))

        // Globální loot: EAN -> univerzum -> set -> rarita -> karta.
        // Při prvním skenu může zvolený SKAN! jemně posunout šanci ve prospěch svého univerza.
        // Po uložení EANu se karta už nikdy nepřeroluje.
        fun byte(index: Int): Int = digest[index].toInt() and 0xFF

        val universes = listOf(
            "pokemon" to cards.filter { it.setId.startsWith("base1") },
            "starwars" to cards.filter { it.setId.startsWith("sw_") && it.scannable },
            "brainrot" to cards.filter { it.setId.startsWith("brainrot_") && it.scannable }
        ).filter { it.second.isNotEmpty() }

        if (universes.isEmpty()) return cards.first()

        val universeBucket = ((byte(0) shl 8) or byte(1)) % 100
        // Globální rozdělení mezi aktuálními dvěma aktivními univerzy:
        // bez zaměření 50/50, tlačítko SKAN! přidá vybranému tématu +10 procentních bodů.
        // Tím vzniká 60/40 nebo 40/60. Další univerzum později dostane vlastní podíl.
        val focus = selectedStyle?.takeIf { it == "pokemon" || it == "brainrot" }
        val activeBoost = activeBoostId()
        val pokemonPercent = when {
            activeBoost == "brainrot" -> 40
            else -> when (focus) {
            "pokemon" -> 60
            "brainrot" -> 40
            else -> 50
            }
        }
        val universe = if (universeBucket < pokemonPercent) {
            universes.firstOrNull { it.first == "pokemon" }
        } else {
            universes.firstOrNull { it.first == "brainrot" }
        } ?: universes.first()

        val universeCards = universe.second
        val setIds = universeCards.map { it.setId }.distinct()
        val setId = setIds[byte(2) % setIds.size]
        val setCards = universeCards.filter { it.setId == setId }

        val rarityBucket = ((byte(3) shl 8) or byte(4)) % 10_000
        val brainrotLoot = universe.first == "brainrot"
        val active = activeBoostId()
        val boostShift = if (active == "luck" || active == "rare") 700 else 0
        val adjustedBucket = (rarityBucket - boostShift).coerceAtLeast(0)
        val rarity = if (brainrotLoot) {
            when {
                adjustedBucket < 6_000 -> "Common"
                adjustedBucket < 8_000 -> "Uncommon"
                adjustedBucket < 9_200 -> "Rare"
                adjustedBucket < 9_800 -> "Epic"
                else -> "Legendary"
            }
        } else {
            when {
                adjustedBucket < 7_500 -> "Common"
                adjustedBucket < 9_200 -> "Uncommon"
                adjustedBucket < 9_800 -> "Rare"
                else -> "Rare Holo"
            }
        }
        val rarityPool = setCards.filter { it.rarity.equals(rarity, true) }
        val pool = if (rarityPool.isNotEmpty()) rarityPool else setCards
        if (pool.isEmpty()) return cards.first()

        fun cardWeight(card: Card): Int {
            val cardHash = MessageDigest.getInstance("SHA-256").digest(card.id.toByteArray(Charsets.UTF_8))
            val bucket = cardHash[0].toInt() and 0xFF
            return when { 51 > bucket -> 8; 128 > bucket -> 3; else -> 1 }
        }

        var totalWeight = 0L
        pool.forEach { totalWeight += cardWeight(it) }
        var indexSeed = 0L
        for (i in 5..31) indexSeed = (indexSeed shl 5) xor (digest[i % digest.size].toLong() and 31L)
        val target = Math.floorMod(indexSeed, totalWeight)
        var cumulative = 0L
        for (card in pool) {
            cumulative += cardWeight(card)
            if (target < cumulative) return card
        }
        return pool.last()
    }

    private fun scanMap(): MutableMap<String, String> {
        val raw = prefs.getString("scanMap", "{}") ?: "{}"
        val obj = JSONObject(raw)
        return obj.keys().asSequence().associateWith { obj.optString(it) }.toMutableMap()
    }

    private fun saveScan(ean: String, card: Card) {
        val map = scanMap()
        map[ean] = card.id
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k, v) }
        prefs.edit()
            .putString("scanMap", obj.toString())
            .putBoolean(card.id, true)
            .putLong(foundAtKey(card.id), System.currentTimeMillis())
            .apply()
    }

    private fun hasScannedBarcode(ean: String): Boolean = scanMap().containsKey(ean)

    private fun copyCount(card: Card): Int {
        val mapped = scanMap().values.count { it == card.id }
        return if (mapped > 0) mapped else if (prefs.getBoolean(card.id, false)) 1 else 0
    }

    private fun uniqueOwned(card: Card) = copyCount(card) > 0
    private fun foundAtKey(id: String) = "foundAt_$id"
    private fun favoriteKey(id: String) = "favorite_$id"
    private fun isOwned(card: Card) = uniqueOwned(card)
    private fun isFavorite(card: Card) = prefs.getBoolean(favoriteKey(card.id), false)

    private fun updateCollectionButton() {
        collectionButton.contentDescription = "Kolekce ${cards.count { isOwned(it) }}/${cards.size}"
    }

    private fun showCollectionUniversePicker() {
        val dialog = Dialog(this)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        val scroll = ScrollView(this).apply { setPadding(dp(14), dp(28), dp(14), dp(28)) }
        val grid = GridLayout(this).apply { columnCount = 2; useDefaultMargins = false }
        universeCatalog().forEach { universe ->
            val tile = createUniverseTile(universe)
            tile.setOnClickListener {
                dialog.dismiss()
                showCollectionDialog(universe)
            }
            grid.addView(tile, GridLayout.LayoutParams().apply {
                width = 0; height = dp(132)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(6), dp(6), dp(6), dp(6))
            })
        }
        scroll.addView(grid, FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        dialog.setContentView(root)
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.attributes = dialog.window?.attributes?.apply { dimAmount = 0.78f }
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun showCollectionDialog(universe: Universe) {
        // Kolekce je samostatná plocha bez vnitřního „okna“.
        // Okolí zůstává ztlumené a na první úrovni jsou pouze dlaždice setů.
        val dialog = Dialog(this)
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setPadding(dp(18), dp(34), dp(18), dp(24))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        // Každé univerzum má vlastní kolekci. EAN loot se nikdy nepřerolovává;
        // pouze zde zobrazujeme obsah daného univerza.
        val universeCards = when (universe.id.lowercase()) {
            "pokemon" -> cards.filter { it.setId.startsWith("base1") }
            "starwars" -> cards.filter { it.setId.startsWith("sw_") }
            "brainrot" -> cards.filter { it.setId.startsWith("brainrot_") }
            else -> emptyList()
        }

        val generations = universeCards.map { it.generation }.distinct().sorted()
        val sets = universeCards.map { it.setId }.distinct()
        val collapsedGenerations = mutableSetOf<Int>()
        var currentSetId: String? = null

        lateinit var render: () -> Unit

        // Kliknutí do prázdného prostoru funguje jako „Zpět“. Když jsme uvnitř
        // konkrétního setu, vrátíme se na seznam setů; jinak se zavře tato plocha
        // a pod ní zůstane otevřené menu daného univerza.
        installBlankSpaceBack(scroll) {
            if (currentSetId != null) render() else dialog.dismiss()
        }

        fun renderSetCards(setId: String) {
            currentSetId = setId
            content.removeAllViews()
            val set = universeCards.firstOrNull { it.setId == setId } ?: return
            val setCards = universeCards.filter { it.setId == setId }

            var selectedMode = "Vše"
            var selectedElement = "Všechny elementy"
            var selectedSort = "Datum nalezení"

            val page = FrameLayout(this)
            content.addView(page, LinearLayout.LayoutParams(-1, -1))

            val cardsScroll = ScrollView(this).apply {
                isFillViewport = true
                setPadding(dp(6), dp(58), dp(6), dp(18))
            }
            val cardsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            cardsScroll.addView(cardsContainer, FrameLayout.LayoutParams(-1, -1))
            page.addView(cardsScroll, FrameLayout.LayoutParams(-1, -1))

            val controls = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(4), dp(8), dp(4))
            }

            fun smallRoundButton(symbol: String, description: String, action: () -> Unit): Button = Button(this).apply {
                text = symbol
                textSize = 19f
                setTextColor(Color.WHITE)
                contentDescription = description
                gravity = Gravity.CENTER
                setPadding(0, 0, 0, 0)
                background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_dialog)
                setOnClickListener { action() }
            }

            fun refreshCards() {
                cardsContainer.removeAllViews()
                renderCards(
                    cardsContainer,
                    applyFilterAndSort(setCards, selectedMode, selectedElement, selectedSort),
                    selectedMode
                )
            }

            val backButton = smallRoundButton("‹", if (universe.id.equals("brainrot", true)) "Zpět na Brainrot" else "Zpět na sety") {
                if (universe.id.equals("brainrot", true)) dialog.dismiss() else render()
            }
            controls.addView(backButton, LinearLayout.LayoutParams(dp(44), dp(44)))

            val spacer = Space(this)
            controls.addView(spacer, LinearLayout.LayoutParams(0, dp(44), 1f))

            lateinit var filterButton: Button
            filterButton = smallRoundButton("☷", "Filtry") {
                val brainrot = universe.id.equals("brainrot", true)
                val options = if (brainrot) {
                    listOf("Vše", "Nalezené", "Rarita", "Herní hodnota", "Oblíbené")
                } else {
                    listOf("Vše", "Nalezené", "Oblíbené", "Pokémon", "Energie", "Item", "Trainer")
                }
                val popup = PopupWindow(this).apply {
                    isFocusable = true
                    elevation = dp(8).toFloat()
                    setBackgroundDrawable(ColorDrawable(Color.rgb(35, 35, 35)))
                }
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                options.forEach { option ->
                    box.addView(Button(this).apply {
                        text = option
                        textSize = 14f
                        setTextColor(Color.WHITE)
                        background = ColorDrawable(Color.TRANSPARENT)
                        gravity = Gravity.START or Gravity.CENTER_VERTICAL
                        setOnClickListener {
                            if (brainrot && option == "Rarita") {
                                popup.dismiss()
                                showBrainrotSubmenu(filterButton, "Rarita", listOf("Vše", "Common", "Uncommon", "Rare", "Epic", "Legendary")) { value ->
                                    selectedMode = if (value == "Vše") "Vše" else "Rarita:$value"
                                    refreshCards()
                                }
                            } else if (brainrot && option == "Herní hodnota") {
                                popup.dismiss()
                                showBrainrotSubmenu(filterButton, "Herní hodnota", listOf("Vše", "1", "2", "3", "4", "5", "6", "7", "8")) { value ->
                                    selectedMode = if (value == "Vše") "Vše" else "Hodnota:$value"
                                    refreshCards()
                                }
                            } else {
                                selectedMode = option
                                popup.dismiss()
                                refreshCards()
                            }
                        }
                    }, LinearLayout.LayoutParams(dp(190), dp(42)))
                }
                val elements = availableElements(setCards)
                if (elements.isNotEmpty()) {
                    box.addView(View(this).apply { setBackgroundColor(Color.DKGRAY) }, LinearLayout.LayoutParams(-1, dp(1)))
                    box.addView(Button(this).apply {
                        text = if (selectedElement == "Všechny elementy") "Elementy" else "Element: $selectedElement"
                        textSize = 14f
                        setTextColor(Color.WHITE)
                        background = ColorDrawable(Color.TRANSPARENT)
                        gravity = Gravity.START or Gravity.CENTER_VERTICAL
                        setOnClickListener {
                            popup.dismiss()
                            val ep = PopupWindow(this@MainActivity).apply {
                                isFocusable = true
                                elevation = dp(8).toFloat()
                                setBackgroundDrawable(ColorDrawable(Color.rgb(35, 35, 35)))
                            }
                            val eb = LinearLayout(this@MainActivity).apply {
                                orientation = LinearLayout.VERTICAL
                                setPadding(dp(8), dp(8), dp(8), dp(8))
                            }
                            (listOf("Všechny elementy") + elements).forEach { element ->
                                eb.addView(Button(this@MainActivity).apply {
                                    text = element
                                    textSize = 14f
                                    setTextColor(Color.WHITE)
                                    background = ColorDrawable(Color.TRANSPARENT)
                                    gravity = Gravity.START or Gravity.CENTER_VERTICAL
                                    setOnClickListener {
                                        selectedElement = element
                                        ep.dismiss()
                                        refreshCards()
                                    }
                                }, LinearLayout.LayoutParams(dp(190), dp(42)))
                            }
                            ep.contentView = eb
                            ep.width = dp(210)
                            ep.height = WindowManager.LayoutParams.WRAP_CONTENT
                            ep.showAsDropDown(filterButton, -dp(165), -dp(48))
                        }
                    }, LinearLayout.LayoutParams(dp(190), dp(42)))
                }
                popup.contentView = box
                popup.width = dp(210)
                popup.height = WindowManager.LayoutParams.WRAP_CONTENT
                popup.showAsDropDown(filterButton, -dp(165), -dp(48))
            }

            lateinit var sortButton: Button
            sortButton = smallRoundButton("↕", "Řazení") {
                val options = if (universe.id.equals("brainrot", true)) {
                    arrayOf("Datum nalezení", "Rarita", "Herní hodnota", "Abecedně", "Oblíbené")
                } else {
                    arrayOf("Datum nalezení", "Rarita", "Element", "Stadium vývoje", "Abecedně", "Pořadí na kartě")
                }
                val popup = PopupWindow(this).apply {
                    isFocusable = true
                    elevation = dp(8).toFloat()
                    setBackgroundDrawable(ColorDrawable(Color.rgb(35, 35, 35)))
                }
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                options.forEach { option ->
                    box.addView(Button(this).apply {
                        text = option
                        textSize = 14f
                        setTextColor(Color.WHITE)
                        background = ColorDrawable(Color.TRANSPARENT)
                        gravity = Gravity.START or Gravity.CENTER_VERTICAL
                        setOnClickListener {
                            selectedSort = option
                            popup.dismiss()
                            refreshCards()
                        }
                    }, LinearLayout.LayoutParams(dp(190), dp(42)))
                }
                popup.contentView = box
                popup.width = dp(210)
                popup.height = WindowManager.LayoutParams.WRAP_CONTENT
                popup.showAsDropDown(sortButton, -dp(165), -dp(48))
            }

            controls.addView(filterButton, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(6) })
            controls.addView(sortButton, LinearLayout.LayoutParams(dp(44), dp(44)))
            page.addView(controls, FrameLayout.LayoutParams(-1, dp(54), Gravity.TOP))

            refreshCards()
        }

        fun renderSetTiles(container: LinearLayout, setCards: List<Card>) {
            val grid = GridLayout(this).apply {
                columnCount = 2
                alignmentMode = GridLayout.ALIGN_BOUNDS
                useDefaultMargins = false
                setPadding(dp(4), dp(4), dp(4), dp(10))
            }
            setCards.distinctBy { it.setId }.sortedBy { it.setName }.forEach { set ->
                val tile = setTile(set)
                tile.setOnClickListener { renderSetCards(set.setId) }
                grid.addView(tile, GridLayout.LayoutParams().apply {
                    width = 0
                    height = dp(122)
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(dp(5), dp(5), dp(5), dp(5))
                })
            }
            container.addView(grid)
        }

        render = {
            currentSetId = null
            content.removeAllViews()
            if (universeCards.isEmpty()) {
                content.addView(TextView(this).apply {
                    text = "Kolekce ${universe.title} je zatím prázdná."
                    textSize = 20f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    setPadding(dp(24), dp(120), dp(24), dp(24))
                }, LinearLayout.LayoutParams(-1, -2))
            } else if (universe.id.equals("brainrot", true)) {
                // Brainrot má jen jednu společnou kolekci: po otevření KOLEKCE
                // jdeme rovnou na karty, bez mezikroku se setem.
                renderSetCards(sets.first())
            } else if (sets.size == 1) {
                renderSetTiles(content, universeCards)
            } else {
                generations.forEach { gen ->
                    val genSets = universeCards.filter { it.generation == gen }.distinctBy { it.setId }.sortedBy { it.setName }
                    val genHeader = sectionButton("Gen $gen  ${ownedCountGeneration(gen)}/${totalGeneration(gen)}", true)
                    content.addView(genHeader)
                    val genBody = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        visibility = if (collapsedGenerations.contains(gen)) View.GONE else View.VISIBLE
                    }
                    genHeader.setOnClickListener {
                        if (!collapsedGenerations.add(gen)) collapsedGenerations.remove(gen)
                        render()
                    }
                    content.addView(genBody)
                    if (genBody.visibility == View.VISIBLE) renderSetTiles(genBody, genSets)
                }
            }
        }

        dialog.setContentView(root)
        dialog.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK && event.action == android.view.KeyEvent.ACTION_UP) {
                if (currentSetId != null) {
                    if (universe.id.equals("brainrot", true)) dialog.dismiss() else render()
                    true
                } else {
                    dialog.dismiss()
                    true
                }
            } else false
        }
        dialog.setCanceledOnTouchOutside(true)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.attributes = dialog.window?.attributes?.apply { dimAmount = 0.72f }
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        render()
    }

    private fun setTile(set: Card): LinearLayout {
        val tile = FrameLayout(this).apply {
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_dialog)
            clipToOutline = true
            elevation = dp(3).toFloat()
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(35, 35, 35))
            when {
                set.setId.equals("base1", true) || set.setName.equals("Base Set", true) -> setImageResource(R.drawable.base_set_tile)
                set.setId.startsWith("sw_") -> setImageResource(R.drawable.universe_starwars_tile)
                set.setId.startsWith("brainrot_") -> setImageResource(R.drawable.universe_brainrot_tile)
            }
        }
        tile.addView(image, FrameLayout.LayoutParams(-1, -1))

        val shade = View(this).apply { setBackgroundColor(Color.argb(80, 0, 0, 0)) }
        tile.addView(shade, FrameLayout.LayoutParams(-1, -1))

        val title = TextView(this).apply {
            text = set.setName
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setShadowLayer(5f, 1f, 1f, Color.BLACK)
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(10), dp(8), dp(8), dp(4))
        }
        tile.addView(title, FrameLayout.LayoutParams(-1, -2, Gravity.TOP or Gravity.START))

        val count = TextView(this).apply {
            text = "${ownedCount(set.setId)}/${setTotal(set.setId)}"
            textSize = 15f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setShadowLayer(4f, 1f, 1f, Color.BLACK)
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(8), dp(4), dp(10), dp(8))
        }
        tile.addView(count, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM or Gravity.END))
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tile, LinearLayout.LayoutParams(-1, -1))
        }
    }

    private fun showBrainrotSubmenu(anchor: View, title: String, options: List<String>, onSelect: (String) -> Unit) {
        val popup = PopupWindow(this).apply {
            isFocusable = true
            elevation = dp(8).toFloat()
            setBackgroundDrawable(ColorDrawable(Color.rgb(35, 35, 35)))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(8), dp(4), dp(8), dp(8))
        })
        options.forEach { option ->
            box.addView(Button(this).apply {
                text = if (title == "Rarita") rarityDisplayName(option) else option
                textSize = 14f
                setTextColor(Color.WHITE)
                background = ColorDrawable(Color.TRANSPARENT)
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener { popup.dismiss(); onSelect(option) }
            }, LinearLayout.LayoutParams(dp(190), dp(42)))
        }
        popup.contentView = box
        popup.width = dp(210)
        popup.height = WindowManager.LayoutParams.WRAP_CONTENT
        popup.showAsDropDown(anchor, -dp(165), -dp(48))
    }

    private fun availableElements(source: List<Card>): List<String> = source.flatMap { it.element.split(",", "/", "|") }.map { it.trim() }.filter { it.isNotEmpty() }.distinct().sorted()

    private fun applyFilterAndSort(source: List<Card>, mode: String, element: String, sort: String): List<Card> {
        var list = when {
            mode == "Nalezené" -> source.filter { isOwned(it) }
            mode == "Oblíbené" -> source.filter { isFavorite(it) }
            mode.startsWith("Rarita:") -> source.filter { it.rarity.equals(mode.substringAfter(":"), true) }
            mode.startsWith("Hodnota:") -> source.filter { it.rarityNumber == mode.substringAfter(":").toIntOrNull() }
            mode == "Pokémon" -> source.filter { it.category.equals("Pokémon", true) }
            mode == "Energie" -> source.filter { it.category.equals("Energy", true) || it.category.equals("Energie", true) }
            mode == "Item" -> source.filter { it.category.equals("Trainer", true) && it.trainerSubtype.equals("Item", true) }
            mode == "Trainer" -> source.filter { it.category.equals("Trainer", true) && !it.trainerSubtype.equals("Item", true) }
            else -> source
        }
        if (element != "Všechny elementy") {
            list = list.filter { it.element.split(",", "/", "|").map { e -> e.trim() }.any { it.equals(element, true) } }
        }

        val sorted = when (sort) {
            "Datum nalezení" -> list.sortedWith(compareByDescending<Card> { prefs.getLong(foundAtKey(it.id), 0L) }.thenBy { it.number })
            "Rarita" -> list.sortedWith(compareBy<Card> { raritySortRank(it.rarity) }.thenBy { it.name.lowercase() }.thenBy { it.number })
            "Herní hodnota" -> list.sortedWith(compareBy<Card> { it.rarityNumber }.thenBy { it.name.lowercase() }.thenBy { it.number })
            "Oblíbené" -> list.sortedWith(compareByDescending<Card> { isFavorite(it) }.thenBy { it.number })
            "Element" -> list.sortedWith(compareBy<Card> { it.element.ifBlank { "~" } }.thenBy { it.evolutionFamily.ifBlank { it.name } }.thenBy { it.evolutionOrder }.thenBy { it.number })
            "Stadium vývoje" -> list.sortedWith(compareBy<Card> { it.evolutionFamily.ifBlank { "~" } }.thenBy { it.evolutionOrder }.thenBy { it.number })
            "Abecedně", "Abecedy" -> list.sortedWith(compareBy<Card> { it.name.lowercase() }.thenBy { it.number })
            else -> list.sortedBy { it.number }
        }

        // Globální pravidlo kolekcí: nalezené vždy první, ale uvnitř skupiny
        // se přesně zachová právě zvolené řazení.
        return sorted.sortedWith(compareByDescending<Card> { isOwned(it) })
    }

    private fun raritySortRank(rarity: String): Int = when (rarity.lowercase()) {
        "common" -> 1
        "uncommon" -> 2
        "rare", "rare holo" -> 3
        "epic" -> 4
        "legendary" -> 5
        else -> 99
    }

    private fun renderCards(content: LinearLayout, setCards: List<Card>, mode: String) {
        if (setCards.isEmpty()) {
            content.addView(TextView(this).apply { text = "Žádné karty neodpovídají filtru."; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(dp(8), dp(18), dp(8), dp(18)) })
            return
        }
        val grid = GridLayout(this).apply { columnCount = 3; useDefaultMargins = true; setPadding(dp(4), dp(4), dp(4), dp(8)) }
        setCards.forEach { card ->
            val copies = copyCount(card)
            val repeat = if (mode == "Nalezené" && copies > 1) copies else 1
            repeat(repeat) {
                val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(3), dp(3), dp(8)) }
                if (isOwned(card)) {
                    if (isBrainrot(card)) {
                        val cardView = brainrotCardView(card, dp(100), dp(142), interactive = true, allowRemote = false, navigationCards = setCards)
                        tile.addView(cardView)
                    } else {
                        val cardFrame = FrameLayout(this).apply {
                            background = rarityStrokeDrawable(card.rarity, 10, 3)
                            setPadding(dp(3), dp(3), dp(3), dp(3))
                            setOnClickListener { showCardViewer(card, setCards) }
                        }
                        val image = ImageView(this).apply {
                            layoutParams = FrameLayout.LayoutParams(dp(90), dp(128), Gravity.CENTER)
                            scaleType = ImageView.ScaleType.FIT_CENTER
                            contentDescription = card.name
                        }
                        val cached = cachedArtworkFile(card)
                        if (cached != null) loadCardArtwork(image, cached) else loadCardArtwork(image, card.imageSmall)
                        cardFrame.addView(image)
                        tile.addView(cardFrame, LinearLayout.LayoutParams(dp(96), dp(134)))
                        val label = if (copies > 1) "#${card.number}  ×$copies${if (isFavorite(card)) "  ♥" else ""}" else "#${card.number}${if (isFavorite(card)) "  ♥" else ""}"
                        tile.addView(TextView(this).apply { text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE) })
                        tile.addView(TextView(this).apply {
                            text = "${rarityDisplayName(card.rarity)}  •  ${rarityDropPercent(card.rarity, isBrainrot(card))}"
                            textSize = 8.5f
                            gravity = Gravity.CENTER
                            setTextColor(Color.LTGRAY)
                            setTypeface(typeface, android.graphics.Typeface.BOLD)
                        })
                    }
                } else {
                    val locked = FrameLayout(this)
                    locked.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(22,22,28), Color.rgb(8,8,12))).apply {
                        cornerRadius = dp(14).toFloat()
                        setStroke(dp(3), rarityFrameColor(card.rarity))
                    }
                    val number = TextView(this).apply {
                        text = "#${card.number}"
                        textSize = 12f
                        setTextColor(Color.WHITE)
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        setShadowLayer(4f, 1f, 1f, Color.BLACK)
                        setPadding(dp(7), dp(5), 0, 0)
                    }
                    locked.addView(number, FrameLayout.LayoutParams(dp(50), dp(30), Gravity.TOP or Gravity.START))
                    addLockedCardOverlay(locked, dp(100))
                    val rarityInfo = TextView(this).apply {
                        text = "${rarityDisplayName(card.rarity)}  •  ${rarityDropPercent(card.rarity, isBrainrot(card))}"
                        textSize = 8.5f
                        setTextColor(Color.LTGRAY)
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        gravity = Gravity.CENTER
                        setShadowLayer(3f, 1f, 1f, Color.BLACK)
                    }
                    locked.addView(rarityInfo, FrameLayout.LayoutParams(-1, dp(22), Gravity.BOTTOM).apply {
                        bottomMargin = dp(3)
                    })
                    locked.layoutParams = LinearLayout.LayoutParams(dp(100), dp(142))
                    locked.isClickable = true
                    locked.setOnClickListener { showCardViewer(card, setCards) }
                    tile.addView(locked)
                }
                tile.setOnClickListener {
                    showCardViewer(card, setCards)
                }
                grid.addView(tile, GridLayout.LayoutParams().apply { width = 0; height = GridLayout.LayoutParams.WRAP_CONTENT; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) })
            }
        }
        content.addView(grid)
    }

    private fun showLockedCardViewer(card: Card) {
        showCardViewer(card, cards.filter { it.setId == card.setId })
    }

    private fun showCardViewer(card: Card, navigationCards: List<Card> = cards.filter { it.setId == card.setId }) {
        if (navigationCards.isEmpty()) return
        val viewer = Dialog(this)
        val ordered = navigationCards.distinctBy { it.id }
        var index = ordered.indexOfFirst { it.id == card.id }.coerceAtLeast(0)
        var downX = 0f
        var downY = 0f

        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
        }

        fun render(current: Card) {
            frame.removeAllViews()
            val owned = isOwned(current)
            val width = (resources.displayMetrics.widthPixels * 0.82f).toInt()
            val height = (resources.displayMetrics.heightPixels * 0.72f).toInt()
            val cardFrame = FrameLayout(this).apply {
                background = rarityStrokeDrawable(current.rarity, 18, 4)
                setPadding(dp(4), dp(4), dp(4), dp(4))
                clipToOutline = true
            }

            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Color.rgb(12, 12, 16))
                contentDescription = current.name
            }
            cardFrame.addView(image, FrameLayout.LayoutParams(-1, -1))
            if (current.imageLarge.isNotBlank()) {
                val cached = cachedArtworkFile(current)
                if (cached != null) loadCardArtwork(image, cached) else loadCardArtwork(image, current.imageLarge)
            }

            if (!owned) {
                image.alpha = 0.30f
                cardFrame.addView(View(this).apply { setBackgroundColor(Color.argb(155, 0, 0, 0)) }, FrameLayout.LayoutParams(-1, -1))
                val lockedOverlay = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(18), dp(18), dp(18), dp(18))
                }
                lockedOverlay.addView(TextView(this).apply { text = "🔒"; textSize = 42f; gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2))
                lockedOverlay.addView(TextView(this).apply {
                    text = "NENASKENOVÁNO"
                    textSize = 24f
                    setTextColor(Color.WHITE)
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    gravity = Gravity.CENTER
                    setShadowLayer(7f, 1f, 1f, Color.BLACK)
                }, LinearLayout.LayoutParams(-1, -2))
                cardFrame.addView(lockedOverlay, FrameLayout.LayoutParams(-1, -1))
            }

            val top = TextView(this).apply {
                text = "#${current.number}"
                textSize = 18f
                setTextColor(Color.WHITE)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setShadowLayer(6f, 1f, 1f, Color.BLACK)
                setPadding(dp(14), dp(10), 0, 0)
            }
            cardFrame.addView(top, FrameLayout.LayoutParams(dp(110), dp(48), Gravity.TOP or Gravity.START))

            val gameValue = TextView(this).apply {
                text = current.rarityNumber.toString()
                textSize = 18f
                setTextColor(Color.WHITE)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    cornerRadius = dp(9).toFloat()
                    setColor(rarityFrameColor(current.rarity))
                    setStroke(dp(1), Color.argb(190,255,255,255))
                }
            }
            cardFrame.addView(gameValue, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.TOP or Gravity.END).apply {
                topMargin = dp(8); rightMargin = dp(8)
            })

            val bottom = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(10), dp(14), dp(12))
                background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.argb(235,0,0,0), Color.TRANSPARENT))
            }
            bottom.addView(TextView(this).apply {
                text = current.name
                textSize = 21f
                setTextColor(Color.WHITE)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(-1, -2))
            bottom.addView(TextView(this).apply {
                text = if (isBrainrot(current)) { val s=brainrotStats(current); "${rarityDisplayName(current.rarity)}  •  ${rarityDropPercent(current.rarity, true)}  •  HP ${s.hp}  ATK ${s.atk}  DEF ${s.def}  SPD ${s.spd}" } else "${rarityDisplayName(current.rarity)}  •  ${rarityDropPercent(current.rarity, false)}"
                textSize = 14f
                setTextColor(Color.LTGRAY)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }, LinearLayout.LayoutParams(-1, -2))
            if (isBrainrot(current)) {
                val bs=brainrotStats(current)
                bottom.addView(TextView(this).apply { text="${bs.archetype} • ${bs.ability}"; textSize=12f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(-1,-2))
            }
            cardFrame.addView(bottom, FrameLayout.LayoutParams(-1, dp(82), Gravity.BOTTOM))

            frame.addView(cardFrame, FrameLayout.LayoutParams(width, height, Gravity.CENTER).apply { bottomMargin = dp(46) })

            val position = TextView(this).apply {
                text = "${index + 1} / ${ordered.size}"
                textSize = 13f
                setTextColor(Color.LTGRAY)
                gravity = Gravity.CENTER
            }
            frame.addView(position, FrameLayout.LayoutParams(-1, dp(30), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(94) })

            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            val favoriteButton = iconButton(if (isFavorite(current)) "♥" else "♡", "Oblíbené")
            favoriteButton.setOnClickListener {
                val newValue = !isFavorite(current)
                prefs.edit().putBoolean(favoriteKey(current.id), newValue).apply()
                favoriteButton.text = if (newValue) "♥" else "♡"
                updateCollectionButton()
            }
            val deckButton = iconButton("+", "Do balíčku")
            deckButton.setOnClickListener { showDeckPicker(current) }
            val closeButton = iconButton("×", "Zavřít")
            closeButton.setOnClickListener { viewer.dismiss() }
            actions.addView(favoriteButton, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(6) })
            actions.addView(deckButton, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(6) })
            actions.addView(closeButton, LinearLayout.LayoutParams(dp(56), dp(56)))
            frame.addView(actions, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { rightMargin = dp(18); bottomMargin = dp(18) })
        }

        frame.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; true }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (kotlin.math.abs(dx) > dp(70) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.2f) {
                        if (dx < 0 && index < ordered.lastIndex) { index++; render(ordered[index]) }
                        else if (dx > 0 && index > 0) { index--; render(ordered[index]) }
                    }
                    true
                }
                else -> true
            }
        }

        render(ordered[index])
        viewer.setContentView(frame)
        viewer.setCanceledOnTouchOutside(true)
        viewer.show()
        viewer.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        viewer.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        viewer.window?.attributes = viewer.window?.attributes?.apply { dimAmount = 0.72f }
        viewer.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun showGameMenuDialog() {
        val dialog = Dialog(this)
        val root = darkDialogRoot()
        root.addView(dialogTitle("🎮 HERNÍ MENU"))
        root.addView(sectionButton("🎒  ITEMY\nInventář itemů", false).apply {
            setOnClickListener { dialog.dismiss(); showItemsDialog() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(sectionButton("🍀  BOOSTY\nAktivní boosty", false).apply {
            setOnClickListener { dialog.dismiss(); showBoostsDialog() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(sectionButton("⚔  TRAINING DUEL\nSouboj vlastních Brainrotů", false).apply {
            setOnClickListener { dialog.dismiss(); showTrainingDuelDialog() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(sectionButton("🃏  PEXESO\nHra o odměny", false).apply {
            setOnClickListener { dialog.dismiss(); showMemoryDialog() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        root.addView(roundedButton("ZAVŘÍT") { dialog.dismiss() },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        dialog.setContentView(root)
        dialog.show()
        styleDialogWindow(dialog, 0.86f, 0.68f)
    }

    private fun showSettingsDialog() {
        val dialog = Dialog(this)
        val root = darkDialogRoot()
        root.addView(dialogTitle("NASTAVENÍ"))
        root.addView(sectionButton("ℹ  Verze 0.5.4", true).apply {
            isClickable = false
            alpha = 0.9f
        })
        root.addView(roundedButton("PATCH NOTES") { dialog.dismiss(); showPatchNotesDialog() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(roundedButton("ZAVŘÍT") { dialog.dismiss() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        dialog.setContentView(root)
        dialog.show()
        styleDialogWindow(dialog, 0.88f, 0.48f)
    }

    private fun showPatchNotesDialog() {
        val dialog = Dialog(this)
        val root = darkDialogRoot()
        root.addView(dialogTitle("PATCH NOTES"))
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
        }
        val text = TextView(this).apply {
            text = """
SKAN 0.5.4 — HLAVNÍ OBRAZOVKA A HERNÍ MENU

• Zrušena kolekce VOZIDLA / HOT WHEELS z hlavní nabídky i výběru kolekcí.
• Itemy, Boosty, Training Duel a Pexeso jsou přesunuty z hlavní obrazovky do kompaktního výsuvného herního menu vedle Nastavení.
• Opravena chyba v katalogu univerz, která bránila kompilaci aplikace.
• Hlavní obrazovka zůstává přehledná a nové herní funkce nejsou zobrazené jako velké dlaždice.
• Herní funkce jsou stále dostupné jedním klepnutím z hlavní obrazovky.

SKAN 0.5.0 — BRAINROT HERNA A ODMĚNY

• Brainroty dostaly deterministické statistiky HP, ATK, DEF, SPD, archetyp a speciální schopnost.
• Přidány itemy získávané skenováním a samostatný inventář itemů.
• Přidány SKAN Coins a odměny za skeny, duely a pexeso.
• Přidány Boosty s omezeným počtem skenů: Luck Boost, Brainrot Boost a Rare Boost.
• Přidány náhodné duely při skenování a Training Duel s vlastním Brainrotem.
• Přidáno Pexeso s náhodnými odměnami.
• Přidány hlavní dlaždice Itemy, Boosty, Training Duel a Pexeso.
• Náhledy Brainrotů nyní zobrazují bojové statistiky a schopnost.
• Nenaskenované karty zůstávají skryté v seznamu a v detailu používají ztmavený artwork s NENASKENOVÁNO.
• Pokémon drop rates zůstávají 75 % / 17 % / 6 % / 2 % a Brainrot 60 % / 20 % / 12 % / 6 % / 2 %; generátor používá stejné hodnoty jako UI.
• Boosty mají omezené trvání na počet skenů a aktivní boost je viditelný na hlavní obrazovce.

SKAN 0.4.4 — AKTUÁLNÍ

• Brainrot nalezené karty nyní mají viditelný barevný rámeček podle rarity stejně jako Pokémon.
• Brainrot filtr nově obsahuje Vše, Nalezené, Rarita, Herní hodnota a Oblíbené.
• Ve všech univerzech jsou nalezené karty vždy první; zvolené řazení se stále uplatňuje uvnitř nalezených i nenalezených.
• Brainrot swipe nyní používá přesně aktuálně filtrovaný a seřazený seznam.

SKAN 0.4.3 — AKTUÁLNÍ

• Rarity jsou nyní v celé aplikaci česky: Běžný, Neobyčejný, Vzácný, Epický, Legendární.
• Přidáno zobrazení „Vzácný Holo“ pro Pokémon karty.
• Přidána kompletní historie Patch Notes přímo do aplikace.
• Nejnovější změny jsou nahoře a starší verze lze procházet posunutím nahoru/dolů.

SKAN 0.4.2

• Brainrot karty v kolekci dostaly rámečky podle rarity stejně jako Pokémon.
• Swipe v náhledu postupuje přesně podle aktuálně seřazeného seznamu.
• Přidáno řazení podle rarity pro Pokémon i Brainrot.
• Brainrot filtry: rarita, herní hodnota 1–8 a oblíbené.
• Brainrot řazení: datum nalezení, rarita, herní hodnota, abecedně a oblíbené.
• Herní hodnota 1–8 je viditelná i ve velkém náhledu.

SKAN 0.4.1

• Opraveno sestavení: rarity rámeček používá správnou funkci.
• Brainrot rarity: Běžný 60 %, Neobyčejný 20 %, Vzácný 12 %, Epický 6 %, Legendární 2 %.
• Pokémon rarity: Běžný 75 %, Neobyčejný 17 %, Vzácný 6 %, Vzácný Holo 2 %.
• Globální poměr Pokémon/Brainrot: 50/50; zaměření SKAN! jej mění na 60/40 nebo 40/60.

SKAN 0.4.0

• Sjednocený náhled Pokémon a Brainrot karet.
• Přidán swipe doleva/doprava mezi otevřenými kartami.
• Nenaskenované karty zobrazují ztmavený artwork s označením NENASKENOVÁNO.
• Rámečky rarity: Běžný hnědý, Neobyčejný zelený, Vzácný světle modrý, Epický fialový, Legendární oranžový/žlutý.
• Rarita a drop rate zůstávají viditelné u odemčených karet.

SKAN 0.3.9

• Globální loot Pokémon/Brainrot 50/50.
• Zaměření SKAN! na Pokémon: 60 % Pokémon / 40 % Brainrot.
• Zaměření SKAN! na Brainrot: 40 % Pokémon / 60 % Brainrot.
• Brainrot rarity: Běžný 60 %, Neobyčejný 20 %, Vzácný 12 %, Epický 6 %, Legendární 2 %.
• Pokémon rarity: Běžný 75 %, Neobyčejný 17 %, Vzácný 6 %, Vzácný Holo 2 %.

SKAN 0.3.8

• Brainrot drop rates byly změněny na Běžný 70 %, Neobyčejný 15 %, Vzácný 12 %, Legendární 3 %.
• Starší Epic metadata byla normalizována na Legendary.

SKAN 0.3.7

• Opraveno klikání na nenaskenované karty.
• Nenaskenaná karta otevře velký náhled artworku ztmavený přes overlay NENASKENOVÁNO.
• Odemčené karty zobrazují raritu a drop rate i v kolekci a náhledu.

SKAN 0.3.6

• Přidáno tlačítko Nastavení.
• Přidána obrazovka Patch Notes.
• Nenaskenované karty lze otevřít z kolekce.
• Náhled nenaskenované karty zobrazuje ztmavený artwork.

SKAN 0.3.5

• Duplicitní skenovaný výsledek se zobrazí ztmavený.
• Číslo karty je viditelné v kolekci i u zamčených karet.
• Zamčené karty zobrazují raritu a drop chance.
• Pokémon drop rates: Běžný 75 %, Neobyčejný 17 %, Vzácný 6 %, Vzácný Holo 2 %.
• Zachována deterministická vazba EAN → karta.
• Zachováno ukládání kolekce.
""".trimIndent()
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(dp(6), dp(4), dp(6), dp(16))
        }
        scroll.addView(text)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(roundedButton("ZAVŘÍT") { dialog.dismiss() })
        dialog.setContentView(root)
        dialog.show()
        styleDialogWindow(dialog, 0.90f, 0.78f)
    }

    private fun iconButton(symbol: String, description: String): Button = Button(this).apply {
        text = symbol
        contentDescription = description
        textSize = 27f
        setTextColor(Color.WHITE)
        isAllCaps = false
        gravity = Gravity.CENTER
        includeFontPadding = false
        background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_icon_button)
        minWidth = 0
        minHeight = 0
        setPadding(0, 0, 0, 0)
    }

    private fun showDecksDialog() {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle("MOJE BALÍČKY"))
        root.addView(roundedButton("＋ NOVÝ BALÍČEK") { showNewDeckDialog(dialog) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        renderDeckList(root, dialog)
        root.addView(roundedButton("ZAVŘÍT") { dialog.dismiss() })
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.88f, 0.72f)
    }

    private fun showNewDeckDialog(parent: Dialog) {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle("NOVÝ BALÍČEK"))
        val input = EditText(this).apply { hint = "Název balíčku"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 18f; setSingleLine(true); background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_edit) }
        root.addView(input, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(roundedButton("ZRUŠIT") { dialog.dismiss() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        row.addView(roundedButton("VYTVOŘIT") {
            val name = input.text.toString().trim()
            if (name.isNotBlank()) { saveDeckNames(getDeckNames().toMutableSet().apply { add(name) }); dialog.dismiss(); parent.dismiss(); showDecksDialog() }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
        root.addView(row)
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.82f, 0.34f)
        input.requestFocus(); dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
    }

    private fun renderDeckList(root: LinearLayout, dialog: Dialog) {
        root.findViewWithTag<View>("deckList")?.let { root.removeView(it) }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "deckList" }
        getDeckNames().sorted().forEach { name ->
            val b = sectionButton("$name  •  ${getDeckCards(name).size} karet", true); b.setOnClickListener { showDeck(name) }; list.addView(b)
        }
        root.addView(list, (root.childCount - 1).coerceAtLeast(1))
    }

    private fun showNewDeckAndAddDialog(card: Card) {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle("NOVÝ BALÍČEK"))
        val input = EditText(this).apply { hint = "Název balíčku"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 18f; setSingleLine(true); background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_edit) }
        root.addView(input, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(roundedButton("ZRUŠIT") { dialog.dismiss() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        row.addView(roundedButton("VYTVOŘIT") {
            val name = input.text.toString().trim()
            if (name.isNotBlank()) { saveDeckNames(getDeckNames().toMutableSet().apply { add(name) }); addCardToDeck(name, card); dialog.dismiss(); Toast.makeText(this, "Přidáno do balíčku $name", Toast.LENGTH_SHORT).show() }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
        root.addView(row)
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.82f, 0.34f)
        input.requestFocus(); dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
    }

    private fun showDeckPicker(card: Card) {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle("PŘIDAT DO BALÍČKU"))
        getDeckNames().sorted().forEach { name ->
            val b = sectionButton(name, true); b.setOnClickListener { addCardToDeck(name, card); dialog.dismiss(); Toast.makeText(this, "Přidáno do balíčku $name", Toast.LENGTH_SHORT).show() }; root.addView(b)
        }
        root.addView(roundedButton("＋ NOVÝ BALÍČEK") { dialog.dismiss(); showNewDeckAndAddDialog(card) })
        root.addView(roundedButton("ZRUŠIT") { dialog.dismiss() })
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.84f, 0.64f)
    }

    private fun showDeck(name: String) {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle(name))
        val filter = makeSpinner(arrayOf("Vše", "Pokémon", "Energie", "Item", "Trainer", "Oblíbené")); root.addView(filter)
        val scroll = ScrollView(this); val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(roundedButton("ZAVŘÍT") { dialog.dismiss() })
        fun render() {
            content.removeAllViews()
            var list = cards.filter { getDeckCards(name).contains(it.id) }
            list = when (filter.selectedItem.toString()) {
                "Pokémon" -> list.filter { it.category.equals("Pokémon", true) }
                "Energie" -> list.filter { it.category.equals("Energy", true) || it.category.equals("Energie", true) }
                "Item" -> list.filter { it.category.equals("Trainer", true) && it.trainerSubtype.equals("Item", true) }
                "Trainer" -> list.filter { it.category.equals("Trainer", true) && !it.trainerSubtype.equals("Item", true) }
                "Oblíbené" -> list.filter { isFavorite(it) }
                else -> list
            }
            renderCards(content, list.sortedBy { it.number }, "Vše")
        }
        filter.onItemSelected { render() }
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.94f, 0.86f); render()
    }

    private fun getDeckNames(): Set<String> = prefs.getStringSet("deckNames", setOf("Můj balíček")) ?: setOf("Můj balíček")
    private fun saveDeckNames(names: Set<String>) { prefs.edit().putStringSet("deckNames", names).apply() }
    private fun getDeckCards(name: String): Set<String> = prefs.getStringSet("deck_$name", emptySet()) ?: emptySet()
    private fun addCardToDeck(name: String, card: Card) { prefs.edit().putStringSet("deck_$name", getDeckCards(name).toMutableSet().apply { add(card.id) }).apply() }

    private fun ownedCount(setId: String) = cards.count { it.setId == setId && isOwned(it) }
    private fun setTotal(setId: String) = cards.count { it.setId == setId }
    private fun ownedCountGeneration(gen: Int) = cards.count { it.generation == gen && isOwned(it) }
    private fun totalGeneration(gen: Int) = cards.count { it.generation == gen }

    private fun darkDialogRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_dialog)
    }
    private fun dialogTitle(text: String) = TextView(this).apply { this.text = text; textSize = 24f; setTextColor(Color.rgb(255,210,31)); setTypeface(typeface, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(10)) }
    private fun roundedButton(text: String, action: (View) -> Unit): Button = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 15f; setTextColor(Color.BLACK); setTypeface(typeface, android.graphics.Typeface.BOLD); background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_button); setOnClickListener(action); minHeight = dp(48)
    }
    private fun sectionButton(text: String, bold: Boolean): Button = roundedButton(text) {}.apply { textSize = if (bold) 16f else 15f; setOnClickListener(null) }
    private fun makeSpinner(items: Array<String>): Spinner {
        val spinner = Spinner(this)
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View = TextView(this@MainActivity).apply { text = items[position]; setTextColor(Color.WHITE); textSize = 13f; setPadding(dp(8), dp(10), dp(8), dp(10)) }
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); spinner.adapter = adapter; return spinner
    }
    private fun Spinner.onItemSelected(action: () -> Unit) = setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener { override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = action(); override fun onNothingSelected(parent: AdapterView<*>?) {} })

    private fun styleDialogWindow(dialog: Dialog, widthFraction: Float, heightFraction: Float) {
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * widthFraction).toInt(), (resources.displayMetrics.heightPixels * heightFraction).toInt())
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        barcodeScanner.close()
        executor.shutdownNow()
        artworkExecutor.shutdownNow()
        super.onDestroy()
    }

}
