package cz.lordfof.skan

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Dialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    private lateinit var cardImage: ImageView
    private lateinit var cardName: TextView
    private lateinit var cardInfo: TextView
    private lateinit var cardSet: TextView
    private lateinit var collectionButton: Button
    private lateinit var decksButton: Button
    private lateinit var mainContent: LinearLayout
    private val executor = Executors.newSingleThreadExecutor()
    private val scanning = AtomicBoolean(false)
    private val barcodeScanner = BarcodeScanning.getClient()

    // Ochrana proti předčasnému/kolísavému přečtení EANu.
    // Kód musí být rozpoznán opakovaně jako stejný kód, jinak se sken nepřijme.
    private var candidateCode: String? = null
    private var candidateFormat: Int = -1
    private var candidateHits: Int = 0
    private var candidateStartedAt: Long = 0L
    private var candidateLastAt: Long = 0L
    private var candidateCenterX: Float = 0f
    private var candidateCenterY: Float = 0f
    private var candidateWidth: Float = 0f
    private val prefs by lazy { getSharedPreferences("collection", MODE_PRIVATE) }
    private lateinit var cards: List<Card>
    private var scannerDialog: Dialog? = null

    private val cameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openScannerDialog()
        else Toast.makeText(this, "Bez povolení kamery SKAN nemůže skenovat EAN kódy.", Toast.LENGTH_LONG).show()
    }

    data class Card(
        val id: String,
        val number: Int,
        val name: String,
        val type: String,
        val element: String,
        val stage: String,
        val evolvesFrom: String,
        val evolutionFamily: String,
        val evolutionOrder: Int,
        val category: String,
        val trainerSubtype: String,
        val energySubtype: String,
        val rarity: String,
        val setId: String,
        val setName: String,
        val generation: Int,
        val imageSmall: String,
        val imageLarge: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        cards = loadCards()

        cardImage = findViewById(R.id.cardImage)
        cardName = findViewById(R.id.cardName)
        cardInfo = findViewById(R.id.cardInfo)
        cardSet = findViewById(R.id.cardSet)
        collectionButton = findViewById(R.id.collectionButton)
        decksButton = findViewById(R.id.decksButton)
        mainContent = findViewById(R.id.mainContent)

        // Výchozí stav: čekáme na první sken.
        cardImage.visibility = View.INVISIBLE
        cardName.text = ""
        cardInfo.text = ""
        cardSet.text = ""

        findViewById<ImageButton>(R.id.scan).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openScannerDialog()
            else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
        collectionButton.setOnClickListener { showCollectionDialog() }
        decksButton.setOnClickListener { showDecksDialog() }
        updateCollectionButton()
    }

    private fun loadCards(): List<Card> {
        val result = mutableListOf<Card>()
        val files = assets.list("") ?: emptyArray()
        files.filter { it.endsWith("_cards.json") }.forEach { file ->
            val root = JSONObject(assets.open(file).bufferedReader().use { it.readText() })
            val setId = root.optString("setId", file.substringBefore("_cards.json"))
            val setName = root.optString("setName", setId)
            val defaultGeneration = root.optInt("generation", 1)
            val a = root.getJSONArray("cards")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val numberText = o.optString("number", (i + 1).toString())
                result += Card(
                    id = o.getString("id"),
                    number = numberText.toIntOrNull() ?: (i + 1),
                    name = o.getString("name"),
                    type = o.optString("cardType", "Karta"),
                    element = readTextOrArray(o, "element", "elements", "types"),
                    stage = o.optString("stage", o.optString("evolutionStage", "")),
                    evolvesFrom = o.optString("evolvesFrom", ""),
                    evolutionFamily = o.optString("evolutionFamily", ""),
                    evolutionOrder = o.optInt("evolutionOrder", 0),
                    category = o.optString("category", o.optString("cardType", "")),
                    trainerSubtype = o.optString("trainerSubtype", ""),
                    energySubtype = o.optString("energySubtype", ""),
                    rarity = o.optString("rarity", "Common"),
                    setId = o.optString("setId", setId),
                    setName = o.optString("setName", setName),
                    generation = o.optInt("generation", defaultGeneration),
                    imageSmall = o.optString("imageSmall", o.optString("imageLarge")),
                    imageLarge = o.getString("imageLarge")
                )
            }
        }
        return result.sortedWith(compareBy<Card> { it.generation }.thenBy { it.setName }.thenBy { it.number })
    }

    private fun readTextOrArray(o: JSONObject, vararg keys: String): String {
        for (key in keys) {
            if (!o.has(key) || o.isNull(key)) continue
            val value = o.get(key)
            if (value is JSONArray) return (0 until value.length()).joinToString(", ") { value.optString(it) }
            val text = value.toString().trim()
            if (text.isNotEmpty()) return text
        }
        return ""
    }

    private fun openScannerDialog() {
        if (scannerDialog?.isShowing == true) return
        resetScanCandidate()
        scanning.set(true)
        val dialog = Dialog(this)
        scannerDialog = dialog
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_dialog)
        }
        val preview = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        root.addView(preview, LinearLayout.LayoutParams(dp(290), dp(290)).apply { gravity = Gravity.CENTER })
        root.addView(TextView(this).apply {
            text = "Namiř čtvereček na EAN čárový kód"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        root.addView(roundedButton("ZRUŠIT") { scanning.set(false); dialog.dismiss() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        dialog.setContentView(root)
        dialog.setCancelable(false)
        dialog.show()
        styleDialogWindow(dialog, 0.90f, 0.76f)
        startCamera(preview, dialog)
    }

    private fun startCamera(preview: PreviewView, dialog: Dialog) {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(executor) { proxy ->
                    val media = proxy.image
                    if (media == null || !scanning.get()) { proxy.close(); return@setAnalyzer }
                    val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                    barcodeScanner.process(image)
                        .addOnSuccessListener { codes ->
                            if (!scanning.get()) return@addOnSuccessListener

                            // Přijímáme jen skutečné EAN/UPC formáty a platný kontrolní součet.
                            // Když je v záběru více kódů, dáme přednost největšímu a nejcentrálnějšímu.
                            val candidate = codes
                                .mapNotNull { barcode ->
                                    val normalized = normalizeEan(barcode) ?: return@mapNotNull null
                                    val box = barcode.boundingBox
                                    if (box == null) return@mapNotNull null
                                    val centerX = (box.left + box.right) / 2f
                                    val centerY = (box.top + box.bottom) / 2f
                                    val area = box.width().toFloat() * box.height().toFloat()
                                    val frameCenter = image.width / 2f
                                    val centerDistance = kotlin.math.abs(centerX - frameCenter)
                                    Triple(barcode, normalized, area - centerDistance * 150f)
                                }
                                .maxByOrNull { it.third }

                            if (candidate == null) {
                                resetScanCandidate()
                            } else {
                                val barcode = candidate.first
                                val code = candidate.second
                                if (registerScanCandidate(code, barcode)) {
                                    if (scanning.compareAndSet(true, false)) {
                                        runOnUiThread {
                                            dialog.dismiss()
                                            scannerDialog = null
                                            showScanResult(code)
                                        }
                                    }
                                }
                            }
                        }
                        .addOnCompleteListener { proxy.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
                dialog.setOnDismissListener { scanning.set(false); provider.unbindAll(); scannerDialog = null }
            } catch (_: Exception) {
                scanning.set(false); dialog.dismiss(); Toast.makeText(this, "Kameru se nepodařilo otevřít.", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun normalizeEan(barcode: Barcode): String? {
        val raw = barcode.rawValue?.filter(Char::isDigit) ?: return null
        val normalized = when (barcode.format) {
            Barcode.FORMAT_EAN_13 -> if (raw.length == 13) raw else return null
            Barcode.FORMAT_EAN_8 -> if (raw.length == 8) raw else return null
            Barcode.FORMAT_UPC_A -> if (raw.length == 12) "0$raw" else return null
            else -> return null
        }
        return if (hasValidEanChecksum(normalized)) normalized else null
    }

    private fun hasValidEanChecksum(code: String): Boolean {
        if (code.length != 8 && code.length != 13) return false
        val digits = code.map { it - '0' }
        var sum = 0
        for (i in 0 until digits.lastIndex) {
            val positionFromRight = digits.lastIndex - i
            sum += if (positionFromRight % 2 == 1) digits[i] * 3 else digits[i]
        }
        val check = (10 - (sum % 10)) % 10
        return check == digits.last()
    }

    private fun registerScanCandidate(code: String, barcode: Barcode): Boolean {
        val now = System.currentTimeMillis()
        val box = barcode.boundingBox
        val centerX = box?.let { (it.left + it.right) / 2f } ?: 0f
        val centerY = box?.let { (it.top + it.bottom) / 2f } ?: 0f
        val width = box?.width()?.toFloat() ?: 0f

        val sameCandidate = candidateCode == code && candidateFormat == barcode.format
        val withinTime = candidateLastAt == 0L || now - candidateLastAt <= 700L
        val stablePosition = if (sameCandidate && candidateWidth > 0f && width > 0f) {
            val widthRatio = width / candidateWidth
            val positionOk = kotlin.math.abs(centerX - candidateCenterX) <= candidateWidth * 0.45f &&
                    kotlin.math.abs(centerY - candidateCenterY) <= candidateWidth * 0.70f
            positionOk && widthRatio in 0.55f..1.80f
        } else {
            true
        }

        if (sameCandidate && withinTime && stablePosition) {
            candidateHits += 1
        } else {
            candidateCode = code
            candidateFormat = barcode.format
            candidateHits = 1
            candidateStartedAt = now
        }

        candidateLastAt = now
        candidateCenterX = centerX
        candidateCenterY = centerY
        if (width > 0f) candidateWidth = width

        // Čtyři po sobě jdoucí stabilní snímky stejného EANu = potvrzený sken.
        return candidateHits >= 4 && now - candidateStartedAt <= 1500L
    }

    private fun resetScanCandidate() {
        candidateCode = null
        candidateFormat = -1
        candidateHits = 0
        candidateStartedAt = 0L
        candidateLastAt = 0L
        candidateCenterX = 0f
        candidateCenterY = 0f
        candidateWidth = 0f
    }

    private fun showScanResult(ean: String) {
        // EAN -> SHA-256 seed -> oficiální rarity -> konkrétní karta.
        // Výsledek je čistě deterministický: stejný EAN dá vždy stejnou kartu.
        val card = deterministicCardForEan(ean)
        val alreadyThisBarcode = hasScannedBarcode(ean)
        if (!alreadyThisBarcode) saveScan(ean, card)
        updateMainCard(card)
        updateCollectionButton()
        showMainScanResult(card, alreadyThisBarcode)
    }

    private fun updateMainCard(card: Card) {
        Glide.with(this).load(card.imageLarge).into(cardImage)
        cardName.text = card.name
        cardInfo.text = card.type
        cardSet.text = "${card.setName} · ${card.number}/${cards.count { it.setId == card.setId }}"
    }

    private fun showMainScanResult(card: Card, duplicateBarcode: Boolean) {
        // Výsledek skenu není dialog: karta se zobrazí přímo na hlavní obrazovce.
        cardImage.visibility = View.VISIBLE
        cardImage.translationX = 0f
        cardImage.alpha = if (duplicateBarcode) 0.32f else 1f
        cardName.alpha = 1f
        cardInfo.alpha = 1f
        cardSet.alpha = 1f
        cardInfo.text = if (duplicateBarcode) "JIŽ NASKENOVÁNO" else card.type
        cardName.text = card.name
        cardSet.text = "${card.setName} · ${card.number}/${cards.count { it.setId == card.setId }}"

        // Kliknutí na kartu ji odsunuje mimo obrazovku a připraví černou plochu pro další sken.
        cardImage.setOnClickListener { view ->
            val direction = if (view.x + view.width / 2f < resources.displayMetrics.widthPixels / 2f) {
                -resources.displayMetrics.widthPixels.toFloat()
            } else {
                resources.displayMetrics.widthPixels.toFloat()
            }
            animateMainCardOut(direction)
        }
        cardImage.setOnTouchListener { view, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val direction = if (event.x < view.width / 2f) -resources.displayMetrics.widthPixels.toFloat() else resources.displayMetrics.widthPixels.toFloat()
                animateMainCardOut(direction)
                true
            } else true
        }
    }

    private fun animateMainCardOut(direction: Float) {
        if (cardImage.visibility != View.VISIBLE) return
        cardImage.isClickable = false
        val move = ObjectAnimator.ofFloat(cardImage, View.TRANSLATION_X, 0f, direction)
        val fade = ObjectAnimator.ofFloat(cardImage, View.ALPHA, cardImage.alpha, 0f)
        AnimatorSet().apply {
            playTogether(move, fade)
            duration = 300
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    cardImage.visibility = View.INVISIBLE
                    cardImage.translationX = 0f
                    cardImage.alpha = 1f
                    cardImage.isClickable = true
                    cardName.text = ""
                    cardInfo.text = ""
                    cardSet.text = ""
                    cardName.alpha = 1f
                    cardInfo.alpha = 1f
                    cardSet.alpha = 1f
                }
            })
            start()
        }
    }

    private fun deterministicCardForEan(ean: String): Card {
        val digest = MessageDigest.getInstance("SHA-256").digest(ean.toByteArray(Charsets.UTF_8))

        // Používáme několik nezávislých částí stejného hashe, takže výsledek
        // nezávisí na zařízení, čase ani na tom, co už má hráč ve sbírce.
        fun unsignedByte(index: Int): Int = digest[index].toInt() and 0xFF
        val rarityRoll = (unsignedByte(0) shl 8) or unsignedByte(1)
        val rarityBucket = rarityRoll % 10_000

        // Herní drop šance. Názvy rarit jsou skutečné rarity Base Setu;
        // procenta jsou pouze pravidlo SKANu pro EAN loot.
        val rarity = when {
            rarityBucket < 5_500 -> "Common"       // 55.00 %
            rarityBucket < 8_000 -> "Uncommon"     // 25.00 %
            rarityBucket < 9_400 -> "Rare"         // 14.00 %
            else -> "Rare Holo"                    // 6.00 %
        }

        val pool = cards.filter { it.rarity.equals(rarity, ignoreCase = true) }
        if (pool.isEmpty()) return cards.first()

        var indexSeed = 0L
        for (i in 2..9) {
            indexSeed = (indexSeed shl 8) or (digest[i].toLong() and 0xFFL)
        }
        val index = Math.floorMod(indexSeed, pool.size.toLong()).toInt()
        return pool[index]
    }

    private fun scanMap(): MutableMap<String, String> {
        val raw = prefs.getString("scanMap", "{}") ?: "{}"
        val obj = JSONObject(raw)
        return obj.keys().asSequence().associateWith { obj.optString(it) }.toMutableMap()
    }

    private fun saveScan(ean: String, card: Card) {
        val map = scanMap()
        map[ean] = card.id
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k, v) }
        prefs.edit()
            .putString("scanMap", obj.toString())
            .putBoolean(card.id, true)
            .putLong(foundAtKey(card.id), System.currentTimeMillis())
            .apply()
    }

    private fun hasScannedBarcode(ean: String): Boolean = scanMap().containsKey(ean)

    private fun copyCount(card: Card): Int {
        val mapped = scanMap().values.count { it == card.id }
        return if (mapped > 0) mapped else if (prefs.getBoolean(card.id, false)) 1 else 0
    }

    private fun uniqueOwned(card: Card) = copyCount(card) > 0
    private fun foundAtKey(id: String) = "foundAt_$id"
    private fun favoriteKey(id: String) = "favorite_$id"
    private fun isOwned(card: Card) = uniqueOwned(card)
    private fun isFavorite(card: Card) = prefs.getBoolean(favoriteKey(card.id), false)

    private fun updateCollectionButton() {
        collectionButton.contentDescription = "Kolekce ${cards.count { isOwned(it) }}/${cards.size}"
    }

    private fun showCollectionDialog() {
        val dialog = Dialog(this)
        val root = darkDialogRoot()
        root.addView(dialogTitle("MOJE KOLEKCE"))

        val filterRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val modeSpinner = makeSpinner(arrayOf("Vše", "Nalezené", "Oblíbené", "Pokémon", "Energie", "Item", "Trainer"))
        val elementSpinner = makeSpinner(arrayOf("Všechny elementy") + availableElements().toTypedArray())
        val sortSpinner = makeSpinner(arrayOf("Datum nalezení", "Element", "Stadium vývoje", "Abecedy", "Pořadí na kartě"))
        filterRow.addView(modeSpinner)
        filterRow.addView(elementSpinner)
        filterRow.addView(sortSpinner)
        root.addView(filterRow)

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        root.addView(roundedButton("ZAVŘÍT") { dialog.dismiss() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val collapsedGenerations = mutableSetOf<Int>()
        val generations = cards.map { it.generation }.distinct().sorted()
        val sets = cards.map { it.setId }.distinct()

        lateinit var render: () -> Unit

        fun renderSetCards(setId: String) {
            content.removeAllViews()
            val set = cards.firstOrNull { it.setId == setId } ?: return
            val back = roundedButton("‹  ZPĚT NA SETY") { render() }
            content.addView(back, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            content.addView(TextView(this).apply {
                text = "${set.setName}  ${ownedCount(setId)}/${setTotal(setId)}"
                textSize = 20f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(0, dp(4), 0, dp(10))
            })
            renderCards(content, applyFilterAndSort(cards.filter { it.setId == setId }, modeSpinner.selectedItem.toString(), elementSpinner.selectedItem.toString(), sortSpinner.selectedItem.toString()), modeSpinner.selectedItem.toString())
        }

        fun renderSetTiles(container: LinearLayout, setCards: List<Card>) {
            val grid = GridLayout(this).apply {
                columnCount = 2
                alignmentMode = GridLayout.ALIGN_BOUNDS
                useDefaultMargins = false
                setPadding(dp(4), dp(4), dp(4), dp(10))
            }
            setCards.distinctBy { it.setId }.sortedBy { it.setName }.forEach { set ->
                val tile = setTile(set)
                tile.setOnClickListener { renderSetCards(set.setId) }
                grid.addView(tile, GridLayout.LayoutParams().apply {
                    width = 0
                    height = dp(122)
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(dp(5), dp(5), dp(5), dp(5))
                })
            }
            container.addView(grid)
        }

        render = {
            content.removeAllViews()
            if (sets.size == 1) {
                renderSetTiles(content, cards)
            } else {
                generations.forEach { gen ->
                    val genSets = cards.filter { it.generation == gen }.distinctBy { it.setId }.sortedBy { it.setName }
                    val genHeader = sectionButton("Gen $gen  ${ownedCountGeneration(gen)}/${totalGeneration(gen)}", true)
                    content.addView(genHeader)
                    val genBody = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        visibility = if (collapsedGenerations.contains(gen)) View.GONE else View.VISIBLE
                    }
                    genHeader.setOnClickListener {
                        if (!collapsedGenerations.add(gen)) collapsedGenerations.remove(gen)
                        render()
                    }
                    content.addView(genBody)
                    if (genBody.visibility == View.VISIBLE) renderSetTiles(genBody, genSets)
                }
            }
        }

        modeSpinner.onItemSelected { render() }
        elementSpinner.onItemSelected { render() }
        sortSpinner.onItemSelected { render() }
        dialog.setContentView(root)
        dialog.show()
        styleDialogWindow(dialog, 0.92f, 0.88f)
        render()
    }

    private fun setTile(set: Card): LinearLayout {
        val tile = FrameLayout(this).apply {
            background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_dialog)
            clipToOutline = true
            elevation = dp(3).toFloat()
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(35, 35, 35))
            if (set.setId.equals("base1", true) || set.setName.equals("Base Set", true)) {
                setImageResource(R.drawable.base_set_tile)
            }
        }
        tile.addView(image, FrameLayout.LayoutParams(-1, -1))

        val shade = View(this).apply { setBackgroundColor(Color.argb(80, 0, 0, 0)) }
        tile.addView(shade, FrameLayout.LayoutParams(-1, -1))

        val title = TextView(this).apply {
            text = set.setName
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setShadowLayer(5f, 1f, 1f, Color.BLACK)
            gravity = Gravity.TOP or Gravity.START
            setPadding(dp(10), dp(8), dp(8), dp(4))
        }
        tile.addView(title, FrameLayout.LayoutParams(-1, -2, Gravity.TOP or Gravity.START))

        val count = TextView(this).apply {
            text = "${ownedCount(set.setId)}/${setTotal(set.setId)}"
            textSize = 15f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setShadowLayer(4f, 1f, 1f, Color.BLACK)
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(8), dp(4), dp(10), dp(8))
        }
        tile.addView(count, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM or Gravity.END))
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tile, LinearLayout.LayoutParams(-1, -1))
        }
    }

    private fun availableElements(): List<String> = cards.flatMap { it.element.split(",", "/", "|") }.map { it.trim() }.filter { it.isNotEmpty() }.distinct().sorted()

    private fun applyFilterAndSort(source: List<Card>, mode: String, element: String, sort: String): List<Card> {
        var list = source
        list = when (mode) {
            "Nalezené" -> list.filter { isOwned(it) }
            "Oblíbené" -> list.filter { isFavorite(it) }
            "Pokémon" -> list.filter { it.category.equals("Pokémon", true) }
            "Energie" -> list.filter { it.category.equals("Energy", true) || it.category.equals("Energie", true) }
            "Item" -> list.filter { it.category.equals("Trainer", true) && it.trainerSubtype.equals("Item", true) }
            "Trainer" -> list.filter { it.category.equals("Trainer", true) && !it.trainerSubtype.equals("Item", true) }
            else -> list
        }
        if (element != "Všechny elementy") list = list.filter { it.element.split(",", "/", "|").map { e -> e.trim() }.any { it.equals(element, true) } }
        return when (sort) {
            "Datum nalezení" -> list.sortedWith(compareByDescending<Card> { prefs.getLong(foundAtKey(it.id), 0L) }.thenBy { it.number })
            "Element" -> list.sortedWith(compareBy<Card> { it.element.ifBlank { "~" } }.thenBy { it.evolutionFamily.ifBlank { it.name } }.thenBy { it.evolutionOrder }.thenBy { it.number })
            "Stadium vývoje" -> list.sortedWith(compareBy<Card> { it.evolutionFamily.ifBlank { "~" } }.thenBy { it.evolutionOrder }.thenBy { it.number })
            "Abecedy" -> list.sortedBy { it.name.lowercase() }
            else -> list.sortedBy { it.number }
        }
    }

    private fun renderCards(content: LinearLayout, setCards: List<Card>, mode: String) {
        if (setCards.isEmpty()) {
            content.addView(TextView(this).apply { text = "Žádné karty neodpovídají filtru."; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(dp(8), dp(18), dp(8), dp(18)) })
            return
        }
        val grid = GridLayout(this).apply { columnCount = 3; useDefaultMargins = true; setPadding(dp(4), dp(4), dp(4), dp(8)) }
        setCards.forEach { card ->
            val copies = copyCount(card)
            val repeat = if (mode == "Nalezené" && copies > 1) copies else 1
            repeat(repeat) {
                val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(3), dp(3), dp(8)) }
                val image = ImageView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(96), dp(134)); scaleType = ImageView.ScaleType.CENTER_CROP; contentDescription = card.name; alpha = if (isOwned(card)) 1f else 0.28f
                    setOnClickListener { showCardViewer(card) }
                }
                Glide.with(this).load(card.imageSmall).into(image)
                tile.addView(image)
                val label = if (copies > 1) "#${card.number}  ×$copies${if (isFavorite(card)) "  ♥" else ""}" else "#${card.number}${if (isFavorite(card)) "  ♥" else ""}"
                tile.addView(TextView(this).apply { text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE) })
                tile.setOnClickListener { showCardViewer(card) }
                grid.addView(tile, GridLayout.LayoutParams().apply { width = 0; height = GridLayout.LayoutParams.WRAP_CONTENT; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) })
            }
        }
        content.addView(grid)
    }

    private fun showCardViewer(card: Card) {
        val viewer = Dialog(this)
        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
        }

        // Náhled karty: samotná karta uprostřed, okolí pouze ztlumené.
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = card.name
            setOnClickListener { viewer.dismiss() }
        }
        frame.addView(image, FrameLayout.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.94f).toInt(),
            (resources.displayMetrics.heightPixels * 0.80f).toInt(),
            Gravity.CENTER
        ))
        Glide.with(this).load(card.imageLarge).into(image)

        // Tři malé kulaté ovládací prvky vpravo dole: oblíbené, do balíčku, zpět.
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        val favoriteButton = iconButton(if (isFavorite(card)) "♥" else "♡", "Oblíbené")
        favoriteButton.setOnClickListener {
            val newValue = !isFavorite(card)
            prefs.edit().putBoolean(favoriteKey(card.id), newValue).apply()
            favoriteButton.text = if (newValue) "♥" else "♡"
            updateCollectionButton()
        }

        val deckButton = iconButton("+", "Do balíčku")
        deckButton.setOnClickListener { showDeckPicker(card) }

        val backButton = iconButton("‹", "Zpět")
        backButton.setOnClickListener { viewer.dismiss() }

        actions.addView(favoriteButton, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(6) })
        actions.addView(deckButton, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(6) })
        actions.addView(backButton, LinearLayout.LayoutParams(dp(56), dp(56)))

        frame.addView(actions, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.END
        ).apply {
            rightMargin = dp(18)
            bottomMargin = dp(18)
        })

        frame.setOnClickListener { viewer.dismiss() }
        viewer.setContentView(frame)
        viewer.setCanceledOnTouchOutside(true)
        viewer.show()
        viewer.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        viewer.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        viewer.window?.attributes = viewer.window?.attributes?.apply { dimAmount = 0.72f }
        viewer.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        )
    }

    private fun iconButton(symbol: String, description: String): Button = Button(this).apply {
        text = symbol
        contentDescription = description
        textSize = 27f
        setTextColor(Color.WHITE)
        isAllCaps = false
        gravity = Gravity.CENTER
        includeFontPadding = false
        background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_icon_button)
        minWidth = 0
        minHeight = 0
        setPadding(0, 0, 0, 0)
    }

    private fun showDecksDialog() {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle("MOJE BALÍČKY"))
        root.addView(roundedButton("＋ NOVÝ BALÍČEK") { showNewDeckDialog(dialog) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        renderDeckList(root, dialog)
        root.addView(roundedButton("ZAVŘÍT") { dialog.dismiss() })
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.88f, 0.72f)
    }

    private fun showNewDeckDialog(parent: Dialog) {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle("NOVÝ BALÍČEK"))
        val input = EditText(this).apply { hint = "Název balíčku"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 18f; setSingleLine(true); background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_edit) }
        root.addView(input, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(roundedButton("ZRUŠIT") { dialog.dismiss() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        row.addView(roundedButton("VYTVOŘIT") {
            val name = input.text.toString().trim()
            if (name.isNotBlank()) { saveDeckNames(getDeckNames().toMutableSet().apply { add(name) }); dialog.dismiss(); parent.dismiss(); showDecksDialog() }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
        root.addView(row)
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.82f, 0.34f)
        input.requestFocus(); dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
    }

    private fun renderDeckList(root: LinearLayout, dialog: Dialog) {
        root.findViewWithTag<View>("deckList")?.let { root.removeView(it) }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "deckList" }
        getDeckNames().sorted().forEach { name ->
            val b = sectionButton("$name  •  ${getDeckCards(name).size} karet", true); b.setOnClickListener { showDeck(name) }; list.addView(b)
        }
        root.addView(list, (root.childCount - 1).coerceAtLeast(1))
    }

    private fun showNewDeckAndAddDialog(card: Card) {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle("NOVÝ BALÍČEK"))
        val input = EditText(this).apply { hint = "Název balíčku"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); textSize = 18f; setSingleLine(true); background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_edit) }
        root.addView(input, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(roundedButton("ZRUŠIT") { dialog.dismiss() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
        row.addView(roundedButton("VYTVOŘIT") {
            val name = input.text.toString().trim()
            if (name.isNotBlank()) { saveDeckNames(getDeckNames().toMutableSet().apply { add(name) }); addCardToDeck(name, card); dialog.dismiss(); Toast.makeText(this, "Přidáno do balíčku $name", Toast.LENGTH_SHORT).show() }
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
        root.addView(row)
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.82f, 0.34f)
        input.requestFocus(); dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
    }

    private fun showDeckPicker(card: Card) {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle("PŘIDAT DO BALÍČKU"))
        getDeckNames().sorted().forEach { name ->
            val b = sectionButton(name, true); b.setOnClickListener { addCardToDeck(name, card); dialog.dismiss(); Toast.makeText(this, "Přidáno do balíčku $name", Toast.LENGTH_SHORT).show() }; root.addView(b)
        }
        root.addView(roundedButton("＋ NOVÝ BALÍČEK") { dialog.dismiss(); showNewDeckAndAddDialog(card) })
        root.addView(roundedButton("ZRUŠIT") { dialog.dismiss() })
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.84f, 0.64f)
    }

    private fun showDeck(name: String) {
        val dialog = Dialog(this)
        val root = darkDialogRoot(); root.addView(dialogTitle(name))
        val filter = makeSpinner(arrayOf("Vše", "Pokémon", "Energie", "Item", "Trainer", "Oblíbené")); root.addView(filter)
        val scroll = ScrollView(this); val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(roundedButton("ZAVŘÍT") { dialog.dismiss() })
        fun render() {
            content.removeAllViews()
            var list = cards.filter { getDeckCards(name).contains(it.id) }
            list = when (filter.selectedItem.toString()) {
                "Pokémon" -> list.filter { it.category.equals("Pokémon", true) }
                "Energie" -> list.filter { it.category.equals("Energy", true) || it.category.equals("Energie", true) }
                "Item" -> list.filter { it.category.equals("Trainer", true) && it.trainerSubtype.equals("Item", true) }
                "Trainer" -> list.filter { it.category.equals("Trainer", true) && !it.trainerSubtype.equals("Item", true) }
                "Oblíbené" -> list.filter { isFavorite(it) }
                else -> list
            }
            renderCards(content, list.sortedBy { it.number }, "Vše")
        }
        filter.onItemSelected { render() }
        dialog.setContentView(root); dialog.show(); styleDialogWindow(dialog, 0.94f, 0.86f); render()
    }

    private fun getDeckNames(): Set<String> = prefs.getStringSet("deckNames", setOf("Můj balíček")) ?: setOf("Můj balíček")
    private fun saveDeckNames(names: Set<String>) { prefs.edit().putStringSet("deckNames", names).apply() }
    private fun getDeckCards(name: String): Set<String> = prefs.getStringSet("deck_$name", emptySet()) ?: emptySet()
    private fun addCardToDeck(name: String, card: Card) { prefs.edit().putStringSet("deck_$name", getDeckCards(name).toMutableSet().apply { add(card.id) }).apply() }

    private fun ownedCount(setId: String) = cards.count { it.setId == setId && isOwned(it) }
    private fun setTotal(setId: String) = cards.count { it.setId == setId }
    private fun ownedCountGeneration(gen: Int) = cards.count { it.generation == gen && isOwned(it) }
    private fun totalGeneration(gen: Int) = cards.count { it.generation == gen }

    private fun darkDialogRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_dialog)
    }
    private fun dialogTitle(text: String) = TextView(this).apply { this.text = text; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(10)) }
    private fun roundedButton(text: String, action: (View) -> Unit): Button = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 15f; setTextColor(Color.WHITE); background = ContextCompat.getDrawable(this@MainActivity, R.drawable.rounded_button); setOnClickListener(action); minHeight = dp(48)
    }
    private fun sectionButton(text: String, bold: Boolean): Button = roundedButton(text) {}.apply { textSize = if (bold) 16f else 15f; setOnClickListener(null) }
    private fun makeSpinner(items: Array<String>): Spinner {
        val spinner = Spinner(this)
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View = TextView(this@MainActivity).apply { text = items[position]; setTextColor(Color.WHITE); textSize = 13f; setPadding(dp(8), dp(10), dp(8), dp(10)) }
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); spinner.adapter = adapter; return spinner
    }
    private fun Spinner.onItemSelected(action: () -> Unit) = setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener { override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = action(); override fun onNothingSelected(parent: AdapterView<*>?) {} })

    private fun styleDialogWindow(dialog: Dialog, widthFraction: Float, heightFraction: Float) {
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * widthFraction).toInt(), (resources.displayMetrics.heightPixels * heightFraction).toInt())
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        barcodeScanner.close()
        executor.shutdownNow()
        super.onDestroy()
    }

}
