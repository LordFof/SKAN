SKAN card data provenance

Pokémon Base Set images use the existing public image endpoint already configured in the project.
Star Wars and Italian Brainrot use real card metadata/checklists. Official artwork is intentionally NOT bundled here without permission from the rights holders.

Star Wars Masterwork source: https://www.topps.com/pages/topps-masterwork-star-wars
Topps checklists: https://www.topps.com/pages/checklists
Italian Brainrot source: https://panini-clickdistribution.co.uk/collections/trading-card-collections/products/italian-brainrot-trading-card-collection-packs

No fake card artwork is included. Empty image fields mean the app must not pretend an image is the real card.
