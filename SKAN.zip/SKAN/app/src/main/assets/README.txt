SKAN card data provenance

Pokémon Base Set images use the existing public image endpoint already configured in the project.
Star Wars uses card metadata/checklists. Brainrot uses the separate YumCut catalog. Remote artwork is referenced by URL.

Star Wars Masterwork source: https://www.topps.com/pages/topps-masterwork-star-wars
Topps checklists: https://www.topps.com/pages/checklists
YumCut Brainrot source: https://yumcut.com/brainrot-characters/c/brainrot

No fake card artwork is included. Empty image fields mean the app must not pretend an image is the real card.
