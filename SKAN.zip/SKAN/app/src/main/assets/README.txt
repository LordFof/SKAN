SKAN Base Set database. 102 real English Base Set cards. Card metadata is bundled locally; card images use the image URLs from the PokemonTCG historical data set and are loaded when a card is shown.
Source: https://github.com/PokemonTCG/pokemon-tcg-data
