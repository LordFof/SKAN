# SKAN global UI style

The shared UI language now follows the Brainrot card preview: black/dark surfaces, yellow SKAN accent, rounded controls, yellow outlined icon buttons, and rounded dark dialogs. This styling is shared across Pokemon, Star Wars, Hot Wheels and Brainrot screens without changing scanner/EAN logic.
