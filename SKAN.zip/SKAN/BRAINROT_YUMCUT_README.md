# YumCut Brainrot cards

- Existing `brainrot_yumcut` set is preserved.
- New `brainrot_yumcut` set contains 451 named entries from the YumCut Brainrot catalog currently indexed during this build.
- Each card has a 1–8 rarity number.
- Artwork is remote from YumCut; no artwork files are bundled.
- **Scanner logic was not changed.** EAN -> SHA-256 -> universe/set/card remains in `MainActivity.kt`.
- YumCut catalog: https://yumcut.com/brainrot-characters/c/brainrot
