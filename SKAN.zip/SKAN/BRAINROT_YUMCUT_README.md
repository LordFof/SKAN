# YumCut Brainrot cards

- Existing `brainrot_yumcut` set is preserved.
- New `brainrot_yumcut` set contains 451 named entries from the YumCut Brainrot catalog currently indexed during this build.
- Each card has a 1–8 rarity number.
- Artwork is remote from YumCut; no artwork files are bundled.
- **Scanner logic was not changed.** EAN -> SHA-256 -> universe/set/card remains in `MainActivity.kt`.
- YumCut catalog: https://yumcut.com/brainrot-characters/c/brainrot

## Artwork / scanning lock
Brainrot cards are only obtainable by EAN scanning when their artwork is bundled in `app/src/main/assets/brainrot_art/`. Cards without bundled artwork remain visible in the collection as `COMING SOON` and are excluded from the deterministic scanner loot pool. When an artwork is added later, set that card's `scannable` to `true` in `brainrot_yumcut_cards.json`.
