# SKAN build + signing

Version: 0.3.4 (versionCode 7)

The project uses the same applicationId `cz.lordfof.skan`, so updates keep the app identity and saved collection data.

Release signing:
- keystore: `signing/skan-release.jks`
- alias: `skan-release`
- store password: `SKAN2026Key!`
- key password: `SKAN2026Key!`

For GitHub Actions, add these repository secrets:
- `SKAN_KEYSTORE_BASE64` = base64 contents of `signing/skan-release.jks`
- `SKAN_KEY_ALIAS` = `skan-release`
- `SKAN_STORE_PASSWORD` = `SKAN2026Key!`
- `SKAN_KEY_PASSWORD` = `SKAN2026Key!`

Never expose the keystore or private signing password in a public repository.
