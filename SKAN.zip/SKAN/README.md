# SKAN

Deterministic EAN-to-collectible-card game prototype with multiple universes.

## Current build
- Real camera scanning only; no manual barcode field.
- Scans EAN/UPC-style numeric product barcodes through ML Kit.
- Same EAN always maps to the same Base Set card on every device.
- Base Set database: all 102 English cards (Pokemon, Trainer, Energy).
- Card metadata is bundled in `app/src/main/assets/base1_cards.json`.
- Card images are loaded from the image URLs recorded in that database.
- Collection is saved locally.
- Deterministic rarity loot is implemented. Current drop rates: Common 75%, Uncommon 17%, Rare 6%, Rare Holo 2%.
- Brainrot/YumCut cards use the same deterministic EAN mapping and collection system.

## Update compatibility
- Application ID remains `cz.lordfof.skan`.
- Collection/progress is stored in the existing `SharedPreferences` file named `collection`.
- This release does not clear or migrate away existing collection data.
- `scanMap`, found timestamps, favorites and deck data remain under the same keys, so installing a newer version over the existing app preserves progress.
- Version code is `8` (`0.3.5`).



## 0.3.5 changes
- Duplicate scan result shows the existing card visibly darkened.
- Collection cards display their card number (`#`).
- Unscanned cards remain hidden/locked but show their card number.
- Locked cards show rarity and the current loot-table drop chance: Common 75%, Uncommon 17%, Rare 6%, Rare Holo 2%.
- The same EAN deterministically maps to the same card and remains stored after the first scan.
- Existing collection storage and EAN-to-card mapping remain unchanged.
- Brainrot/YumCut collection cards use the same numbering, locked-state and rarity display rules.
