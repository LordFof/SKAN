# SKAN

Prototype of a deterministic EAN-to-Pokemon-TCG card game.

## Current build
- Real camera scanning only; no manual barcode field.
- Scans EAN/UPC-style numeric product barcodes through ML Kit.
- Same EAN always maps to the same Base Set card on every device.
- Base Set database: all 102 English cards (Pokemon, Trainer, Energy).
- Card metadata is bundled in `app/src/main/assets/base1_cards.json`.
- Card images are loaded from the image URLs recorded in that database.
- Collection is saved locally.
- Drop rates/rarities are intentionally not implemented yet.

Next planned stage: expand the local database with more sets, then design drop-rate/game mechanics.
