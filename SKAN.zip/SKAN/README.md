# SKAN

Prototype of a deterministic EAN-to-Pokemon-TCG card game.

## Current build
- Real camera scanning only; no manual barcode field.
- Scans EAN/UPC-style numeric product barcodes through ML Kit.
- Same EAN always maps to the same Base Set card on every device.
- Base Set database: all 102 English cards (Pokemon, Trainer, Energy).
- Card metadata is bundled in `app/src/main/assets/base1_cards.json`.
- Card images are loaded from the image URLs recorded in that database.
- Collection is saved locally.
- Drop rates/rarities are intentionally not implemented yet.

Next planned stage: expand the local database with more sets, then design drop-rate/game mechanics.

## Update compatibility
- Application ID remains `cz.lordfof.skan`.
- Collection/progress is stored in the existing `SharedPreferences` file named `collection`.
- This release does not clear or migrate away existing collection data.
- `scanMap`, found timestamps, favorites and deck data remain under the same keys, so installing a newer version over the existing app preserves progress.
- Version code is `5` (`0.3.2`).



## 0.3.2 changes
- Duplicate scan result shows the existing card visibly darkened.
- Collection cards display their card number (`#`).
- Unscanned cards remain hidden/locked but show their card number.
- Locked cards show rarity and loot-table drop chance: Common 55%, Uncommon 25%, Rare 14%, Rare Holo 6%.
- Existing collection storage and EAN-to-card mapping remain unchanged.
