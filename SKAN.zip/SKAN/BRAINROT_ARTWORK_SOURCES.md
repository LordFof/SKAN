# Brainrot artwork sources

Remote artwork is referenced only where the source page explicitly states the images are free to use, including commercial projects/social media.

- #1 Bluberini Octopusini — https://yumcut.com/brainrot-characters/image/bluberini-octopusini
- #14 Frulli Frulla — https://yumcut.com/brainrot-characters/image/frulli-frulla
- #16 Boneca Ambalabu — https://yumcut.com/brainrot-characters/image/boneca-ambalabu
- #19 Ballerino Lololo — https://yumcut.com/brainrot-characters/image/ballerino-lololo
- #28 Chimpanzini Bananini — https://yumcut.com/brainrot-characters/image/chimpanzini-bananini
- #38 Lirili Larila — https://yumcut.com/brainrot-characters/image/lirili-larila
- #50 Giraffa Celeste — https://yumcut.com/brainrot-characters/image/girafa-celeste
- #60 Ballerina Cappuccina — https://yumcut.com/brainrot-characters/image/ballerina-cappuccina
- #76 Tralalero Tralala — https://yumcut.com/brainrot-characters/image/tralalero-tralala
- #78 Frigo Camelo — https://yumcut.com/brainrot-characters/image/frigo-camelo
- #102 Brr Brr Patapim — https://yumcut.com/brainrot-characters/image/brr-brr-patapim
- #104 Burbaloni Luliloli — https://yumcut.com/brainrot-characters/image/burbaloni-lulilolli
- #119 Trippi Troppi — https://yumcut.com/brainrot-characters/image/trippi-troppi-troppa-trippa
- #123 Orangutini Ananasini — https://yumcut.com/brainrot-characters/image/orangutini-ananasini
- #141 Cocofanto Elefanto — https://yumcut.com/brainrot-characters/image/cocofanto-elefanto

Cards without a verified reusable image remain COMING SOON.
