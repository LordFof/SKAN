#!/usr/bin/env bash
set -euo pipefail
base64 -w 0 signing/skan-release.jks > skan-release.jks.base64
printf '\nCreated skan-release.jks.base64 for GitHub secret SKAN_KEYSTORE_BASE64.\n'
