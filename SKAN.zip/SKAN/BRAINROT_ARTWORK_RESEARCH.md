# Brainrot Alpha – artwork research

All 150 Alpha cards have remote artwork candidates matched from their names.

Source catalog: https://yumcut.com/brainrot-characters

The app uses remote URLs; cards whose exact source URL later needs correction can be replaced without changing the card database structure.
