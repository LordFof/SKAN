# SKEN.tcg

První prototyp hry: čárový kód → deterministicky vybraná karta Pokémon #001–#151 → automatické uložení do kolekce.

Aktuálně je skenování simulované zadáním čárového kódu. Skutečný kamerový skener bude přidán v další verzi.

## GitHub Actions
Workflow je v `.github/workflows/build-apk.yml` a po pushi na `main` nebo `test` sestaví debug APK jako artifact `SKEN-tcg-debug`.
